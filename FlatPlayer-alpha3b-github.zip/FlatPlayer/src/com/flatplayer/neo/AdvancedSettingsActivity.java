package com.flatplayer.neo;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.io.File;
import java.util.ArrayList;
import android.widget.TextView;

public class AdvancedSettingsActivity extends PlayerBindActivity {

    private static final int REQ_EXPORT = 41;
    private static final int REQ_IMPORT = 42;

    private Prefs prefs;
    private String pendingExport;
    private String pendingImport;
    private RadioGroup themeGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = new Prefs(this);

        ImageButton back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        themeGroup = findViewById(R.id.theme_group);
        int mode = prefs.theme();
        int themeChecked = mode == Prefs.THEME_LIGHT ? R.id.theme_light
                : mode == Prefs.THEME_DARK ? R.id.theme_dark : R.id.theme_follow;
        themeGroup.check(themeChecked);
        themeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int value = checkedId == R.id.theme_light ? Prefs.THEME_LIGHT
                        : checkedId == R.id.theme_dark ? Prefs.THEME_DARK : Prefs.THEME_FOLLOW;
                if (value != prefs.theme()) {
                    prefs.setTheme(value);
                    recreate();
                }
            }
        });

        Switch resume = findViewById(R.id.sw_resume);
        resume.setChecked(prefs.resume());
        resume.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton button, boolean checked) {
                prefs.setResume(checked);
            }
        });

        Switch headset = findViewById(R.id.sw_headset);
        headset.setChecked(prefs.headset());
        headset.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton button, boolean checked) {
                prefs.setHeadset(checked);
            }
        });

        Switch confirm = findViewById(R.id.sw_confirm);
        confirm.setChecked(prefs.confirmSingle());
        confirm.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton button, boolean checked) {
                prefs.setConfirmSingle(checked);
            }
        });

        android.view.View searchModeRow = findViewById(R.id.search_mode_row);
        if (searchModeRow != null) {
            searchModeRow.setVisibility(android.view.View.GONE);
        }
        final TextView fadeRow = findViewById(R.id.fade_row);
        fadeRow.setText(getString(R.string.fade_switch) + "："
                + getString(R.string.fade_fmt, prefs.fadeSeconds()));
        fadeRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final float[] value = {prefs.fadeSeconds()};
                android.widget.LinearLayout box = new android.widget.LinearLayout(AdvancedSettingsActivity.this);
                box.setOrientation(android.widget.LinearLayout.VERTICAL);
                int pad = (int) (20 * getResources().getDisplayMetrics().density);
                box.setPadding(pad, pad / 2, pad, 0);
                final TextView label = new TextView(AdvancedSettingsActivity.this);
                label.setTextColor(0xFF888888);
                label.setText(getString(R.string.fade_fmt, value[0]));
                box.addView(label);
                SeekBar bar = new SeekBar(AdvancedSettingsActivity.this);
                bar.setMax(30);
                bar.setProgress(Math.round(value[0] * 10));
                bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        value[0] = progress / 10f;
                        label.setText(getString(R.string.fade_fmt, value[0]));
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
                box.addView(bar);
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.fade_switch)
                        .setView(box)
                        .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                prefs.setFadeSeconds(value[0]);
                                if (service != null) {
                                    service.setFadeSeconds(value[0]);
                                }
                                fadeRow.setText(getString(R.string.fade_switch) + "："
                                        + getString(R.string.fade_fmt, value[0]));
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
        });

        final TextView eqRow = findViewById(R.id.equalizer_row);
        eqRow.setText(R.string.equalizer);
        eqRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service == null || !service.isEqualizerAvailable()) {
                    Toast.makeText(AdvancedSettingsActivity.this, R.string.eq_need_play, Toast.LENGTH_SHORT).show();
                    return;
                }
                showEqualizerDialog();
            }
        });

        final boolean darkMode = prefs.theme() == Prefs.THEME_DARK
                || (prefs.theme() == Prefs.THEME_FOLLOW
                && (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES);
        final String[] bgNames = darkMode
                ? new String[]{getString(R.string.bg_deep_gray), getString(R.string.bg_black),
                getString(R.string.bg_blue_gray)}
                : new String[]{getString(R.string.bg_white), getString(R.string.bg_warm),
                getString(R.string.bg_light_gray)};
        findViewById(R.id.help_row).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdvancedSettingsActivity.this, HelpActivity.class));
            }
        });

        final TextView notificationRow = findViewById(R.id.notification_row);
        updateNotificationRow(notificationRow);
        notificationRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT < 33
                        || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                try {
                    Intent intent = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    intent.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(intent);
                } catch (Exception ignored) {
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                android.net.Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored2) {
                        // 忽略
                    }
                }
            }
        });

        final TextView materialRow = findViewById(R.id.material_row);
        materialRow.setText(getString(R.string.material) + "："
                + getString(prefs.glassMaterial() == 1
                ? R.string.material_acrylic : R.string.material_blur));
        materialRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] names = {getString(R.string.material_blur),
                        getString(R.string.material_acrylic)};
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.material)
                        .setSingleChoiceItems(names, prefs.glassMaterial(),
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        prefs.setGlassMaterial(which);
                                        recreate();
                                    }
                                })
                        .show();
            }
        });

        final TextView glassRow = findViewById(R.id.glass_row);
        int glass = prefs.frostedGlass();
        if (glass < 0) {
            boolean lowRam = ((android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE))
                    .isLowRamDevice();
            glass = lowRam ? 0 : 2;
        }
        final String[] glassNames = {
                getString(R.string.glass_off),
                getString(R.string.glass_light),
                getString(R.string.glass_standard),
                getString(R.string.glass_strong)
        };
        glassRow.setText(getString(R.string.frosted_glass) + "：" + glassNames[glass]);
        final int glassCurrent = glass;
        glassRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.frosted_glass)
                        .setSingleChoiceItems(glassNames, glassCurrent,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        prefs.setFrostedGlass(which);
                                        recreate();
                                    }
                                })
                        .show();
            }
        });

        final TextView bgRow = findViewById(R.id.bg_row);
        int bgIndex = Math.max(0, Math.min(2, prefs.backgroundPreset()));
        bgRow.setText(getString(R.string.bg_color) + "：" + bgNames[bgIndex]);
        bgRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.bg_color)
                        .setSingleChoiceItems(bgNames, prefs.backgroundPreset(),
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        prefs.setBackgroundPreset(which);
                                        recreate();
                                    }
                                })
                        .show();
            }
        });

        final TextView accentRow = findViewById(R.id.accent_row);
        accentRow.setText(getString(R.string.accent) + "：" + getString(R.string.hue_fmt, prefs.accentHue()));
        accentRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int[] hue = {prefs.accentHue()};
                android.widget.LinearLayout box = new android.widget.LinearLayout(AdvancedSettingsActivity.this);
                box.setOrientation(android.widget.LinearLayout.VERTICAL);
                int pad = (int) (20 * getResources().getDisplayMetrics().density);
                box.setPadding(pad, pad / 2, pad, 0);

                final TextView preview = new TextView(AdvancedSettingsActivity.this);
                preview.setHeight((int) (56 * getResources().getDisplayMetrics().density));
                preview.setText("　");
                box.addView(preview);

                final SeekBar hueBar = new SeekBar(AdvancedSettingsActivity.this);
                hueBar.setMax(359);
                hueBar.setProgress(hue[0]);
                box.addView(hueBar);

                final TextView label = new TextView(AdvancedSettingsActivity.this);
                label.setTextColor(0xFF888888);
                label.setTextSize(12);
                label.setText(getString(R.string.hue_fmt, hue[0]));
                box.addView(label);

                final android.graphics.drawable.GradientDrawable circle = new android.graphics.drawable.GradientDrawable();
                circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                circle.setColor(android.graphics.Color.HSVToColor(new float[]{hue[0], 0.65f, 0.95f}));
                preview.setBackground(circle);

                hueBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        hue[0] = progress;
                        circle.setColor(android.graphics.Color.HSVToColor(new float[]{progress, 0.65f, 0.95f}));
                        label.setText(getString(R.string.hue_fmt, progress));
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });

                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.accent)
                        .setView(box)
                        .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                prefs.setAccentHue(hue[0]);
                                recreate();
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
        });

        final TextView searchRow = findViewById(R.id.search_mode_row);
        searchRow.setText(getString(R.string.search_mode) + "："
                + getString(prefs.searchMode() == 1 ? R.string.search_ball_label : R.string.search_bar));
        searchRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] names = {
                        getString(R.string.search_bar),
                        getString(R.string.search_ball_label)
                };
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.search_mode)
                        .setSingleChoiceItems(names, prefs.searchMode(), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                prefs.setSearchMode(which);
                                searchRow.setText(getString(R.string.search_mode) + "：" + names[which]);
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        });

        final TextView sortRow = findViewById(R.id.sort_row);
        sortRow.setText(getString(R.string.sort_mode) + "：" + SortUtil.label(this, prefs.sortMode()));
        sortRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] options = {
                        getString(R.string.sort_title),
                        getString(R.string.sort_title_desc),
                        getString(R.string.sort_artist),
                        getString(R.string.sort_album),
                        getString(R.string.sort_duration_asc),
                        getString(R.string.sort_duration_desc),
                        getString(R.string.sort_added),
                        getString(R.string.sort_played),
                        getString(R.string.sort_recent),
                        getString(R.string.sort_folder)
                };
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.sort_mode)
                        .setSingleChoiceItems(options, prefs.sortMode(), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                prefs.setSortMode(which);
                                sortRow.setText(getString(R.string.sort_mode) + "："
                                        + SortUtil.label(AdvancedSettingsActivity.this, which));
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        });

        Switch motion = findViewById(R.id.sw_motion);
        motion.setChecked(prefs.reduceMotion());
        motion.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton button, boolean checked) {
                prefs.setReduceMotion(checked);
            }
        });

        findViewById(R.id.clear_stats).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(AdvancedSettingsActivity.this)
                        .setTitle(R.string.clear_stats)
                        .setMessage(R.string.clear_stats_msg)
                        .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                prefs.clearStats();
                                Toast.makeText(AdvancedSettingsActivity.this, R.string.cleared, Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
        });
        findViewById(R.id.clear_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArtLoader.clearMemory();
                ArtLoader.clearDisk(AdvancedSettingsActivity.this);
                Toast.makeText(AdvancedSettingsActivity.this, R.string.cleaned, Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.duplicates_row).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdvancedSettingsActivity.this, DuplicatesActivity.class));
            }
        });
        findViewById(R.id.cleanup_row).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cleanupMissing();
            }
        });
        findViewById(R.id.import_data).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                importData();
            }
        });
        findViewById(R.id.export_data).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportData();
            }
        });
        findViewById(R.id.diagnostics).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDiagnostics();
            }
        });

        findViewById(R.id.hidden_entry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new android.content.Intent(AdvancedSettingsActivity.this, HiddenActivity.class));
            }
        });

        TextView about = findViewById(R.id.about);
        about.setText(getString(R.string.about_msg) + "\nAndroid " + Build.VERSION.RELEASE);
    }


    private void showEqualizerDialog() {
        final String[] names = {
                getString(R.string.eq_off),
                getString(R.string.eq_pop),
                getString(R.string.eq_rock),
                getString(R.string.eq_classical),
                getString(R.string.eq_vocal),
                getString(R.string.eq_bass),
                getString(R.string.eq_custom)
        };
        int preset = service.getEqualizerPreset();
        int current = preset < 0 ? 0 : (preset == 6 ? 6 : preset + 1);
        new AlertDialog.Builder(this)
                .setTitle(R.string.equalizer)
                .setSingleChoiceItems(names, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 6) {
                            showCustomBands();
                        } else {
                            service.setEqualizerPreset(which - 1);
                        }
                        dialog.dismiss();
                    }
                })
                .show();
    }

    private void showCustomBands() {
        final short count = service.getBandCount();
        final short[] range = service.getBandRange();
        short[] levels = service.getBandLevels();
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, pad / 2);
        final SeekBar[] bars = new SeekBar[count];
        for (int i = 0; i < count; i++) {
            TextView label = new TextView(this);
            label.setText("Band " + (i + 1));
            label.setTextSize(11);
            label.setTextColor(0xFF888888);
            box.addView(label);
            SeekBar bar = new SeekBar(this);
            bar.setMax(range[1] - range[0]);
            bar.setProgress(levels[i] - range[0]);
            bars[i] = bar;
            box.addView(bar);
        }
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(R.string.eq_custom)
                .setView(scroll)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        short[] values = new short[bars.length];
                        for (int i = 0; i < bars.length; i++) {
                            values[i] = (short) (bars[i].getProgress() + range[0]);
                        }
                        service.setCustomBands(values);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
    private void cleanupMissing() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Track> kept = new ArrayList<>();
                int removed = 0;
                for (Track track : SafStore.tracks(AdvancedSettingsActivity.this)) {
                    try {
                        java.io.InputStream in = getContentResolver()
                                .openInputStream(android.net.Uri.parse(track.uri));
                        if (in != null) {
                            in.close();
                            kept.add(track);
                        } else {
                            removed++;
                        }
                    } catch (Exception e) {
                        removed++;
                    }
                }
                SafStore.setTracks(AdvancedSettingsActivity.this, kept);
                prefs.markLibraryChanged();
                final int count = removed;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            Toast.makeText(AdvancedSettingsActivity.this,
                                    getString(R.string.cleanup_done, count), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void exportData() {
        try {
            JSONObject root = new JSONObject();
            root.put("app", "sfl");
            root.put("backup_version", 2);
            root.put("created", System.currentTimeMillis());
            root.put("prefs", prefs.exportAll());
            JSONArray playlists = new JSONArray();
            for (Playlist playlist : PlaylistStore.load(this)) {
                playlists.put(playlist.toJson());
            }
            root.put("playlists", playlists);
            JSONObject art = new JSONObject();
            File artDir = new File(getFilesDir(), "custom_art");
            File[] files = artDir.listFiles();
            long total = 0;
            if (files != null) {
                for (File file : files) {
                    if (!file.isFile() || total + file.length() > 12L * 1024 * 1024) {
                        continue;
                    }
                    byte[] bytes = new byte[(int) file.length()];
                    java.io.FileInputStream in = new java.io.FileInputStream(file);
                    int read = in.read(bytes);
                    in.close();
                    if (read > 0) {
                        art.put(file.getName(), android.util.Base64.encodeToString(
                                bytes, android.util.Base64.NO_WRAP));
                        total += read;
                    }
                }
            }
            root.put("art", art);
            pendingExport = root.toString(2);
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "sfl-backup-" + System.currentTimeMillis() + ".json");
            startActivityForResult(intent, REQ_EXPORT);
        } catch (Exception e) {
            Toast.makeText(this, R.string.export_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void importData() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void applyBackup(String text) {
        try {
            JSONObject root = new JSONObject(text);
            JSONObject prefsJson = root.optJSONObject("prefs");
            if (prefsJson == null) {
                Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.importAll(prefsJson);
            JSONObject art = root.optJSONObject("art");
            if (art != null) {
                File artDir = new File(getFilesDir(), "custom_art");
                artDir.mkdirs();
                java.util.Iterator<String> names = art.keys();
                while (names.hasNext()) {
                    String name = names.next();
                    try {
                        byte[] bytes = android.util.Base64.decode(
                                art.optString(name), android.util.Base64.NO_WRAP);
                        File file = new File(artDir, name);
                        java.io.FileOutputStream out = new java.io.FileOutputStream(file);
                        out.write(bytes);
                        out.close();
                    } catch (Exception ignored) {
                        // 跳过损坏封面
                    }
                }
            }
            JSONArray playlists = root.optJSONArray("playlists");
            if (playlists != null) {
                ArrayList<Playlist> list = new ArrayList<>();
                for (int i = 0; i < playlists.length(); i++) {
                    JSONObject item = playlists.optJSONObject(i);
                    if (item != null) {
                        list.add(Playlist.fromJson(item));
                    }
                }
                PlaylistStore.save(this, list);
            }
            prefs.markLibraryChanged();
            Toast.makeText(this, R.string.import_done, Toast.LENGTH_SHORT).show();
            recreate();
        } catch (Exception e) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void showDiagnostics() {
        StringBuilder info = new StringBuilder();
        info.append("Sfl Player ").append(versionName()).append('\n');
        info.append("Android ").append(android.os.Build.VERSION.RELEASE)
                .append(" (API ").append(android.os.Build.VERSION.SDK_INT).append(")\n");
        info.append(android.os.Build.MANUFACTURER).append(' ')
                .append(android.os.Build.MODEL).append("\n\n");
        info.append(getString(R.string.diagnostics_favorites, prefs.favorites().size())).append('\n');
        info.append(getString(R.string.diagnostics_hidden, prefs.hiddenTracks().size())).append('\n');
        info.append(getString(R.string.diagnostics_cache, ArtLoader.diskSize(this) / 1024)).append('\n');
        info.append(getString(R.string.diagnostics_permission,
                getString(hasAudioPermission() ? R.string.authorized : R.string.unauthorized)));
        new AlertDialog.Builder(this)
                .setTitle(R.string.diagnostics)
                .setMessage(info.toString())
                .setPositiveButton(R.string.close, null)
                .show();
    }

    private void updateNotificationRow(TextView row) {
        String status;
        if (Build.VERSION.SDK_INT < 33) {
            status = getString(R.string.notification_not_needed);
        } else if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status = getString(R.string.notification_allowed);
        } else {
            status = getString(R.string.notification_denied);
        }
        row.setText(getString(R.string.notification_permission) + "：" + status);
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "4.0.0";
        }
    }

    private boolean hasAudioPermission() {
        String permission = android.os.Build.VERSION.SDK_INT >= 33
                ? android.Manifest.permission.READ_MEDIA_AUDIO
                : android.Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            try {
                java.io.InputStream in = getContentResolver().openInputStream(data.getData());
                java.io.BufferedReader reader = new java.io.BufferedReader(
                        new java.io.InputStreamReader(in, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                reader.close();
                pendingImport = sb.toString();
                new AlertDialog.Builder(this)
                        .setTitle(R.string.import_data)
                        .setMessage(R.string.import_confirm)
                        .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                applyBackup(pendingImport);
                                pendingImport = null;
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            } catch (Exception e) {
                Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (requestCode != REQ_EXPORT || resultCode != RESULT_OK || data == null
                || data.getData() == null || pendingExport == null) {
            return;
        }
        try {
            OutputStream out = getContentResolver().openOutputStream(data.getData());
            if (out != null) {
                out.write(pendingExport.getBytes("UTF-8"));
                out.close();
            }
            Toast.makeText(this, R.string.export_done, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.export_failed, Toast.LENGTH_SHORT).show();
        } finally {
            pendingExport = null;
        }
    }
}
