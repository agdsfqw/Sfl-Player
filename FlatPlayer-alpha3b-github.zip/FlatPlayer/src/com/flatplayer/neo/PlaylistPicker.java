package com.flatplayer.neo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** 选择歌单并加入（支持现场新建）。 */
public final class PlaylistPicker {

    private PlaylistPicker() {
    }

    public static void show(final Activity activity, final List<String> uris) {
        final ArrayList<Playlist> playlists = PlaylistStore.load(activity);
        final String[] names = new String[playlists.size() + 1];
        for (int i = 0; i < playlists.size(); i++) {
            names[i] = playlists.get(i).name;
        }
        names[playlists.size()] = activity.getString(R.string.new_playlist) + "…";

        new AlertDialog.Builder(activity)
                .setTitle(R.string.choose_playlist)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == playlists.size()) {
                            PlaylistDialogs.showEdit(activity, null, new PlaylistDialogs.Callback() {
                                @Override
                                public void onSaved(Playlist playlist) {
                                    playlists.add(playlist);
                                    boolean added = addUris(playlist, uris);
                                    PlaylistStore.save(activity, playlists);
                                    toast(activity, added);
                                }
                            });
                        } else {
                            Playlist playlist = playlists.get(which);
                            boolean added = addUris(playlist, uris);
                            PlaylistStore.save(activity, playlists);
                            toast(activity, added);
                        }
                    }
                })
                .show();
    }

    private static boolean addUris(Playlist playlist, List<String> uris) {
        boolean added = false;
        for (String uri : uris) {
            if (uri == null || playlist.uris.contains(uri)) {
                continue;
            }
            playlist.uris.add(uri);
            added = true;
        }
        return added;
    }

    private static void toast(Activity activity, boolean added) {
        Toast.makeText(activity,
                activity.getString(added ? R.string.added_to_playlist : R.string.already_in_playlist),
                Toast.LENGTH_SHORT).show();
    }
}
