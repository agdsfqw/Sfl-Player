package com.flatplayer.neo;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/** 歌单详情：播放全部、移除歌曲、编辑/删除。 */
public class PlaylistDetailActivity extends PlayerBindActivity {

    public static final String EXTRA_ID = "playlist_id";

    private static final int REQ_ADD = 35;
    private static final int REQ_EXPORT_M3U = 36;

    private final ArrayList<Track> tracks = new ArrayList<>();
    private Playlist playlist;
    private SimpleTrackAdapter adapter;
    private String playlistId;
    private String pendingM3u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist_detail);
        playlistId = getIntent().getStringExtra(EXTRA_ID);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.export_m3u).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportM3u();
            }
        });
        findViewById(R.id.add_songs).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(PlaylistDetailActivity.this, TrackPickerActivity.class),
                        REQ_ADD);
            }
        });
        findViewById(R.id.edit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (playlist == null) {
                    return;
                }
                PlaylistDialogs.showEdit(PlaylistDetailActivity.this, playlist,
                        new PlaylistDialogs.Callback() {
                            @Override
                            public void onSaved(Playlist saved) {
                                saveAll();
                                bindHeader();
                            }
                        });
            }
        });
        findViewById(R.id.play_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playQueue(tracks, 0);
            }
        });

        ListView list = findViewById(R.id.d_list);
        adapter = new SimpleTrackAdapter(this, true);
        list.setAdapter(adapter);
        ScrollPause.attach(list, adapter);
        list.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, android.view.DragEvent event) {
                if (event.getAction() == android.view.DragEvent.ACTION_DROP) {
                    int to = list.pointToPosition((int) event.getX(), (int) event.getY());
                    int from = adapter.getDragFrom();
                    if (from >= 0 && to >= 0 && from != to) {
                        moveTrackTo(from, to);
                    }
                    adapter.setDragFrom(-1);
                }
                return true;
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                playQueue(tracks, position);
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final String[] items = {
                        getString(R.string.move_up),
                        getString(R.string.move_down),
                        getString(R.string.remove_from_playlist)
                };
                new AlertDialog.Builder(PlaylistDetailActivity.this)
                        .setTitle(tracks.get(position).title)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    moveTrack(position, -1);
                                } else if (which == 1) {
                                    moveTrack(position, 1);
                                } else {
                                    removeTrack(position);
                                }
                            }
                        })
                        .show();
                return true;
            }
        });

        load();
    }

    private void load() {
        Playlist found = null;
        for (Playlist item : PlaylistStore.load(this)) {
            if (item.id.equals(playlistId)) {
                found = item;
                break;
            }
        }
        if (found == null) {
            finish();
            return;
        }
        playlist = found;
        new Thread(new Runnable() {
            @Override
            public void run() {
                HashMap<String, Track> map = new HashMap<>();
                for (Track track : Library.loadAll(PlaylistDetailActivity.this)) {
                    map.put(track.uri, track);
                }
                final ArrayList<Track> result = new ArrayList<>();
                for (String uri : playlist.uris) {
                    Track track = map.get(uri);
                    if (track != null) {
                        result.add(track);
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tracks.clear();
                        tracks.addAll(result);
                        adapter.setTracks(tracks);
                        bindHeader();
                    }
                });
            }
        }).start();
    }

    private void bindHeader() {
        if (playlist == null) {
            return;
        }
        TextView title = findViewById(R.id.d_title);
        TextView note = findViewById(R.id.d_note);
        TextView meta = findViewById(R.id.d_meta);
        title.setText(playlist.name);
        note.setText(playlist.note == null || playlist.note.isEmpty() ? getString(R.string.no_note) : playlist.note);
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA)
                .format(new Date(playlist.createdAt));
        meta.setText(getString(R.string.playlist_meta, playlist.uris.size(), time));

        ImageView cover = findViewById(R.id.p_cover);
        final TextView tile = findViewById(R.id.p_tile);
        Tiles.apply(tile, playlist.name, false);
        if (!tracks.isEmpty()) {
            final String uri = tracks.get(0).uri;
            cover.setTag(uri);
            ArtLoader.load(this, uri, 400, new ArtLoader.Callback() {
                @Override
                public void onArt(String u, Bitmap bitmap) {
                    if (bitmap != null && uri.equals(cover.getTag())) {
                        cover.setImageBitmap(bitmap);
                        tile.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    private void moveTrackTo(int from, int to) {
        if (from < 0 || to < 0 || from >= tracks.size() || to >= tracks.size()) {
            return;
        }
        Track track = tracks.remove(from);
        tracks.add(to, track);
        playlist.uris.clear();
        for (Track item : tracks) {
            playlist.uris.add(item.uri);
        }
        saveAll();
        adapter.setTracks(tracks);
    }

    private void moveTrack(int position, int delta) {
        int target = position + delta;
        if (target < 0 || target >= tracks.size()) {
            return;
        }
        Track track = tracks.remove(position);
        tracks.add(target, track);
        playlist.uris.clear();
        for (Track item : tracks) {
            playlist.uris.add(item.uri);
        }
        saveAll();
        adapter.setTracks(tracks);
    }

    private void removeTrack(int position) {
        String uri = tracks.get(position).uri;
        playlist.uris.remove(uri);
        saveAll();
        load();
        Toast.makeText(this, R.string.remove_from_playlist, Toast.LENGTH_SHORT).show();
    }

    private void exportM3u() {
        if (playlist == null) {
            return;
        }
        StringBuilder sb = new StringBuilder("#EXTM3U\n");
        for (Track track : tracks) {
            sb.append("#EXTINF:").append(track.duration / 1000).append(',')
                    .append(track.artist).append(" - ").append(track.title).append('\n');
            String path = track.relativePath == null ? "" : track.relativePath;
            if (path.isEmpty() || track.displayName == null) {
                sb.append(track.uri);
            } else {
                sb.append("/storage/emulated/0/").append(path).append(track.displayName);
            }
            sb.append('\n');
        }
        pendingM3u = sb.toString();
        android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        intent.setType("audio/x-mpegurl");
        intent.putExtra(android.content.Intent.EXTRA_TITLE, playlist.name + ".m3u");
        startActivityForResult(intent, REQ_EXPORT_M3U);
    }

    private void saveAll() {
        ArrayList<Playlist> all = PlaylistStore.load(this);
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(playlist.id)) {
                all.set(i, playlist);
                break;
            }
        }
        PlaylistStore.save(this, all);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT_M3U && resultCode == RESULT_OK && data != null
                && data.getData() != null && pendingM3u != null) {
            try {
                java.io.OutputStream out = getContentResolver().openOutputStream(data.getData());
                if (out != null) {
                    out.write(pendingM3u.getBytes("UTF-8"));
                    out.close();
                }
                Toast.makeText(this, R.string.export_done, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, R.string.export_failed, Toast.LENGTH_SHORT).show();
            } finally {
                pendingM3u = null;
            }
            return;
        }
        if (requestCode != REQ_ADD || resultCode != RESULT_OK || data == null) {
            return;
        }
        java.util.ArrayList<String> uris = data.getStringArrayListExtra("uris");
        if (uris == null || uris.isEmpty() || playlist == null) {
            return;
        }
        boolean added = false;
        for (String uri : uris) {
            if (uri != null && !playlist.uris.contains(uri)) {
                playlist.uris.add(uri);
                added = true;
            }
        }
        if (added) {
            saveAll();
            load();
            Toast.makeText(this, R.string.added_to_playlist, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.already_in_playlist, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }
}
