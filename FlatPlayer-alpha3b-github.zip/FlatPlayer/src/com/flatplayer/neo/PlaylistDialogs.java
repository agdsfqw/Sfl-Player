package com.flatplayer.neo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

/** 歌单新建 / 编辑弹窗。 */
public final class PlaylistDialogs {

    public interface Callback {
        void onSaved(Playlist playlist);
    }

    private PlaylistDialogs() {
    }

    public static void showEdit(final Activity activity, final Playlist existing, final Callback callback) {
        View content = LayoutInflater.from(activity).inflate(R.layout.dialog_playlist_edit, null);
        final EditText nameInput = content.findViewById(R.id.name_input);
        final EditText noteInput = content.findViewById(R.id.note_input);
        if (existing != null) {
            nameInput.setText(existing.name);
            noteInput.setText(existing.note);
        }

        new AlertDialog.Builder(activity)
                .setTitle(existing == null ? R.string.new_playlist : R.string.edit)
                .setView(content)
                .setPositiveButton(existing == null ? R.string.create : R.string.save,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String name = nameInput.getText().toString().trim();
                                if (name.isEmpty()) {
                                    name = activity.getString(R.string.unnamed_playlist);
                                }
                                String note = noteInput.getText().toString().trim();
                                Playlist playlist;
                                if (existing == null) {
                                    playlist = Playlist.create(name, note);
                                } else {
                                    existing.name = name;
                                    existing.note = note;
                                    playlist = existing;
                                }
                                callback.onSaved(playlist);
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
