package com.flatplayer.neo;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/** 统一处理主题：跟随系统 / 强制浅色 / 强制深色。 */
public abstract class BaseActivity extends Activity {

    private boolean appliedDark;
    private int appliedHue;
    private int appliedBg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Prefs prefs = new Prefs(this);
        boolean dark;
        int mode = prefs.theme();
        if (mode == Prefs.THEME_LIGHT) {
            dark = false;
        } else if (mode == Prefs.THEME_DARK) {
            dark = true;
        } else {
            int uiMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            dark = uiMode == Configuration.UI_MODE_NIGHT_YES;
        }
        appliedDark = dark;
        appliedHue = prefs.accentHue();
        appliedBg = prefs.backgroundPreset();
        setTheme(dark ? R.style.Theme_Sfl_Dark : R.style.Theme_Sfl_Light);
        applyOverlays(dark, appliedBg, appliedHue);
        super.onCreate(savedInstanceState);
        if (prefs.animationLevel() == 0) {
            getWindow().setWindowAnimations(0);
        }
        try {
            applyEdgeToEdge();
        } catch (Throwable ignored) {
            // 全屏适配失败时退回系统默认布局
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Prefs prefs = new Prefs(this);
        if (isDark() != appliedDark || prefs.accentHue() != appliedHue
                || prefs.backgroundPreset() != appliedBg) {
            recreate();
        }
    }

    private void applyOverlays(boolean dark, int background, int hue) {
        try {
            int bg = Math.max(0, Math.min(2, background));
            int bgRes = getResources().getIdentifier(
                    "Bg" + (dark ? "D" : "L") + bg, "style", getPackageName());
            if (bgRes != 0) {
                getTheme().applyStyle(bgRes, true);
            }
            int h = ((hue % 360) + 360) % 360;
            int accentRes = getResources().getIdentifier(
                    (dark ? "AccentD_" : "AccentL_") + h, "style", getPackageName());
            if (accentRes != 0) {
                getTheme().applyStyle(accentRes, true);
            }
        } catch (Throwable ignored) {
            // 主题叠加失败时退回基础主题
        }
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        requestInsets();
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        requestInsets();
    }

    private void requestInsets() {
        View content = findViewById(android.R.id.content);
        if (content != null) {
            content.requestApplyInsets();
        }
    }

    private void applyEdgeToEdge() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.setBackgroundDrawable(new ColorDrawable(themeColor(R.attr.colorBg)));
        boolean dark = isDark();
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        } else {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (!dark && Build.VERSION.SDK_INT >= 23) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (!dark && Build.VERSION.SDK_INT >= 26) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(params);
        }
        final View content = findViewById(android.R.id.content);
        content.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public android.view.WindowInsets onApplyWindowInsets(View v,
                    android.view.WindowInsets insets) {
                try {
                    onApplyInsets(insets.getSystemWindowInsetLeft(),
                            insets.getSystemWindowInsetTop(),
                            insets.getSystemWindowInsetRight(),
                            insets.getSystemWindowInsetBottom());
                } catch (Throwable ignored) {
                    // 布局失败不影响启动
                }
                return insets;
            }
        });
        content.requestApplyInsets();
    }

    /** 默认给内容层加安全区；需要背景铺满的页面可以覆写。 */
    protected void onApplyInsets(int left, int top, int right, int bottom) {
        View content = findViewById(android.R.id.content);
        if (content != null) {
            content.setPadding(left, top, right, bottom);
        }
    }

    private int themeColor(int attr) {
        android.util.TypedValue value = new android.util.TypedValue();
        getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    private boolean isDark() {
        Prefs prefs = new Prefs(this);
        int mode = prefs.theme();
        if (mode == Prefs.THEME_LIGHT) {
            return false;
        }
        if (mode == Prefs.THEME_DARK) {
            return true;
        }
        int uiMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return uiMode == Configuration.UI_MODE_NIGHT_YES;
    }
}
