package com.flatplayer.neo;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;

/** 弹窗毛玻璃/亚克力：用当前界面快照做窗口背景，前面盖一层半透明底色。 */
public final class GlassDialogs {

    private GlassDialogs() {
    }

    public static void apply(final Activity activity, final Dialog dialog) {
        if (activity == null || dialog == null) {
            return;
        }
        final Prefs prefs = new Prefs(activity);
        int level = prefs.frostedGlass();
        if (level < 0) {
            boolean lowRam = ((android.app.ActivityManager) activity
                    .getSystemService(Activity.ACTIVITY_SERVICE)).isLowRamDevice();
            level = lowRam ? 0 : 2;
        }
        if (level <= 0) {
            return;
        }
        final Window window = dialog.getWindow();
        if (window == null) {
            return;
        }
        final boolean acrylic = prefs.glassMaterial() == 1;
        final int radius = acrylic
                ? (level >= 3 ? 10 : level == 2 ? 6 : 3)
                : (level >= 3 ? 18 : level == 2 ? 10 : 5);
        final int surface = themeColor(activity, R.attr.colorSurface);
        window.setDimAmount(0.15f);
        Blur.blurView(activity.getWindow().getDecorView(), radius, new Blur.Callback() {
            @Override
            public void onBlur(android.graphics.Bitmap bitmap) {
                if (bitmap == null || activity.isFinishing() || window.getDecorView() == null) {
                    return;
                }
                try {
                    if (acrylic) {
                        Blur.acrylic(bitmap, surface, 0.16f, 0.025f);
                    }
                    BitmapDrawable image = new BitmapDrawable(activity.getResources(), bitmap);
                    Drawable overlay = new ColorDrawable(Color.argb(acrylic ? 205 : 228,
                            Color.red(surface), Color.green(surface), Color.blue(surface)));
                    window.setBackgroundDrawable(new LayerDrawable(new Drawable[]{image, overlay}));
                } catch (Throwable ignored) {
                    // 窗口已销毁
                }
            }
        });
    }

    /** 自定义布局的弹窗：内容面板改成半透明圆角，边缘露出毛玻璃。 */
    public static void styleContent(Activity activity, View content) {
        if (activity == null || content == null) {
            return;
        }
        int surface = themeColor(activity, R.attr.colorSurface);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.argb(242, Color.red(surface),
                Color.green(surface), Color.blue(surface)));
        background.setCornerRadius(dp(activity, 18));
        content.setBackground(background);
    }

    private static int themeColor(Activity activity, int attr) {
        TypedValue value = new TypedValue();
        activity.getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    private static int dp(Activity activity, int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                activity.getResources().getDisplayMetrics());
    }
}
