package com.flatplayer.neo;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** 播放页面 / 音频 / 文件 / 语言四个分类页。 */
public class SettingsCategoryActivity extends BaseActivity {

    public static final String EXTRA_CATEGORY = "category";
    public static final int CATEGORY_PLAYER = 1;
    public static final int CATEGORY_AUDIO = 2;
    public static final int CATEGORY_FILES = 3;
    public static final int CATEGORY_LANGUAGE = 4;

    private Prefs prefs;
    private LinearLayout list;
    private int category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_category);
        prefs = new Prefs(this);
        category = getIntent().getIntExtra(EXTRA_CATEGORY, CATEGORY_PLAYER);
        ((TextView) findViewById(R.id.category_title)).setText(categoryTitle());
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        list = findViewById(R.id.category_list);
        build();
    }

    private int categoryTitle() {
        switch (category) {
            case CATEGORY_AUDIO:
                return R.string.settings_audio;
            case CATEGORY_FILES:
                return R.string.settings_files;
            case CATEGORY_LANGUAGE:
                return R.string.settings_language;
            case CATEGORY_PLAYER:
            default:
                return R.string.settings_player_page;
        }
    }

    private void build() {
        if (category == CATEGORY_PLAYER) {
            playerPage();
        } else if (category == CATEGORY_AUDIO) {
            audioPage();
        } else if (category == CATEGORY_FILES) {
            filesPage();
        } else {
            languagePage();
        }
    }

    private void playerPage() {
        list.addView(SettingsUi.row(this, getString(R.string.lyric_font_size) + "："
                + prefs.lyricFontSize() + "sp", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLyricFont();
            }
        }));
        list.addView(SettingsUi.switchRow(this, getString(R.string.player_bg_blur),
                prefs.playerBlur(), new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                        prefs.setPlayerBlur(isChecked);
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.fade_switch) + "："
                + getString(R.string.fade_fmt, prefs.fadeSeconds()), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFade();
            }
        }));
        list.addView(SettingsUi.row(this, getString(R.string.equalizer), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAdvanced();
            }
        }));
    }

    private void audioPage() {
        list.addView(SettingsUi.row(this, getString(R.string.equalizer), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAdvanced();
            }
        }));
        list.addView(SettingsUi.switchRow(this, getString(R.string.resume), prefs.resume(),
                new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                        prefs.setResume(isChecked);
                    }
                }));
        list.addView(SettingsUi.switchRow(this, getString(R.string.headset), prefs.headset(),
                new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                        prefs.setHeadset(isChecked);
                    }
                }));
        list.addView(SettingsUi.switchRow(this, getString(R.string.confirm_single_switch),
                prefs.confirmSingle(), new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                        prefs.setConfirmSingle(isChecked);
                    }
                }));
    }

    private void filesPage() {
        list.addView(SettingsUi.row(this, getString(R.string.folders), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsCategoryActivity.this, FolderActivity.class));
            }
        }));
        list.addView(SettingsUi.row(this, getString(R.string.hidden_songs), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsCategoryActivity.this, HiddenActivity.class));
            }
        }));
        list.addView(SettingsUi.row(this, getString(R.string.duplicates), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsCategoryActivity.this, DuplicatesActivity.class));
            }
        }));
        list.addView(SettingsUi.row(this, getString(R.string.export_data) + " / "
                + getString(R.string.import_data), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAdvanced();
            }
        }));
    }

    private void languagePage() {
        list.addView(SettingsUi.switchRow(this, getString(R.string.color_blind), prefs.colorBlind(),
                new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                        prefs.setColorBlind(isChecked);
                        if (isChecked) {
                            Toast.makeText(SettingsCategoryActivity.this,
                                    R.string.color_blind_hint, Toast.LENGTH_SHORT).show();
                        }
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.font_scale_info,
                getResources().getConfiguration().fontScale), null));
        list.addView(SettingsUi.row(this, getString(R.string.language_follow), null));
    }

    private void showLyricFont() {
        final int[] value = {prefs.lyricFontSize()};
        LinearLayout box = dialogBox();
        final TextView label = new TextView(this);
        label.setText(value[0] + "sp");
        box.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(16);
        bar.setProgress(value[0] - 12);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value[0] = 12 + progress;
                label.setText(value[0] + "sp");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        box.addView(bar);
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.lyric_font_size)
                .setView(box)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.setLyricFontSize(value[0]);
                        recreate();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showFade() {
        final float[] value = {prefs.fadeSeconds()};
        LinearLayout box = dialogBox();
        final TextView label = new TextView(this);
        label.setText(getString(R.string.fade_fmt, value[0]));
        box.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(30);
        bar.setProgress(Math.round(value[0] * 10));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value[0] = progress / 10f;
                label.setText(getString(R.string.fade_fmt, value[0]));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        box.addView(bar);
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.fade_switch)
                .setView(box)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.setFadeSeconds(value[0]);
                        recreate();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private LinearLayout dialogBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(SettingsUi.dp(this, 20), SettingsUi.dp(this, 8),
                SettingsUi.dp(this, 20), 0);
        return box;
    }

    private void openAdvanced() {
        startActivity(new Intent(this, AdvancedSettingsActivity.class));
    }
}
