package com.flatplayer.neo;

import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

/** 个性化：主题、底色、强调色、材质、动画、预设与重置。 */
public class PersonalizationActivity extends BaseActivity {

    private Prefs prefs;
    private ThemeManager theme;
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_category);
        prefs = new Prefs(this);
        theme = new ThemeManager(this);
        ((TextView) findViewById(R.id.category_title)).setText(R.string.settings_personalization);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        list = findViewById(R.id.category_list);
        build();
    }

    private void build() {
        list.removeAllViews();
        list.addView(SettingsUi.row(this, getString(R.string.theme) + "：" + themeName(),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showTheme();
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.bg_color) + "：" + backgroundName(),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showBackground();
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.accent) + "：" + getString(R.string.hue_fmt,
                prefs.accentHue()), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAccent();
            }
        }));
        list.addView(materialRow());
        list.addView(SettingsUi.row(this, getString(R.string.frosted_glass) + "：" + glassName(),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showGlass();
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.animation_level) + "：" + animationName(),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showAnimation();
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.presets),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showPresets();
                    }
                }));
        SettingsUi.divider(this, list);
        list.addView(SettingsUi.row(this, getString(R.string.reset_default),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        confirmReset();
                    }
                }));
    }

    private View materialRow() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(SettingsUi.dp(this, 20), SettingsUi.dp(this, 10),
                SettingsUi.dp(this, 20), SettingsUi.dp(this, 10));
        TextView label = new TextView(this);
        label.setText(R.string.material);
        label.setTextSize(15);
        label.setTextColor(SettingsUi.color(this, R.attr.colorText));
        box.addView(label);
        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton acrylic = new RadioButton(this);
        acrylic.setText(R.string.material_acrylic);
        acrylic.setId(View.generateViewId());
        RadioButton frosted = new RadioButton(this);
        frosted.setText(R.string.material_blur);
        frosted.setId(View.generateViewId());
        group.addView(acrylic);
        group.addView(frosted);
        group.check(prefs.glassMaterial() == 1 ? acrylic.getId() : frosted.getId());
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                theme.setMaterial(checkedId == acrylic.getId() ? 1 : 0);
                recreate();
            }
        });
        box.addView(group);
        return box;
    }

    private void showTheme() {
        final String[] names = {getString(R.string.theme_follow), getString(R.string.theme_light),
                getString(R.string.theme_dark)};
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.theme)
                .setSingleChoiceItems(names, prefs.theme(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.setTheme(which);
                        recreate();
                    }
                })
                .show();
    }

    private void showBackground() {
        final String[] names = backgroundNames();
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.bg_color)
                .setSingleChoiceItems(names, prefs.backgroundPreset(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.setBackgroundPreset(which);
                        recreate();
                    }
                })
                .show();
    }

    private void showAccent() {
        final int[] hue = {prefs.accentHue()};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(SettingsUi.dp(this, 20), SettingsUi.dp(this, 8), SettingsUi.dp(this, 20), 0);
        final TextView label = new TextView(this);
        label.setText(getString(R.string.hue_fmt, hue[0]));
        box.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(359);
        bar.setProgress(hue[0]);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                hue[0] = progress;
                label.setText(getString(R.string.hue_fmt, progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        box.addView(bar);
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.accent)
                .setView(box)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.setAccentHue(hue[0]);
                        recreate();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showGlass() {
        final String[] names = {getString(R.string.glass_off), getString(R.string.glass_light),
                getString(R.string.glass_standard), getString(R.string.glass_strong)};
        int current = prefs.frostedGlass();
        if (current < 0) {
            current = 2;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.frosted_glass)
                .setSingleChoiceItems(names, current, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.setFrostedGlass(which);
                        recreate();
                    }
                })
                .show();
    }

    private void showAnimation() {
        final String[] names = {getString(R.string.anim_off), getString(R.string.anim_fast),
                getString(R.string.anim_medium), getString(R.string.anim_elegant)};
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.animation_level)
                .setSingleChoiceItems(names, theme.animationLevel(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        theme.setAnimationLevel(which);
                        recreate();
                    }
                })
                .show();
    }

    private void showPresets() {
        final String[] names = {getString(R.string.preset_default), getString(R.string.preset_performance),
                getString(R.string.preset_beauty), getString(R.string.preset_low_end)};
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.presets)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        theme.applyPreset(which);
                        recreate();
                    }
                })
                .show();
    }

    private void confirmReset() {
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.reset_default)
                .setMessage(R.string.reset_confirm)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        theme.resetVisuals();
                        recreate();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private String themeName() {
        int theme = prefs.theme();
        return getString(theme == Prefs.THEME_LIGHT ? R.string.theme_light
                : theme == Prefs.THEME_DARK ? R.string.theme_dark : R.string.theme_follow);
    }

    private String backgroundName() {
        return backgroundNames()[Math.max(0, Math.min(2, prefs.backgroundPreset()))];
    }

    private String[] backgroundNames() {
        boolean dark = prefs.theme() == Prefs.THEME_DARK
                || (prefs.theme() == Prefs.THEME_FOLLOW
                && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES);
        return dark
                ? new String[]{getString(R.string.bg_deep_gray), getString(R.string.bg_black),
                getString(R.string.bg_blue_gray)}
                : new String[]{getString(R.string.bg_white), getString(R.string.bg_warm),
                getString(R.string.bg_light_gray)};
    }

    private String glassName() {
        int level = prefs.frostedGlass();
        if (level < 0) {
            level = 2;
        }
        return getString(level == 0 ? R.string.glass_off : level == 1 ? R.string.glass_light
                : level == 2 ? R.string.glass_standard : R.string.glass_strong);
    }

    private String animationName() {
        int level = theme.animationLevel();
        return getString(level == 0 ? R.string.anim_off : level == 1 ? R.string.anim_fast
                : level == 2 ? R.string.anim_medium : R.string.anim_elegant);
    }
}
