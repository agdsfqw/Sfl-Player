package com.flatplayer.neo;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** 设置页的通用行组件。 */
public final class SettingsUi {

    private SettingsUi() {
    }

    public static TextView row(Context context, String text, View.OnClickListener listener) {
        TextView row = new TextView(context);
        row.setText(text);
        row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        row.setTextColor(color(context, R.attr.colorText));
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinHeight(dp(context, 54));
        row.setPadding(dp(context, 20), dp(context, 14), dp(context, 20), dp(context, 14));
        row.setBackgroundResource(selectable(context));
        row.setOnClickListener(listener);
        return row;
    }

    public static LinearLayout switchRow(Context context, String text, boolean checked,
                                         android.widget.CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(context, 20), dp(context, 6), dp(context, 16), dp(context, 6));
        box.setBackgroundResource(selectable(context));
        TextView label = new TextView(context);
        label.setText(text);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        label.setTextColor(color(context, R.attr.colorText));
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        box.addView(label, labelParams);
        Switch toggle = new Switch(context);
        toggle.setChecked(checked);
        toggle.setOnCheckedChangeListener(listener);
        box.addView(toggle);
        return box;
    }

    public static void divider(Context context, LinearLayout parent) {
        View line = new View(context);
        line.setBackgroundColor(color(context, R.attr.colorDivider));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(context, 1)));
        params.leftMargin = dp(context, 20);
        params.rightMargin = dp(context, 20);
        parent.addView(line, params);
    }

    public static int color(Context context, int attr) {
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    public static int dp(Context context, int value) {
        return (int) (value * context.getResources().getDisplayMetrics().density);
    }

    private static int selectable(Context context) {
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, value, true);
        return value.resourceId;
    }
}
