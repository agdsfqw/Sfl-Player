package com.flatplayer.neo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 歌单列表：新建、编辑、删除、进入详情。 */
public class PlaylistActivity extends BaseActivity {

    private static final int REQ_IMPORT = 37;

    private final ArrayList<Playlist> playlists = new ArrayList<>();
    private ListView list;
    private TextView empty;
    private PlaylistAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);
        list = findViewById(R.id.playlist_list);
        empty = findViewById(R.id.playlist_empty);
        adapter = new PlaylistAdapter();
        list.setAdapter(adapter);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.import_m3u).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(intent, REQ_IMPORT);
            }
        });
        findViewById(R.id.new_playlist).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlaylistDialogs.showEdit(PlaylistActivity.this, null, new PlaylistDialogs.Callback() {
                    @Override
                    public void onSaved(Playlist playlist) {
                        playlists.add(playlist);
                        PlaylistStore.save(PlaylistActivity.this, playlists);
                        refresh();
                    }
                });
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 3) {
                    Intent smart = new Intent(PlaylistActivity.this, SmartListActivity.class);
                    smart.putExtra(SmartListActivity.EXTRA_TYPE, position);
                    startActivity(smart);
                    return;
                }
                Intent intent = new Intent(PlaylistActivity.this, PlaylistDetailActivity.class);
                intent.putExtra(PlaylistDetailActivity.EXTRA_ID, playlists.get(position - 3).id);
                startActivity(intent);
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                if (position < 3) {
                    return false;
                }
                final Playlist playlist = playlists.get(position - 3);
                String[] items = {getString(R.string.edit), getString(R.string.delete)};
                new AlertDialog.Builder(PlaylistActivity.this)
                        .setTitle(playlist.name)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    PlaylistDialogs.showEdit(PlaylistActivity.this, playlist,
                                            new PlaylistDialogs.Callback() {
                                                @Override
                                                public void onSaved(Playlist saved) {
                                                    PlaylistStore.save(PlaylistActivity.this, playlists);
                                                    refresh();
                                                }
                                            });
                                } else {
                                    confirmDelete(playlist, position);
                                }
                            }
                        })
                        .show();
                return true;
            }
        });

        load();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_IMPORT || resultCode != RESULT_OK || data == null
                || data.getData() == null) {
            return;
        }
        try {
            java.io.InputStream in = getContentResolver().openInputStream(data.getData());
            java.io.BufferedReader reader = new java.io.BufferedReader(
                    new java.io.InputStreamReader(in, "UTF-8"));
            ArrayList<String> paths = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    paths.add(line);
                }
            }
            reader.close();
            java.util.HashMap<String, Track> byName = new java.util.HashMap<>();
            for (Track track : Library.loadAll(this)) {
                if (track.displayName != null) {
                    byName.put(track.displayName.toLowerCase(), track);
                }
                byName.put(track.title.toLowerCase(), track);
            }
            Playlist playlist = Playlist.create(getString(R.string.m3u_playlist_name), getString(R.string.m3u_playlist_note));
            int matched = 0;
            for (String path : paths) {
                String name = path;
                int slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
                if (slash >= 0) {
                    name = path.substring(slash + 1);
                }
                Track track = byName.get(name.toLowerCase());
                if (track != null && !playlist.uris.contains(track.uri)) {
                    playlist.uris.add(track.uri);
                    matched++;
                }
            }
            playlists.add(playlist);
            PlaylistStore.save(this, playlists);
            refresh();
            android.widget.Toast.makeText(this,
                    getString(R.string.m3u_done, playlist.uris.size(), paths.size()),
                    android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "导入失败", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmDelete(final Playlist playlist, final int position) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_playlist)
                .setMessage(R.string.delete_playlist_msg)
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        playlists.remove(position);
                        PlaylistStore.save(PlaylistActivity.this, playlists);
                        refresh();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        playlists.clear();
        playlists.addAll(PlaylistStore.load(this));
        refresh();
    }

    private void refresh() {
        adapter.notifyDataSetChanged();
        empty.setVisibility(playlists.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private static String formatTime(long millis) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(new Date(millis));
    }

    private class PlaylistAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return 3 + playlists.size();
        }

        @Override
        public Playlist getItem(int position) {
            return position < 3 ? null : playlists.get(position - 3);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_playlist, parent, false);
            }
            if (position < 3) {
                TextView smartName = view.findViewById(R.id.p_name);
                TextView smartSub = view.findViewById(R.id.p_sub);
                ImageView smartCover = view.findViewById(R.id.p_cover);
                TextView smartTile = view.findViewById(R.id.p_tile);
                smartName.setText(position == 0 ? R.string.smart_recent
                        : position == 1 ? R.string.smart_most : R.string.smart_never);
                smartSub.setText(R.string.smart);
                smartCover.setTag("smart" + position);
                smartCover.setImageDrawable(null);
                Tiles.apply(smartTile, smartName.getText().toString(), false);
                smartTile.setVisibility(View.VISIBLE);
                return view;
            }
            final Playlist playlist = playlists.get(position - 3);
            TextView name = view.findViewById(R.id.p_name);
            TextView sub = view.findViewById(R.id.p_sub);
            final ImageView cover = view.findViewById(R.id.p_cover);
            final TextView tile = view.findViewById(R.id.p_tile);
            name.setText(playlist.name);
            sub.setText(getString(R.string.playlist_meta, playlist.uris.size(), formatTime(playlist.createdAt)));
            Tiles.apply(tile, playlist.name, false);
            if (!playlist.uris.isEmpty()) {
                final String uri = playlist.uris.get(0);
                cover.setTag(uri);
                ArtLoader.load(PlaylistActivity.this, uri, 256, new ArtLoader.Callback() {
                    @Override
                    public void onArt(String u, Bitmap bitmap) {
                        if (bitmap != null && uri.equals(cover.getTag())) {
                            cover.setImageBitmap(bitmap);
                            tile.setVisibility(View.GONE);
                        }
                    }
                });
            }
            return view;
        }
    }
}
