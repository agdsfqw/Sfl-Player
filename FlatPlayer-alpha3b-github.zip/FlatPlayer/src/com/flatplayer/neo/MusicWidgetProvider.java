package com.flatplayer.neo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** 4×2 桌面小部件：上一首/播放暂停/下一首。 */
public class MusicWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_REFRESH = "com.flatplayer.neo.WIDGET_REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            manager.updateAppWidget(id, build(context));
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            refresh(context);
        }
    }

    public static void refresh(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName name = new ComponentName(context, MusicWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(name);
            if (ids == null || ids.length == 0) {
                return;
            }
            RemoteViews views = build(context);
            for (int id : ids) {
                manager.updateAppWidget(id, views);
            }
        } catch (Throwable ignored) {
            // 小部件更新失败不影响播放
        }
    }

    private static RemoteViews build(Context context) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_music);
        Prefs prefs = new Prefs(context);
        views.setTextViewText(R.id.widget_title, prefs.widgetTitle());
        views.setTextViewText(R.id.widget_artist, prefs.widgetArtist());
        views.setImageViewResource(R.id.widget_toggle,
                prefs.widgetPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);

        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        views.setOnClickPendingIntent(R.id.widget_open, PendingIntent.getActivity(
                context, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        views.setOnClickPendingIntent(R.id.widget_prev, serviceAction(
                context, 2, PlayerService.ACTION_PREV));
        views.setOnClickPendingIntent(R.id.widget_toggle, serviceAction(
                context, 3, PlayerService.ACTION_TOGGLE));
        views.setOnClickPendingIntent(R.id.widget_next, serviceAction(
                context, 4, PlayerService.ACTION_NEXT));
        return views;
    }

    private static PendingIntent serviceAction(Context context, int request, String action) {
        Intent intent = new Intent(context, PlayerService.class);
        intent.setAction(action);
        return PendingIntent.getService(context, request, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
