package com.flatplayer.neo;

import android.content.ClipData;
import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** 详情页用的简单曲目列表（无封面、无收藏按钮）。 */
public class SimpleTrackAdapter extends BaseAdapter implements ScrollPause.Pausable {

    private final LayoutInflater inflater;
    private final Context context;
    private List<Track> tracks = new ArrayList<>();
    private final boolean draggable;
    private int dragFrom = -1;
    private boolean scrolling;

    public SimpleTrackAdapter(Context context) {
        this(context, false);
    }

    public SimpleTrackAdapter(Context context, boolean draggable) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.draggable = draggable;
    }

    @Override
    public void setScrolling(boolean scrolling) {
        this.scrolling = scrolling;
    }

    public int getDragFrom() {
        return dragFrom;
    }

    public void setDragFrom(int position) {
        dragFrom = position;
    }

    public void setTracks(List<Track> list) {
        tracks = list;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return tracks.size();
    }

    @Override
    public Track getItem(int position) {
        return tracks.get(position);
    }

    @Override
    public long getItemId(int position) {
        return tracks.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = inflater.inflate(R.layout.item_track_simple, parent, false);
        }
        Track track = tracks.get(position);
        TextView num = view.findViewById(R.id.t_num);
        TextView title = view.findViewById(R.id.t_title);
        TextView artist = view.findViewById(R.id.t_artist);
        TextView dur = view.findViewById(R.id.t_dur);
        num.setText(String.valueOf(position + 1));
        title.setText(track.title);
        artist.setText(track.artist);
        dur.setText(Track.format(track.duration));
        final TextView quality = view.findViewById(R.id.t_quality);
        final String qualityKey = track.uri;
        quality.setTag(qualityKey);
        Quality quick = QualityLoader.formatOnly(track);
        quality.setText(quick.shortLabel);
        quality.getBackground().mutate().setTint(quick.color);
        quality.setVisibility(View.VISIBLE);
        QualityLoader.request(context, track, new QualityLoader.Callback() {
            @Override
            public void onQuality(String uri, Quality value) {
                if (qualityKey.equals(quality.getTag())) {
                    quality.setText(value.shortLabel);
                    quality.getBackground().mutate().setTint(value.color);
                    quality.setVisibility(View.VISIBLE);
                }
            }
        });
        ImageView drag = view.findViewById(R.id.s_drag);
        drag.setVisibility(draggable ? View.VISIBLE : View.GONE);
        if (draggable) {
            drag.setTag(position);
            drag.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    dragFrom = (Integer) v.getTag();
                    ClipData data = ClipData.newPlainText("", "");
                    View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
                    if (Build.VERSION.SDK_INT >= 24) {
                        v.startDragAndDrop(data, shadow, null, 0);
                    } else {
                        v.startDrag(data, shadow, null, 0);
                    }
                    return true;
                }
            });
        }
        return view;
    }
}
