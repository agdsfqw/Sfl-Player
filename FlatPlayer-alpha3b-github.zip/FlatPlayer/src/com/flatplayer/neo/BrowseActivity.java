package com.flatplayer.neo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** 专辑网格 / 歌手列表；点条目进入详情页。 */
public class BrowseActivity extends BaseActivity {

    public static final String EXTRA_MODE = "mode";
    public static final String MODE_ALBUMS = "albums";
    public static final String MODE_ARTISTS = "artists";

    private String mode;
    private GridView grid;
    private ListView list;
    private TextView empty;
    private final ArrayList<AlbumEntry> albums = new ArrayList<>();
    private final ArrayList<ArtistEntry> artists = new ArrayList<>();

    static class AlbumEntry {
        long albumId;
        String name;
        String artist;
        String coverUri;
        int count;
    }

    static class ArtistEntry {
        String name;
        String coverUri;
        int count;
        int albumCount;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse);
        mode = getIntent().getStringExtra(EXTRA_MODE);
        if (mode == null) {
            mode = MODE_ALBUMS;
        }
        grid = findViewById(R.id.album_grid);
        list = findViewById(R.id.browse_list);
        empty = findViewById(R.id.browse_empty);
        TextView title = findViewById(R.id.title);
        title.setText(MODE_ALBUMS.equals(mode) ? R.string.albums : R.string.artists);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        boolean albumMode = MODE_ALBUMS.equals(mode);
        grid.setVisibility(albumMode ? View.VISIBLE : View.GONE);
        list.setVisibility(albumMode ? View.GONE : View.VISIBLE);
        if (albumMode) {
            grid.setAdapter(new AlbumAdapter());
            grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    AlbumEntry entry = albums.get(position);
                    Intent intent = new Intent(BrowseActivity.this, AlbumDetailActivity.class);
                    intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_ID, entry.albumId);
                    intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_NAME, entry.name);
                    startActivity(intent);
                }
            });
        } else {
            list.setAdapter(new ArtistAdapter());
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(BrowseActivity.this, ArtistDetailActivity.class);
                    intent.putExtra(ArtistDetailActivity.EXTRA_ARTIST, artists.get(position).name);
                    startActivity(intent);
                }
            });
        }

        load();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Track> tracks = Library.load(BrowseActivity.this);
                final ArrayList<AlbumEntry> albumResult = new ArrayList<>();
                final ArrayList<ArtistEntry> artistResult = new ArrayList<>();
                if (MODE_ALBUMS.equals(mode)) {
                    Map<String, AlbumEntry> map = new LinkedHashMap<>();
                    for (Track track : tracks) {
                        String key = String.valueOf(track.albumId);
                        AlbumEntry entry = map.get(key);
                        if (entry == null) {
                            entry = new AlbumEntry();
                            entry.albumId = track.albumId;
                            entry.name = track.album == null || track.album.isEmpty()
                                    ? getString(R.string.unknown_album) : track.album;
                            entry.artist = track.artist;
                            entry.coverUri = track.uri;
                            map.put(key, entry);
                        }
                        entry.count++;
                    }
                    albumResult.addAll(map.values());
                    java.util.Collections.sort(albumResult, new java.util.Comparator<AlbumEntry>() {
                        @Override
                        public int compare(AlbumEntry a, AlbumEntry b) {
                            return a.name.compareToIgnoreCase(b.name);
                        }
                    });
                } else {
                    Map<String, ArtistEntry> map = new LinkedHashMap<>();
                    Map<String, java.util.Set<String>> albumNames = new LinkedHashMap<>();
                    for (Track track : tracks) {
                        String key = track.artist == null ? "" : track.artist;
                        ArtistEntry entry = map.get(key);
                        if (entry == null) {
                            entry = new ArtistEntry();
                            entry.name = key.isEmpty() ? getString(R.string.unknown_artist) : key;
                            entry.coverUri = track.uri;
                            map.put(key, entry);
                            albumNames.put(key, new java.util.HashSet<String>());
                        }
                        entry.count++;
                        albumNames.get(key).add(String.valueOf(track.albumId));
                    }
                    for (Map.Entry<String, ArtistEntry> item : map.entrySet()) {
                        item.getValue().albumCount = albumNames.get(item.getKey()).size();
                        artistResult.add(item.getValue());
                    }
                    java.util.Collections.sort(artistResult, new java.util.Comparator<ArtistEntry>() {
                        @Override
                        public int compare(ArtistEntry a, ArtistEntry b) {
                            return a.name.compareToIgnoreCase(b.name);
                        }
                    });
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        albums.clear();
                        albums.addAll(albumResult);
                        artists.clear();
                        artists.addAll(artistResult);
                        int size = MODE_ALBUMS.equals(mode) ? albums.size() : artists.size();
                        empty.setVisibility(size == 0 ? View.VISIBLE : View.GONE);
                        if (MODE_ALBUMS.equals(mode)) {
                            ((BaseAdapter) grid.getAdapter()).notifyDataSetChanged();
                        } else {
                            ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
                        }
                    }
                });
            }
        }).start();
    }

    private class AlbumAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return albums.size();
        }

        @Override
        public AlbumEntry getItem(int position) {
            return albums.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_album, parent, false);
            }
            final AlbumEntry entry = albums.get(position);
            final ImageView cover = view.findViewById(R.id.g_cover);
            final TextView tile = view.findViewById(R.id.g_tile);
            TextView title = view.findViewById(R.id.g_title);
            TextView sub = view.findViewById(R.id.g_sub);
            title.setText(entry.name);
            sub.setText(entry.artist + " · " + entry.count + " 首");
            Tiles.apply(tile, entry.name, false);
            cover.setTag(entry.coverUri);
            cover.setImageDrawable(null);
            ArtLoader.load(BrowseActivity.this, CustomArtStore.albumKey(entry.albumId, entry.name, entry.artist), entry.coverUri, 400, new ArtLoader.Callback() {
                @Override
                public void onArt(String uri, Bitmap bitmap) {
                    if (bitmap != null && uri.equals(cover.getTag())) {
                        cover.setImageBitmap(bitmap);
                        tile.setVisibility(View.GONE);
                    }
                }
            });
            return view;
        }
    }

    private class ArtistAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return artists.size();
        }

        @Override
        public ArtistEntry getItem(int position) {
            return artists.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_artist, parent, false);
            }
            final ArtistEntry entry = artists.get(position);
            final ImageView avatar = view.findViewById(R.id.a_avatar);
            final TextView tile = view.findViewById(R.id.a_tile);
            TextView name = view.findViewById(R.id.a_name);
            TextView sub = view.findViewById(R.id.a_sub);
            name.setText(entry.name);
            sub.setText(entry.count + " 首 · " + entry.albumCount + " 张专辑");
            Tiles.apply(tile, entry.name, true);
            avatar.setTag(entry.coverUri);
            avatar.setImageDrawable(null);
            ArtLoader.load(BrowseActivity.this, CustomArtStore.artistKey(entry.name), entry.coverUri, 256, new ArtLoader.Callback() {
                @Override
                public void onArt(String uri, Bitmap bitmap) {
                    if (bitmap != null && uri.equals(avatar.getTag())) {
                        avatar.setImageBitmap(bitmap);
                        tile.setVisibility(View.GONE);
                    }
                }
            });
            return view;
        }
    }
}
