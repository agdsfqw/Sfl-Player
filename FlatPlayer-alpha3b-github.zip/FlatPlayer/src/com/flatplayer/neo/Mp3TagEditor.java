package com.flatplayer.neo;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 仅写 MP3 ID3v2.3 的标题/艺术家/专辑；保留封面、歌词等其它帧。 */
public final class Mp3TagEditor {

    private Mp3TagEditor() {
    }

    public static void write(Context context, Track track, String title, String artist,
                             String album) throws Exception {
        File tempIn = File.createTempFile("tag_in", ".mp3", context.getCacheDir());
        File tempOut = File.createTempFile("tag_out", ".mp3", context.getCacheDir());
        try {
            InputStream in = context.getContentResolver().openInputStream(Uri.parse(track.uri));
            if (in == null) {
                throw new Exception("无法读取文件");
            }
            copy(in, tempIn);
            in.close();

            byte[] all = readHeader(tempIn);
            int audioOffset = audioOffset(all);
            List<byte[]> kept = new ArrayList<>();
            parseFrames(all, kept);

            ByteArrayOutputStream tag = new ByteArrayOutputStream();
            tag.write(new byte[]{'I', 'D', '3', 3, 0, 0, 0, 0, 0, 0});
            for (byte[] frame : kept) {
                tag.write(frame);
            }
            tag.write(textFrame("TIT2", title));
            tag.write(textFrame("TPE1", artist));
            tag.write(textFrame("TALB", album));
            // 预留 1KB padding，便于以后编辑
            tag.write(new byte[1024]);
            byte[] tagBytes = tag.toByteArray();
            int tagSize = tagBytes.length - 10;
            tagBytes[6] = (byte) ((tagSize >> 21) & 0x7F);
            tagBytes[7] = (byte) ((tagSize >> 14) & 0x7F);
            tagBytes[8] = (byte) ((tagSize >> 7) & 0x7F);
            tagBytes[9] = (byte) (tagSize & 0x7F);

            FileOutputStream out = new FileOutputStream(tempOut);
            out.write(tagBytes);
            FileInputStream audio = new FileInputStream(tempIn);
            long skipped = 0;
            while (skipped < audioOffset) {
                long step = audio.skip(audioOffset - skipped);
                if (step <= 0) {
                    break;
                }
                skipped += step;
            }
            copy(audio, out);
            audio.close();
            out.close();

            File backup = new File(context.getCacheDir(), "tag_backup.tmp");
            copy(new FileInputStream(tempIn), backup);

            OutputStream target = null;
            try {
                target = context.getContentResolver().openOutputStream(
                        Uri.parse(track.uri), "wt");
            } catch (Exception ignored) {
                // 部分提供方不支持 "wt"
            }
            if (target == null) {
                target = context.getContentResolver().openOutputStream(
                        Uri.parse(track.uri), "w");
            }
            if (target == null) {
                target = context.getContentResolver().openOutputStream(Uri.parse(track.uri));
            }
            if (target == null) {
                throw new Exception("无法写入文件");
            }
            try {
                FileInputStream result = new FileInputStream(tempOut);
                copy(result, target);
                result.close();
                target.close();
                backup.delete();
            } catch (Exception writeError) {
                try {
                    if (target != null) {
                        target.close();
                    }
                } catch (Exception ignored) {
                    // 忽略
                }
                try {
                    OutputStream restore = context.getContentResolver().openOutputStream(
                            Uri.parse(track.uri), "w");
                    if (restore != null) {
                        FileInputStream original = new FileInputStream(backup);
                        copy(original, restore);
                        original.close();
                        restore.close();
                    }
                } catch (Exception ignored) {
                    // 回滚也失败时保留异常
                }
                throw writeError;
            }
        } finally {
            tempIn.delete();
            tempOut.delete();
        }
    }

    private static byte[] readHeader(File file) throws Exception {
        FileInputStream in = new FileInputStream(file);
        byte[] header = new byte[10];
        int read = in.read(header);
        if (read < 10 || header[0] != 'I' || header[1] != 'D' || header[2] != '3') {
            in.close();
            return header;
        }
        int size = ((header[6] & 0x7F) << 21) | ((header[7] & 0x7F) << 14)
                | ((header[8] & 0x7F) << 7) | (header[9] & 0x7F);
        if (size <= 0 || size > 32 * 1024 * 1024) {
            in.close();
            return header;
        }
        byte[] all = new byte[10 + size];
        System.arraycopy(header, 0, all, 0, 10);
        int offset = 10;
        while (offset < all.length) {
            int count = in.read(all, offset, all.length - offset);
            if (count <= 0) {
                break;
            }
            offset += count;
        }
        in.close();
        return all;
    }

    private static int audioOffset(byte[] header) throws Exception {
        if (header.length < 10 || header[0] != 'I' || header[1] != 'D' || header[2] != '3') {
            return 0;
        }
        int size = ((header[6] & 0x7F) << 21) | ((header[7] & 0x7F) << 14)
                | ((header[8] & 0x7F) << 7) | (header[9] & 0x7F);
        int flags = header[5] & 0xFF;
        int offset = 10 + size;
        if ((flags & 0x10) != 0) {
            offset += 10;
        }
        return offset;
    }

    private static void parseFrames(byte[] header, List<byte[]> kept) {
        if (header.length < 10 || header[0] != 'I' || header[1] != 'D' || header[2] != '3') {
            return;
        }
        int version = header[3] & 0xFF;
        boolean v4 = version == 4;
        int size = ((header[6] & 0x7F) << 21) | ((header[7] & 0x7F) << 14)
                | ((header[8] & 0x7F) << 7) | (header[9] & 0x7F);
        int pos = 10;
        int end = 10 + size;
        int flags = header[5] & 0xFF;
        if ((flags & 0x40) != 0 && pos + 4 <= end) {
            // 跳过扩展头，避免把扩展头当成帧
            if (v4) {
                int extSize = ((header[pos] & 0x7F) << 21) | ((header[pos + 1] & 0x7F) << 14)
                        | ((header[pos + 2] & 0x7F) << 7) | (header[pos + 3] & 0x7F);
                pos += Math.max(4, extSize);
            } else {
                int extSize = ((header[pos] & 0xFF) << 24) | ((header[pos + 1] & 0xFF) << 16)
                        | ((header[pos + 2] & 0xFF) << 8) | (header[pos + 3] & 0xFF);
                pos += 4 + extSize;
            }
        }
        while (pos + 10 <= end) {
            String id = new String(header, pos, 4, StandardCharsets.ISO_8859_1);
            int frameSize = v4
                    ? ((header[pos + 4] & 0x7F) << 21) | ((header[pos + 5] & 0x7F) << 14)
                    | ((header[pos + 6] & 0x7F) << 7) | (header[pos + 7] & 0x7F)
                    : ((header[pos + 4] & 0xFF) << 24) | ((header[pos + 5] & 0xFF) << 16)
                    | ((header[pos + 6] & 0xFF) << 8) | (header[pos + 7] & 0xFF);
            if (frameSize <= 0 || pos + 10 + frameSize > end) {
                break;
            }
            if (!"TIT2".equals(id) && !"TPE1".equals(id) && !"TALB".equals(id)) {
                byte[] frame = new byte[10 + frameSize];
                System.arraycopy(header, pos, frame, 0, frame.length);
                if (v4) {
                    // 保留帧统一改写成 v2.3 的 32 位大端长度
                    frame[4] = (byte) ((frameSize >> 24) & 0xFF);
                    frame[5] = (byte) ((frameSize >> 16) & 0xFF);
                    frame[6] = (byte) ((frameSize >> 8) & 0xFF);
                    frame[7] = (byte) (frameSize & 0xFF);
                }
                kept.add(frame);
            }
            pos += 10 + frameSize;
        }
    }

    private static byte[] textFrame(String id, String value) throws Exception {
        byte[] text = (value == null ? "" : value).getBytes("UTF-16LE");
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        data.write(0x01);
        data.write(new byte[]{(byte) 0xFF, (byte) 0xFE});
        data.write(text);
        byte[] payload = data.toByteArray();
        ByteArrayOutputStream frame = new ByteArrayOutputStream();
        frame.write(id.getBytes(StandardCharsets.ISO_8859_1));
        frame.write((payload.length >> 24) & 0xFF);
        frame.write((payload.length >> 16) & 0xFF);
        frame.write((payload.length >> 8) & 0xFF);
        frame.write(payload.length & 0xFF);
        frame.write(0);
        frame.write(0);
        frame.write(payload);
        return frame.toByteArray();
    }

    private static void copy(InputStream in, File file) throws Exception {
        FileOutputStream out = new FileOutputStream(file);
        copy(in, out);
        out.close();
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[64 * 1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
        out.flush();
    }
}
