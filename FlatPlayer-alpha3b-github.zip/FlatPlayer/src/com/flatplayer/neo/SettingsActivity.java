package com.flatplayer.neo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

/** 设置枢纽：五大模块 + 高级设置。 */
public class SettingsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_home);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        LinearLayout list = findViewById(R.id.settings_home_list);
        add(list, R.string.settings_personalization, PersonalizationActivity.class);
        addCategory(list, R.string.settings_player_page, SettingsCategoryActivity.CATEGORY_PLAYER);
        addCategory(list, R.string.settings_audio, SettingsCategoryActivity.CATEGORY_AUDIO);
        addCategory(list, R.string.settings_files, SettingsCategoryActivity.CATEGORY_FILES);
        addCategory(list, R.string.settings_language, SettingsCategoryActivity.CATEGORY_LANGUAGE);
        SettingsUi.divider(this, list);
        add(list, R.string.advanced_settings, AdvancedSettingsActivity.class);
    }

    private void add(LinearLayout list, int title, final Class<?> target) {
        list.addView(SettingsUi.row(this, getString(title), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, target));
            }
        }));
    }

    private void addCategory(LinearLayout list, int title, final int category) {
        list.addView(SettingsUi.row(this, getString(title), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingsActivity.this, SettingsCategoryActivity.class);
                intent.putExtra(SettingsCategoryActivity.EXTRA_CATEGORY, category);
                startActivity(intent);
            }
        }));
    }
}
