package com.flatplayer.neo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 自建歌单：名称、备注、建立时间、曲目 URI 列表（去重）。 */
public class Playlist {

    public String id;
    public String name;
    public String note;
    public long createdAt;
    public final ArrayList<String> uris = new ArrayList<>();

    public static Playlist create(String name, String note) {
        Playlist playlist = new Playlist();
        playlist.id = UUID.randomUUID().toString();
        playlist.name = name == null ? "" : name;
        playlist.note = note == null ? "" : note;
        playlist.createdAt = System.currentTimeMillis();
        return playlist;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("note", note);
        o.put("createdAt", createdAt);
        JSONArray array = new JSONArray();
        for (String uri : uris) {
            array.put(uri);
        }
        o.put("uris", array);
        return o;
    }

    public static Playlist fromJson(JSONObject o) {
        Playlist playlist = new Playlist();
        playlist.id = o.optString("id", UUID.randomUUID().toString());
        playlist.name = o.optString("name", "未命名歌单");
        playlist.note = o.optString("note", "");
        playlist.createdAt = o.optLong("createdAt", System.currentTimeMillis());
        JSONArray array = o.optJSONArray("uris");
        if (array != null) {
            for (int i = 0; i < array.length(); i++) {
                String uri = array.optString(i);
                if (uri != null && !uri.isEmpty() && !playlist.uris.contains(uri)) {
                    playlist.uris.add(uri);
                }
            }
        }
        return playlist;
    }

    public List<String> uriList() {
        return new ArrayList<>(uris);
    }
}
