package com.flatplayer.neo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class AlbumDetailActivity extends PlayerBindActivity {

    public static final String EXTRA_ALBUM_ID = "album_id";
    public static final String EXTRA_ALBUM_NAME = "album_name";

    private static final int REQ_PICK = 31;
    private static final int REQ_CROP = 32;

    private final ArrayList<Track> tracks = new ArrayList<>();
    private SimpleTrackAdapter adapter;
    private String coverUri;
    private String customKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);

        final long albumId = getIntent().getLongExtra(EXTRA_ALBUM_ID, -1);
        final String albumName = getIntent().getStringExtra(EXTRA_ALBUM_NAME);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ListView list = findViewById(R.id.d_list);
        adapter = new SimpleTrackAdapter(this);
        list.setAdapter(adapter);
        ScrollPause.attach(list, adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                playQueue(tracks, position);
            }
        });
        findViewById(R.id.play_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playQueue(tracks, 0);
            }
        });
        findViewById(R.id.d_cover).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCoverMenu();
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Track> result = new ArrayList<>();
                for (Track track : Library.load(AlbumDetailActivity.this)) {
                    if (track.albumId == albumId) {
                        result.add(track);
                    }
                }
                if (result.isEmpty() && albumName != null) {
                    for (Track track : Library.load(AlbumDetailActivity.this)) {
                        if (albumName.equals(track.album)) {
                            result.add(track);
                        }
                    }
                }
                SortUtil.sort(result, new Prefs(AlbumDetailActivity.this).sortMode(), AlbumDetailActivity.this);
                final ArrayList<Track> loaded = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tracks.clear();
                        tracks.addAll(loaded);
                        adapter.setTracks(tracks);
                        bindHeader(albumName);
                    }
                });
            }
        }).start();
    }

    private void showCoverMenu() {
        if (customKey == null) {
            return;
        }
        String[] items = {getString(R.string.change_cover), getString(R.string.restore_default_cover)};
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.change_cover)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == 0) {
                            pickImage();
                        } else {
                            CustomArtStore.clear(AlbumDetailActivity.this, customKey);
                            ArtLoader.clearMemory();
                            recreate();
                        }
                    }
                })
                .show();
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try {
            startActivityForResult(intent, REQ_PICK);
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "无法打开图片选择器", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }
        if (requestCode == REQ_PICK && data != null && data.getData() != null) {
            Intent crop = new Intent(this, CropActivity.class);
            crop.putExtra(CropActivity.EXTRA_IMAGE, data.getData().toString());
            crop.putExtra(CropActivity.EXTRA_KEY, customKey);
            startActivityForResult(crop, REQ_CROP);
        } else if (requestCode == REQ_CROP) {
            recreate();
        }
    }

    private void bindHeader(String fallbackName) {
        String name = tracks.isEmpty() ? (fallbackName == null ? getString(R.string.unknown_album) : fallbackName)
                : (tracks.get(0).album == null || tracks.get(0).album.isEmpty()
                ? getString(R.string.unknown_album) : tracks.get(0).album);
        String artist = tracks.isEmpty() ? "" : tracks.get(0).artist;
        int year = tracks.isEmpty() ? 0 : tracks.get(0).year;

        TextView title = findViewById(R.id.d_name);
        TextView artistView = findViewById(R.id.d_artist);
        TextView meta = findViewById(R.id.d_meta);
        title.setText(name);
        artistView.setText(artist);
        String metaText = tracks.size() + " 首";
        if (year > 0) {
            metaText += " · " + year;
        }
        meta.setText(metaText);
        coverUri = tracks.isEmpty() ? null : tracks.get(0).uri;
        customKey = tracks.isEmpty() ? null : CustomArtStore.albumKey(tracks.get(0));
        ImageView cover = findViewById(R.id.d_cover);
        final TextView tile = findViewById(R.id.d_tile);
        Tiles.apply(tile, name, false);
        if (coverUri != null) {
            final String uri = coverUri;
            cover.setTag(uri);
            ArtLoader.load(this, CustomArtStore.albumKey(tracks.isEmpty() ? null : tracks.get(0)), uri, 512, new ArtLoader.Callback() {
                @Override
                public void onArt(String u, Bitmap bitmap) {
                    if (bitmap != null && uri.equals(cover.getTag())) {
                        cover.setImageBitmap(bitmap);
                        tile.setVisibility(View.GONE);
                    }
                }
            });
        }
    }
}
