package com.flatplayer.neo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 重复歌曲检测：按「文件名 + 时长」分组。 */
public class DuplicatesActivity extends BaseActivity {

    private final ArrayList<Group> groups = new ArrayList<>();
    private ListView list;
    private TextView summary;
    private Prefs prefs;

    static class Group {
        String key;
        List<Track> tracks = new ArrayList<>();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duplicates);
        prefs = new Prefs(this);
        list = findViewById(R.id.dup_list);
        summary = findViewById(R.id.dup_summary);
        list.setAdapter(new DupAdapter());

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                final Group group = groups.get(position);
                String[] items = {getString(R.string.hide_others, group.tracks.size() - 1)};
                new AlertDialog.Builder(DuplicatesActivity.this)
                        .setTitle(group.tracks.get(0).title)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                java.util.Set<String> hidden = prefs.hiddenTracks();
                                for (int i = 1; i < group.tracks.size(); i++) {
                                    hidden.add(group.tracks.get(i).uri);
                                }
                                prefs.setHiddenTracks(hidden);
                                load();
                                android.widget.Toast.makeText(DuplicatesActivity.this,
                                        "已隐藏 " + (group.tracks.size() - 1) + " 首",
                                        android.widget.Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();
            }
        });
        load();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Map<String, Group> map = new LinkedHashMap<>();
                for (Track track : Library.load(DuplicatesActivity.this)) {
                    String name = track.displayName == null || track.displayName.isEmpty()
                            ? track.title : track.displayName;
                    String key = (name + "|" + (track.duration / 1000)).toLowerCase();
                    Group group = map.get(key);
                    if (group == null) {
                        group = new Group();
                        group.key = key;
                        map.put(key, group);
                    }
                    group.tracks.add(track);
                }
                final ArrayList<Group> result = new ArrayList<>();
                for (Group group : map.values()) {
                    if (group.tracks.size() > 1) {
                        result.add(group);
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        groups.clear();
                        groups.addAll(result);
                        ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
                        summary.setText(groups.isEmpty()
                                ? getString(R.string.no_duplicates)
                                : getString(R.string.duplicates_found, groups.size()));
                    }
                });
            }
        }).start();
    }

    private class DupAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return groups.size();
        }

        @Override
        public Group getItem(int position) {
            return groups.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_browse, parent, false);
            }
            Group group = groups.get(position);
            TextView title = view.findViewById(R.id.b_title);
            TextView sub = view.findViewById(R.id.b_sub);
            title.setText(group.tracks.get(0).title);
            sub.setText(group.tracks.size() + " 份 · " + group.tracks.get(0).artist);
            return view;
        }
    }
}
