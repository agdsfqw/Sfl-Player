package com.flatplayer.neo;

import android.graphics.Bitmap;

/** 列表/迷你条到播放页共享元素用的临时封面。 */
public final class TransitionArt {

    public static final class Data {
        public final long trackId;
        public final Bitmap bitmap;

        Data(long trackId, Bitmap bitmap) {
            this.trackId = trackId;
            this.bitmap = bitmap;
        }
    }

    private static Data data;

    private TransitionArt() {
    }

    public static void put(long trackId, Bitmap bitmap) {
        data = new Data(trackId, bitmap);
    }

    public static Data take() {
        Data value = data;
        data = null;
        return value;
    }
}
