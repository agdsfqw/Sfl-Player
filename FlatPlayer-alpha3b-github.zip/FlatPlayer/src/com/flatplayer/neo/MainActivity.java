package com.flatplayer.neo;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.ContentObserver;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListPopupWindow;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends BaseActivity implements PlayerService.Listener, TrackAdapter.OnFavoriteToggle {

    public static final String EXTRA_FILTER_MODE = "filter_mode";
    public static final String EXTRA_FILTER_ALBUM_ID = "filter_album_id";
    public static final String EXTRA_FILTER_ARTIST = "filter_artist";
    public static final String EXTRA_FILTER_LABEL = "filter_label";

    public static final int MODE_ALL = 0;
    public static final int MODE_FAVORITES = 1;
    public static final int MODE_RECENT = 2;
    public static final int MODE_ALBUM = 3;
    public static final int MODE_ARTIST = 4;

    private static final int REQ_AUDIO = 7;

    private final ArrayList<Track> tracks = new ArrayList<>();
    private final Set<String> favorites = new HashSet<>();
    private final Set<String> selectedUris = new HashSet<>();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private ListView list;
    private EditText search;
    private View empty;
    private TextView emptyTitle;
    private TextView emptySub;
    private TextView emptyAction;
    private TextView headerTitle;

    private View mini;
    private TextView miniTitle;
    private TextView miniArtist;
    private ImageView miniCover;
    private String miniCoverUri;
    private ImageButton miniPlay;
    private SeekBar miniProgress;

    private View drawer;
    private View scrim;
    private ImageView drawerBg;
    private boolean drawerOpen;
    private boolean showLoading;
    private boolean dragging;
    private boolean selectionMode;
    private View selectionBar;
    private TextView selectionCount;
    private View searchBall;
    private ListPopupWindow historyPopup;
    private View sidePlayer;
    private ImageView sideCover;
    private TextView sideTitle;
    private TextView sideArtist;
    private TextView sideQuality;
    private ImageButton sidePlay;
    private boolean tablet;
    private int sideWidthPx;
    private String sideCoverUri;
    private long lastOpenPlayer;
    private boolean playerOpening;
    private float ballDownX;
    private float ballDownY;
    private float ballStartX;
    private float ballStartY;
    private boolean ballMoved;

    private int drawerWidth;
    private float gestureDownX;
    private float gestureDownY;
    private boolean gestureHandled;
    private int lastSort = -1;
    private int filterMode = MODE_ALL;
    private long filterAlbumId = -1;
    private String filterArtist = "";
    private String filterLabel = "";

    private TrackAdapter adapter;
    private PlayerService service;
    private Prefs prefs;
    private boolean bound;
    private boolean hasLoadedOnce;
    private int pendingIndex = -1;
    private int lastRevision;

    private final Runnable mediaReload = new Runnable() {
        @Override
        public void run() {
            if (hasAudioPermission()) {
                try {
            getContentResolver().registerContentObserver(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
        } catch (Throwable ignored) {
            // 个别机型不允许注册
        }
        load();
            }
        }
    };

    private final ContentObserver mediaObserver = new ContentObserver(
            new Handler(Looper.getMainLooper())) {
        @Override
        public void onChange(boolean selfChange, android.net.Uri uri) {
            ui.removeCallbacks(mediaReload);
            ui.postDelayed(mediaReload, 1200);
        }
    };

    private final Runnable searchDebounce = new Runnable() {
        @Override
        public void run() {
            applyFilter();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            ui.postDelayed(this, 500);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((PlayerService.LocalBinder) binder).service();
            service.addListener(MainActivity.this);
            if (pendingIndex >= 0 && adapter.getCount() > 0) {
                int start = Math.min(pendingIndex, adapter.getCount() - 1);
                pendingIndex = -1;
                service.setQueue(new ArrayList<>(adapter.getTracks()), start);
            } else {
                service.restoreSaved();
            }
            sync();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);
        lastRevision = prefs.libraryRevision();
        favorites.addAll(prefs.favorites());
        bindViews();
        setupActions();

        adapter = new TrackAdapter(this, this);
        adapter.setFavorites(favorites);
        list.setAdapter(adapter);
        ScrollPause.attach(list, adapter);

        int startMode = getIntent().getIntExtra(EXTRA_FILTER_MODE, -1);
        if (startMode >= 0) {
            filterMode = startMode;
            filterAlbumId = getIntent().getLongExtra(EXTRA_FILTER_ALBUM_ID, -1);
            filterArtist = getIntent().getStringExtra(EXTRA_FILTER_ARTIST);
            filterLabel = getIntent().getStringExtra(EXTRA_FILTER_LABEL);
            if (filterArtist == null) {
                filterArtist = "";
            }
            if (filterLabel == null) {
                filterLabel = "";
            }
        }
        hideThumb(miniProgress, false);
        float density = getResources().getDisplayMetrics().density;
        drawerWidth = Math.min(dp(280),
                (int) (getResources().getConfiguration().screenWidthDp * density * 0.72f));
        android.view.ViewGroup.LayoutParams drawerParams = drawer.getLayoutParams();
        drawerParams.width = drawerWidth;
        drawer.setLayoutParams(drawerParams);
        drawer.setTranslationX(-drawerWidth);
        setupMiniSwipe();
        setupTablet();
        findViewById(R.id.search_icon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });

        if (hasAudioPermission()) {
            load();
        } else {
            applyFilter();
            requestAudioPermission();
        }
        if (prefs.safOnly() && Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED
                && !prefs.notificationPrompted()) {
            prefs.setNotificationPrompted(true);
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_AUDIO);
        }
    }

    private void bindViews() {
        list = findViewById(R.id.list);
        search = findViewById(R.id.search);
        empty = findViewById(R.id.empty);
        emptyTitle = findViewById(R.id.empty_title);
        emptySub = findViewById(R.id.empty_sub);
        emptyAction = findViewById(R.id.empty_action);
        headerTitle = findViewById(R.id.header_title);
        mini = findViewById(R.id.mini);
        miniTitle = findViewById(R.id.mini_title);
        miniArtist = findViewById(R.id.mini_artist);
        miniCover = findViewById(R.id.mini_cover);
        miniPlay = findViewById(R.id.mini_play);
        miniProgress = findViewById(R.id.mini_progress);
        drawer = findViewById(R.id.drawer);
        scrim = findViewById(R.id.scrim);
        drawerBg = findViewById(R.id.drawer_bg);
        selectionBar = findViewById(R.id.selection_bar);
        selectionCount = findViewById(R.id.selection_count);
        sidePlayer = findViewById(R.id.side_player);
        sideCover = findViewById(R.id.side_cover);
        sideTitle = findViewById(R.id.side_title);
        sideArtist = findViewById(R.id.side_artist);
        sideQuality = findViewById(R.id.side_quality);
        sidePlay = findViewById(R.id.side_play);
    }

    private void setupActions() {
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectionMode) {
                    toggleSelection(adapter.getItem(position));
                } else if (service != null && service.currentTrack() != null
                        && service.currentTrack().uri.equals(adapter.getItem(position).uri)) {
                    View cover = view.findViewById(R.id.cover);
                    openPlayerWithCover(cover);
                } else {
                    playAt(position);
                }
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectionMode) {
                    toggleSelection(adapter.getItem(position));
                } else {
                    showTrackMenu(adapter.getItem(position));
                }
                return true;
            }
        });

        findViewById(R.id.act_favorite).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                batchFavorite();
            }
        });
        findViewById(R.id.act_playlist).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedUris.isEmpty()) {
                    return;
                }
                PlaylistPicker.show(MainActivity.this, new ArrayList<>(selectedUris));
                exitSelection();
            }
        });
        findViewById(R.id.act_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exitSelection();
            }
        });

        findViewById(R.id.menu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });

        findViewById(R.id.drawer_playlist).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFilter(MODE_ALL, -1, "", "");
            }
        });
        findViewById(R.id.drawer_recent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFilter(MODE_RECENT, -1, "", "");
            }
        });
        findViewById(R.id.drawer_playlists).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, PlaylistActivity.class));
            }
        });
        findViewById(R.id.drawer_bookmarks).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, BookmarksActivity.class));
            }
        });
        findViewById(R.id.drawer_folder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, FolderActivity.class));
            }
        });
        findViewById(R.id.drawer_albums).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                Intent intent = new Intent(MainActivity.this, BrowseActivity.class);
                intent.putExtra(BrowseActivity.EXTRA_MODE, BrowseActivity.MODE_ALBUMS);
                startActivity(intent);
            }
        });
        findViewById(R.id.drawer_artists).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                Intent intent = new Intent(MainActivity.this, BrowseActivity.class);
                intent.putExtra(BrowseActivity.EXTRA_MODE, BrowseActivity.MODE_ARTISTS);
                startActivity(intent);
            }
        });
        findViewById(R.id.drawer_favorites).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFilter(MODE_FAVORITES, -1, "", "");
            }
        });
        findViewById(R.id.drawer_stats).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, StatsActivity.class));
            }
        });
        findViewById(R.id.drawer_queue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                QueueDialog.show(MainActivity.this, service);
            }
        });
        findViewById(R.id.drawer_settings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        findViewById(R.id.drawer_about).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
            }
        });

        mini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null && service.currentTrack() != null) {
                    startActivity(new Intent(MainActivity.this, PlayerActivity.class));
                }
            }
        });
        miniPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.toggle();
                }
            }
        });
        findViewById(R.id.mini_prev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.prev();
                }
            }
        });
        findViewById(R.id.mini_next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.next();
                }
            }
        });

        miniProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (!fromUser || service == null) {
                    return;
                }
                int duration = service.getDuration();
                if (duration > 0) {
                    miniArtist.setText(Track.format((long) duration * progress / 1000)
                            + " / " + Track.format(duration));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                dragging = true;
                hideThumb(bar, true);
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                dragging = false;
                if (service != null) {
                    int duration = service.getDuration();
                    if (duration > 0) {
                        service.seekTo(duration * bar.getProgress() / 1000);
                    }
                }
                hideThumb(bar, false);
                sync();
            }
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (historyPopup != null) {
                    historyPopup.dismiss();
                    historyPopup = null;
                }
                ui.removeCallbacks(searchDebounce);
                ui.postDelayed(searchDebounce, 150);
            }
        });

        emptyAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (prefs.safOnly()) {
                    startActivity(new Intent(MainActivity.this, FolderActivity.class));
                } else if (!hasAudioPermission()) {
                    requestAudioPermission();
                } else if (prefs.foldersConfigured() && prefs.selectedFolders().isEmpty()) {
                    startActivity(new Intent(MainActivity.this, FolderActivity.class));
                } else {
                    load();
                }
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        int mode = intent.getIntExtra(EXTRA_FILTER_MODE, -1);
        if (mode < 0) {
            return;
        }
        long albumId = intent.getLongExtra(EXTRA_FILTER_ALBUM_ID, -1);
        String artist = intent.getStringExtra(EXTRA_FILTER_ARTIST);
        String label = intent.getStringExtra(EXTRA_FILTER_LABEL);
        setFilter(mode, albumId, artist == null ? "" : artist, label == null ? "" : label);
    }

    private void setFilter(int mode, long albumId, String artist, String label) {
        filterMode = mode;
        filterAlbumId = albumId;
        filterArtist = artist;
        filterLabel = label;
        closeDrawer();
        applyFilter();
    }

    /** 迷你条上滑展开播放页；轻点仍然打开。 */
    private void setupMiniSwipe() {
        mini.setOnTouchListener(new View.OnTouchListener() {
            private float startX;
            private float startY;
            private boolean fired;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX();
                        startY = event.getRawY();
                        fired = false;
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        float dy = startY - event.getRawY();
                        float dx = Math.abs(event.getRawX() - startX);
                        if (!fired && dy > dp(40) && dy > dx * 1.5f) {
                            fired = true;
                            openPlayer();
                            return true;
                        }
                        return false;
                    case MotionEvent.ACTION_UP:
                        if (fired) {
                            fired = false;
                            return true;
                        }
                        return false;
                    default:
                        return false;
                }
            }
        });
    }

    private void setupSearchBall() {
        final View root = findViewById(R.id.main_root);
        searchBall.post(new Runnable() {
            @Override
            public void run() {
                int maxX = Math.max(0, root.getWidth() - searchBall.getWidth());
                int maxY = Math.max(0, root.getHeight() - searchBall.getHeight());
                int x = prefs.ballX();
                int y = prefs.ballY();
                if (x < 0 || x > maxX) {
                    x = maxX;
                }
                if (y < 0 || y > maxY) {
                    y = Math.max(0, maxY - dp(120));
                }
                searchBall.setTranslationX(x);
                searchBall.setTranslationY(y);
            }
        });
        searchBall.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        ballDownX = event.getRawX();
                        ballDownY = event.getRawY();
                        ballStartX = v.getTranslationX();
                        ballStartY = v.getTranslationY();
                        ballMoved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - ballDownX;
                        float dy = event.getRawY() - ballDownY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            ballMoved = true;
                        }
                        float maxX = Math.max(0, ((View) v.getParent()).getWidth() - v.getWidth());
                        float maxY = Math.max(0, ((View) v.getParent()).getHeight() - v.getHeight());
                        v.setTranslationX(Math.max(0, Math.min(maxX, ballStartX + dx)));
                        v.setTranslationY(Math.max(0, Math.min(maxY, ballStartY + dy)));
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (ballMoved) {
                            snapBall(v);
                        } else {
                            openSearchDialog();
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void applySearchMode() {
        boolean ballMode = prefs.searchMode() == 1;
        if (search != null) {
            search.setVisibility(ballMode ? View.GONE : View.VISIBLE);
        }
        if (searchBall != null) {
            searchBall.setVisibility(ballMode && !tablet ? View.VISIBLE : View.GONE);
        }
    }

    private void showSearchHistory() {
        if (search == null || !search.getText().toString().isEmpty()) {
            return;
        }
        if (historyPopup != null) {
            return;
        }
        final ArrayList<String> history = prefs.searchHistory();
        if (history.isEmpty()) {
            return;
        }
        final ArrayList<String> items = new ArrayList<>(history);
        items.add(getString(R.string.clear_history));
        ListPopupWindow popup = new ListPopupWindow(this);
        popup.setAnchorView(search);
        popup.setWidth(search.getWidth());
        popup.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items));
        popup.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == items.size() - 1) {
                    prefs.clearSearchHistory();
                } else {
                    search.setText(items.get(position));
                    search.setSelection(search.getText().length());
                }
                dismissHistoryPopup(parent);
            }
        });
        popup.setOnDismissListener(new android.widget.PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                historyPopup = null;
            }
        });
        popup.show();
        historyPopup = popup;
    }

    private void dismissHistoryPopup(View view) {
        if (historyPopup != null) {
            historyPopup.dismiss();
            historyPopup = null;
        }
    }

    private void openSearchDialog() {
        if (tracks.isEmpty()) {
            toast(getString(R.string.library_loading));
            return;
        }
        final Dialog dialog = new Dialog(this);
        View content = getLayoutInflater().inflate(R.layout.dialog_search, null);
        dialog.setContentView(content);
        final EditText input = content.findViewById(R.id.search_input);
        final ListView list = content.findViewById(R.id.search_list);
        final SearchAdapter adapter = new SearchAdapter();
        list.setAdapter(adapter);
        final ArrayList<SearchRow> rows = new ArrayList<>();
        final ArrayList<Track> songResults = new ArrayList<>();
        adapter.setData(rows);
        // 打开时先展示搜索历史，否则空查询状态是一片空白
        for (String item : prefs.searchHistory()) {
            SearchRow history = new SearchRow();
            history.type = 3;
            history.title = item;
            history.sub = getString(R.string.type_history);
            rows.add(history);
        }
        if (!rows.isEmpty()) {
            SearchRow clear = new SearchRow();
            clear.type = 4;
            clear.title = getString(R.string.clear_history);
            rows.add(clear);
        }
        adapter.notifyDataSetChanged();
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String query = s.toString().trim().toLowerCase(Locale.ROOT);
                rows.clear();
                songResults.clear();
                if (query.isEmpty()) {
                    for (String item : prefs.searchHistory()) {
                        SearchRow history = new SearchRow();
                        history.type = 3;
                        history.title = item;
                        history.sub = getString(R.string.type_history);
                        rows.add(history);
                    }
                    if (!rows.isEmpty()) {
                        SearchRow clear = new SearchRow();
                        clear.type = 4;
                        clear.title = getString(R.string.clear_history);
                        rows.add(clear);
                    }
                    adapter.notifyDataSetChanged();
                    return;
                }
                java.util.LinkedHashMap<String, Integer> artists = new java.util.LinkedHashMap<>();
                java.util.LinkedHashMap<String, long[]> albums = new java.util.LinkedHashMap<>();
                java.util.HashMap<String, String> albumNames = new java.util.HashMap<>();
                for (Track track : tracks) {
                    boolean match = Pinyin.matches(track.title, query)
                            || Pinyin.matches(track.artist, query)
                            || Pinyin.matches(track.album == null ? "" : track.album, query);
                    if (!match) {
                        continue;
                    }
                    SearchRow row = new SearchRow();
                    row.type = 0;
                    row.track = track;
                    row.title = track.title;
                    row.sub = track.artist;
                    rows.add(row);
                    songResults.add(track);
                }
                for (Track track : tracks) {
                    if (!Pinyin.matches(track.artist, query)) {
                        continue;
                    }
                    artists.put(track.artist, artists.containsKey(track.artist)
                            ? artists.get(track.artist) + 1 : 1);
                }
                for (Track track : tracks) {
                    if (query.isEmpty()) {
                        continue;
                    }
                    String album = track.album == null ? "" : track.album;
                    if (!Pinyin.matches(album, query)) {
                        continue;
                    }
                    String key = track.albumId + "|" + album;
                    long[] item = albums.get(key);
                    if (item == null) {
                        albums.put(key, new long[]{track.albumId, 1});
                        albumNames.put(key, album);
                    } else {
                        item[1]++;
                    }
                }
                int artistCount = 0;
                for (java.util.Map.Entry<String, Integer> entry : artists.entrySet()) {
                    if (artistCount++ >= 6) {
                        break;
                    }
                    SearchRow row = new SearchRow();
                    row.type = 1;
                    row.title = entry.getKey();
                    row.sub = getString(R.string.song_count_short, entry.getValue());
                    rows.add(row);
                }
                int albumCount = 0;
                for (java.util.Map.Entry<String, long[]> entry : albums.entrySet()) {
                    if (albumCount++ >= 6) {
                        break;
                    }
                    SearchRow row = new SearchRow();
                    row.type = 2;
                    row.albumId = entry.getValue()[0];
                    row.title = albumNames.get(entry.getKey());
                    row.sub = getString(R.string.song_count_short, entry.getValue()[1]);
                    rows.add(row);
                }
                adapter.notifyDataSetChanged();
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SearchRow row = rows.get(position);
                if (row.type == 3) {
                    input.setText(row.title);
                    input.setSelection(input.getText().length());
                    return;
                }
                if (row.type == 4) {
                    prefs.clearSearchHistory();
                    rows.clear();
                    adapter.notifyDataSetChanged();
                    input.setText("");
                    return;
                }
                if (row.type == 0) {
                    prefs.addSearchHistory(input.getText().toString().trim());
                    startService(new Intent(MainActivity.this, PlayerService.class));
                    int index = songResults.indexOf(row.track);
                    if (service != null && index >= 0) {
                        service.setQueue(new ArrayList<>(songResults), index);
                    }
                    dialog.dismiss();
                } else if (row.type == 1) {
                    prefs.addSearchHistory(input.getText().toString().trim());
                    Intent intent = new Intent(MainActivity.this, ArtistDetailActivity.class);
                    intent.putExtra(ArtistDetailActivity.EXTRA_ARTIST, row.title);
                    startActivity(intent);
                    dialog.dismiss();
                } else {
                    prefs.addSearchHistory(input.getText().toString().trim());
                    Intent intent = new Intent(MainActivity.this, AlbumDetailActivity.class);
                    intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_ID, row.albumId);
                    intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_NAME, row.title);
                    startActivity(intent);
                    dialog.dismiss();
                }
            }
        });
        dialog.show();
        GlassDialogs.styleContent(this, content);
        GlassDialogs.apply(this, dialog);
        input.requestFocus();
    }

    private static class SearchRow {
        int type;
        Track track;
        String title;
        String sub;
        long albumId;
    }

    private class SearchAdapter extends BaseAdapter {
        private ArrayList<SearchRow> rows = new ArrayList<>();

        void setData(ArrayList<SearchRow> data) {
            rows = data;
        }

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public SearchRow getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_search, parent, false);
            }
            SearchRow row = rows.get(position);
            TextView title = view.findViewById(R.id.sr_title);
            TextView sub = view.findViewById(R.id.sr_sub);
            TextView type = view.findViewById(R.id.sr_type);
            title.setText(row.title);
            sub.setText(row.sub);
            if (row.type == 0) {
                type.setText(R.string.type_song);
            } else if (row.type == 1) {
                type.setText(R.string.type_artist);
            } else if (row.type == 2) {
                type.setText(R.string.type_album);
            } else if (row.type == 4) {
                type.setText("");
            } else {
                type.setText(R.string.type_history);
            }
            return view;
        }
    }

    private void openPlayer() {
        openPlayerWithCover(miniCover);
    }

    private void setupTablet() {
        tablet = getResources().getConfiguration().smallestScreenWidthDp >= 600;
        if (!tablet) {
            return;
        }
        sideWidthPx = dp(320);
        sidePlayer.setVisibility(View.VISIBLE);
        mini.setVisibility(View.GONE);
        searchBall.setVisibility(View.GONE);
        sidePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.toggle();
                }
            }
        });
        findViewById(R.id.side_prev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.prev();
                }
            }
        });
        findViewById(R.id.side_next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.next();
                }
            }
        });
        sideCover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPlayerWithCover(sideCover);
            }
        });
        View content = findViewById(android.R.id.content);
        if (content != null) {
            content.requestApplyInsets();
        }
    }

    private void updateSidePlayer(Track track, boolean playing) {
        if (!tablet || sidePlayer == null) {
            return;
        }
        if (track == null) {
            sideTitle.setText(R.string.app_name);
            sideArtist.setText("");
            sideQuality.setVisibility(View.GONE);
            sideCover.setImageDrawable(null);
            return;
        }
        sideTitle.setText(track.title);
        sideArtist.setText(track.artist);
        sidePlay.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        if (!track.uri.equals(sideCoverUri)) {
            sideCoverUri = track.uri;
            sideCover.setImageDrawable(null);
            final String uri = track.uri;
            ArtLoader.load(this, CustomArtStore.albumKey(track), uri, 320, new ArtLoader.Callback() {
                @Override
                public void onArt(String u, android.graphics.Bitmap bitmap) {
                    if (bitmap != null && uri.equals(sideCoverUri)) {
                        sideCover.setImageBitmap(bitmap);
                    }
                }
            });
            sideQuality.setVisibility(View.GONE);
            QualityLoader.request(this, track, new QualityLoader.Callback() {
                @Override
                public void onQuality(String u, Quality quality) {
                    if (uri.equals(sideCoverUri)) {
                        sideQuality.setText(quality.detail);
                        sideQuality.getBackground().mutate().setTint(quality.color);
                        sideQuality.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
    }

    private void openPlayerWithCover(View cover) {
        if (service == null || service.currentTrack() == null) {
            return;
        }
        if (playerOpening) {
            return;
        }
        if (prefs.animationLevel() == 0) {
            startActivity(new Intent(MainActivity.this, PlayerActivity.class));
            return;
        }
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastOpenPlayer < 700) {
            return;
        }
        playerOpening = true;
        lastOpenPlayer = now;
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                playerOpening = false;
            }
        }, 2000);
        Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
        if (prefs.reduceMotion()) {
            startActivity(intent);
            return;
        }
        android.graphics.drawable.Drawable drawable =
                cover == null ? null : ((ImageView) cover).getDrawable();
        if (drawable instanceof android.graphics.drawable.BitmapDrawable) {
            cover.setTransitionName("player_cover");
            TransitionArt.put(service.currentTrack().id,
                    ((android.graphics.drawable.BitmapDrawable) drawable).getBitmap());
            android.app.ActivityOptions options = android.app.ActivityOptions
                    .makeSceneTransitionAnimation(this, cover, "player_cover");
            startActivity(intent, options.toBundle());
        } else {
            startActivity(intent);
        }
    }

    /** 右滑拉出侧栏，左滑收起；迷你条上的横向拖动不参与判定。 */
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                gestureDownX = event.getRawX();
                gestureDownY = event.getRawY();
                gestureHandled = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (!gestureHandled) {
                    float dx = event.getRawX() - gestureDownX;
                    float dy = Math.abs(event.getRawY() - gestureDownY);
                    if (drawerOpen) {
                        if (dx < -dp(36) && Math.abs(dx) > dy * 1.2f) {
                            closeDrawer();
                            gestureHandled = true;
                            return true;
                        }
                    } else if (dx > dp(44) && dx > dy * 1.2f
                            && !insideMini(event) && !insideSearch(event) && !insideBall(event)) {
                        openDrawer();
                        gestureHandled = true;
                        return true;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                gestureHandled = false;
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    /** 松手后横向吸附到最近的屏幕边缘。 */
    private void snapBall(final View ball) {
        final View parent = (View) ball.getParent();
        final float maxX = Math.max(0, parent.getWidth() - ball.getWidth());
        float center = ball.getTranslationX() + ball.getWidth() / 2f;
        final float targetX = center < parent.getWidth() / 2f ? 0 : maxX;
        ball.animate().translationX(targetX).setDuration(200).withEndAction(new Runnable() {
            @Override
            public void run() {
                prefs.setBallPosition((int) targetX, (int) ball.getTranslationY());
            }
        }).start();
    }

    private boolean insideBall(MotionEvent event) {
        if (searchBall == null || searchBall.getVisibility() != View.VISIBLE) {
            return false;
        }
        int[] location = new int[2];
        searchBall.getLocationOnScreen(location);
        float x = event.getRawX();
        float y = event.getRawY();
        return x >= location[0] && x <= location[0] + searchBall.getWidth()
                && y >= location[1] && y <= location[1] + searchBall.getHeight();
    }

    private boolean insideSearch(MotionEvent event) {
        if (search == null) {
            return false;
        }
        int[] location = new int[2];
        search.getLocationOnScreen(location);
        int height = search.getHeight();
        return event.getRawY() >= location[1] && event.getRawY() <= location[1] + height;
    }

    private boolean insideMini(MotionEvent event) {
        if (mini.getVisibility() != View.VISIBLE) {
            return false;
        }
        int[] location = new int[2];
        mini.getLocationOnScreen(location);
        return event.getRawY() >= location[1];
    }

    @Override
    protected void onApplyInsets(int left, int top, int right, int bottom) {
        View contentView = findViewById(R.id.content);
        if (contentView != null) {
            contentView.setPadding(left, top, right + sideWidthPx, bottom);
        }
        View drawerScroll = findViewById(R.id.drawer_scroll);
        if (drawerScroll != null) {
            drawerScroll.setPadding(0, top, 0, bottom);
        }
    }

    private int glassLevel() {
        int level = prefs.frostedGlass();
        if (level < 0) {
            boolean lowRam = ((android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE))
                    .isLowRamDevice();
            level = lowRam ? 0 : 2;
        }
        return level;
    }

    private boolean acrylic() {
        return prefs.glassMaterial() == 1;
    }

    private int glassRadius() {
        int level = glassLevel();
        if (acrylic()) {
            return level >= 3 ? 8 : level == 2 ? 4 : 2;
        }
        return level >= 3 ? 14 : level == 2 ? 8 : 4;
    }

    private void applyGlass() {
        final int level = glassLevel();
        if (level <= 0) {
            drawerBg.setVisibility(View.GONE);
            drawer.setBackgroundColor(themeColor(R.attr.colorSurface, 255));
            return;
        }
        final int surface = themeColor(R.attr.colorSurface, 255);
        drawer.setBackgroundColor(themeColor(R.attr.colorSurface, acrylic() ? 236 : 242));
        final View contentView = findViewById(R.id.content);
        final float targetAlpha = acrylic() ? 0.42f : 0.55f;
        Blur.blurView(contentView, glassRadius(), new Blur.Callback() {
            @Override
            public void onBlur(android.graphics.Bitmap bitmap) {
                if (!drawerOpen || isFinishing() || drawerBg == null) {
                    return;
                }
                if (bitmap == null) {
                    drawerBg.setVisibility(View.GONE);
                    return;
                }
                if (acrylic()) {
                    Blur.acrylic(bitmap, surface, 0.12f, 0.02f);
                }
                drawerBg.setImageBitmap(bitmap);
                drawerBg.setVisibility(View.VISIBLE);
                drawerBg.setAlpha(0f);
                drawerBg.animate().alpha(targetAlpha).setDuration(140).start();
            }
        });
    }

    private int attrColor(int attr) {
        android.util.TypedValue value = new android.util.TypedValue();
        getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    private int themeColor(int attr, int alpha) {
        android.util.TypedValue value = new android.util.TypedValue();
        getTheme().resolveAttribute(attr, value, true);
        int color = value.data;
        return android.graphics.Color.argb(alpha,
                android.graphics.Color.red(color),
                android.graphics.Color.green(color),
                android.graphics.Color.blue(color));
    }

    private void openDrawer() {
        if (drawerOpen) {
            return;
        }
        drawerOpen = true;
        applyGlass();
        scrim.setVisibility(View.VISIBLE);
        float target = glassLevel() > 0 ? (acrylic() ? 0.03f : 0.06f) : 1f;
        if (prefs.reduceMotion()) {
            drawer.setTranslationX(0);
            scrim.setAlpha(target);
            return;
        }
        drawer.animate().translationX(0).setDuration(180).withLayer().start();
        scrim.animate().alpha(target).setDuration(200).start();
    }

    private void closeDrawer() {
        if (!drawerOpen) {
            return;
        }
        drawerOpen = false;
        if (prefs.reduceMotion()) {
            drawer.setTranslationX(-drawerWidth);
            scrim.setVisibility(View.GONE);
            scrim.setAlpha(0f);
            drawerBg.setVisibility(View.GONE);
            return;
        }
        drawer.animate().translationX(-drawerWidth).setDuration(160).withLayer().start();
        scrim.animate().alpha(0f).setDuration(180).withEndAction(new Runnable() {
            @Override
            public void run() {
                scrim.setVisibility(View.GONE);
                drawerBg.setVisibility(View.GONE);
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (selectionMode) {
            exitSelection();
            return;
        }
        if (drawerOpen) {
            closeDrawer();
            return;
        }
        super.onBackPressed();
    }

    private void showTrackMenu(final Track track) {
        if (track == null) {
            return;
        }
        final boolean favorite = favorites.contains(track.uri);
        String[] items = {
                getString(R.string.only_this),
                getString(R.string.play_next),
                getString(R.string.audio_info),
                favorite ? getString(R.string.unfavorite) : getString(R.string.favorite),
                getString(R.string.add_to_playlist),
                getString(R.string.hide_from_library),
                getString(R.string.multi_select),
                getString(R.string.edit_tags)
        };
        new AlertDialog.Builder(this)
                .setTitle(track.title)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            playOnlyThis(track);
                        } else if (which == 1) {
                            if (service != null) {
                                service.playNext(track);
                                toast(getString(R.string.added_next));
                            }
                        } else if (which == 2) {
                            InfoDialog.show(MainActivity.this, track);
                        } else if (which == 3) {
                            onToggle(track);
                        } else if (which == 4) {
                            PlaylistPicker.show(MainActivity.this,
                                    java.util.Collections.singletonList(track.uri));
                        } else if (which == 5) {
                            hideTrack(track);
                        } else if (which == 6) {
                            enterSelection(track);
                        } else {
                            editTags(track);
                        }
                    }
                })
                .show();
    }

    private void editTags(final Track track) {
        if (track.displayName == null
                || !track.displayName.toLowerCase().endsWith(".mp3")) {
            toast(getString(R.string.tag_mp3_only));
            return;
        }
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = dp(20);
        box.setPadding(pad, dp(4), pad, 0);
        final EditText titleInput = tagInput(getString(R.string.tag_title), track.title);
        final EditText artistInput = tagInput(getString(R.string.tag_artist), track.artist);
        final EditText albumInput = tagInput(getString(R.string.tag_album), track.album);
        box.addView(titleInput);
        box.addView(artistInput);
        box.addView(albumInput);
        new AlertDialog.Builder(this)
                .setTitle(R.string.edit_tags)
                .setView(box)
                .setPositiveButton(R.string.save, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final String title = titleInput.getText().toString().trim();
                        final String artist = artistInput.getText().toString().trim();
                        final String album = albumInput.getText().toString().trim();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Mp3TagEditor.write(MainActivity.this, track, title, artist, album);
                                    prefs.setMetaOverride(track.uri, title, artist, album);
                                    prefs.markLibraryChanged();
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            load();
                                            toast(getString(R.string.tag_written));
                                        }
                                    });
                                } catch (Throwable t) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            toast(getString(R.string.tag_write_failed));
                                        }
                                    });
                                }
                            }
                        }).start();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private EditText tagInput(String hint, String value) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setText(value == null ? "" : value);
        input.setSingleLine(true);
        input.setTextColor(attrColor(R.attr.colorText));
        input.setHintTextColor(attrColor(R.attr.colorTextDim));
        return input;
    }

    private void enterSelection(Track track) {
        selectionMode = true;
        selectedUris.clear();
        if (track != null) {
            selectedUris.add(track.uri);
        }
        updateSelectionUi();
    }

    private void toggleSelection(Track track) {
        if (track == null) {
            return;
        }
        if (selectedUris.contains(track.uri)) {
            selectedUris.remove(track.uri);
        } else {
            selectedUris.add(track.uri);
        }
        if (selectedUris.isEmpty()) {
            exitSelection();
        } else {
            updateSelectionUi();
        }
    }

    private void updateSelectionUi() {
        selectionBar.setVisibility(View.VISIBLE);
        selectionCount.setText(getString(R.string.selected_count, selectedUris.size()));
        adapter.setSelected(selectedUris);
        headerTitle.setText(getString(R.string.selected_count, selectedUris.size()));
    }

    private void exitSelection() {
        selectionMode = false;
        selectedUris.clear();
        selectionBar.setVisibility(View.GONE);
        adapter.setSelected(selectedUris);
        updateHeader();
    }

    private void batchFavorite() {
        if (selectedUris.isEmpty()) {
            return;
        }
        int count = selectedUris.size();
        favorites.addAll(selectedUris);
        prefs.setFavorites(favorites);
        adapter.setFavorites(favorites);
        exitSelection();
        toast(getString(R.string.favorited_count, count));
    }

    private void hideTrack(Track track) {
        Set<String> hidden = prefs.hiddenTracks();
        hidden.add(track.uri);
        prefs.setHiddenTracks(hidden);
        lastRevision = prefs.libraryRevision();
        tracks.remove(track);
        applyFilter();
        toast(getString(R.string.removed_from_library));
    }

    private void playOnlyThis(final Track track) {
        if (prefs.confirmSingle()) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.confirm_single_title)
                    .setMessage(R.string.confirm_single_msg)
                    .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startOnly(track);
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
        } else {
            startOnly(track);
        }
    }

    private void startOnly(Track track) {
        startService(new Intent(this, PlayerService.class));
        if (service != null) {
            service.setQueue(Collections.singletonList(track), 0);
        }
    }

    @Override
    public void onToggle(Track track) {
        if (favorites.contains(track.uri)) {
            favorites.remove(track.uri);
        } else {
            favorites.add(track.uri);
        }
        prefs.setFavorites(favorites);
        adapter.setFavorites(favorites);
        if (filterMode == MODE_FAVORITES) {
            applyFilter();
        }
    }

    private void playAt(int position) {
        if (position < 0 || position >= adapter.getCount()) {
            return;
        }
        if (search != null) {
            String query = search.getText().toString().trim();
            if (!query.isEmpty()) {
                prefs.addSearchHistory(query);
            }
        }
        startService(new Intent(this, PlayerService.class));
        if (service != null) {
            service.setQueue(new ArrayList<>(adapter.getTracks()), position);
            sync();
        } else {
            pendingIndex = position;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!bound) {
            bindService(new Intent(this, PlayerService.class), connection, BIND_AUTO_CREATE);
            bound = true;
        }
        ui.post(ticker);
    }

    @Override
    protected void onResume() {
        super.onResume();
        playerOpening = false;
        sync();
        if (prefs.sortMode() != lastSort) {
            applyFilter();
        }
        if (prefs.libraryRevision() != lastRevision) {
            lastRevision = prefs.libraryRevision();
            if (hasAudioPermission()) {
                load();
            }
        }
    }

    @Override
    protected void onDestroy() {
        try {
            getContentResolver().unregisterContentObserver(mediaObserver);
        } catch (Throwable ignored) {
            // 忽略
        }
        ui.removeCallbacks(mediaReload);
        ui.removeCallbacks(searchDebounce);
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
        ui.removeCallbacks(ticker);
        if (service != null) {
            service.removeListener(this);
        }
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        service = null;
    }

    @Override
    public void onStateChanged() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                sync();
            }
        });
    }

    @Override
    public void onError(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(R.string.play_failed_title)
                        .setMessage(message)
                        .setPositiveButton(R.string.retry, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (service != null) {
                                    service.retry();
                                }
                            }
                        })
                        .setNeutralButton(R.string.skip, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (service != null) {
                                    service.skip();
                                }
                            }
                        })
                        .setNegativeButton(R.string.stop_play, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (service != null) {
                                    service.stopPlayback();
                                }
                            }
                        })
                        .show();
            }
        });
    }

    private void sync() {
        Track track = service == null ? null : service.currentTrack();
        if (track == null) {
            mini.setVisibility(View.GONE);
            adapter.setCurrentUri(null);
            miniCoverUri = null;
            miniCover.setImageDrawable(null);
            updateSidePlayer(null, false);
            return;
        }
        boolean playing = service.isPlaying();
        mini.setVisibility(tablet ? View.GONE : View.VISIBLE);
        updateSidePlayer(track, playing);
        miniTitle.setText(track.title);
        miniArtist.setText(track.artist);
        if (!track.uri.equals(miniCoverUri)) {
            miniCoverUri = track.uri;
            miniCover.setImageDrawable(null);
            final String uri = track.uri;
            ArtLoader.load(this, CustomArtStore.albumKey(track), uri, 128, new ArtLoader.Callback() {
                @Override
                public void onArt(String u, android.graphics.Bitmap bitmap) {
                    if (bitmap != null && uri.equals(miniCoverUri)) {
                        miniCover.setImageBitmap(bitmap);
                    }
                }
            });
        }
        miniPlay.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        miniPlay.setContentDescription(getString(playing ? R.string.pause : R.string.play));
        adapter.setCurrentUri(track.uri);
        updateProgress();
    }

    private void updateProgress() {
        if (dragging || service == null || service.currentTrack() == null) {
            return;
        }
        int duration = service.getDuration();
        if (duration <= 0) {
            return;
        }
        int position = Math.min(service.getPosition(), duration);
        int progress = (int) Math.min(1000L, (long) position * 1000L / duration);
        miniProgress.setProgress(progress);
    }

    private void load() {
        if (!hasAudioPermission()) {
            applyFilter();
            return;
        }
        showLoading = true;
        empty.setVisibility(View.GONE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Track> loaded = Library.load(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showLoading = false;
                        hasLoadedOnce = true;
                        tracks.clear();
                        tracks.addAll(loaded);
                        applyFilter();
                        QualityLoader.prefetch(MainActivity.this, tracks);
                    }
                });
            }
        }).start();
    }

    private void applyFilter() {
        ArrayList<Track> base = new ArrayList<>();
        if (filterMode == MODE_FAVORITES) {
            for (Track track : tracks) {
                if (favorites.contains(track.uri)) {
                    base.add(track);
                }
            }
        } else if (filterMode == MODE_RECENT) {
            HashMap<String, Track> map = new HashMap<>();
            for (Track track : tracks) {
                map.put(track.uri, track);
            }
            for (String uri : prefs.recent()) {
                Track track = map.get(uri);
                if (track != null) {
                    base.add(track);
                }
            }
        } else if (filterMode == MODE_ALBUM) {
            for (Track track : tracks) {
                if (track.albumId == filterAlbumId) {
                    base.add(track);
                }
            }
        } else if (filterMode == MODE_ARTIST) {
            for (Track track : tracks) {
                if (filterArtist.equals(track.artist)) {
                    base.add(track);
                }
            }
        } else {
            base.addAll(tracks);
        }

        String query = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        ArrayList<Track> filtered = new ArrayList<>();
        for (Track track : base) {
            if (!query.isEmpty()) {
                String title = track.title.toLowerCase(Locale.ROOT);
                String artist = track.artist.toLowerCase(Locale.ROOT);
                String album = track.album == null ? "" : track.album.toLowerCase(Locale.ROOT);
                if (!title.contains(query) && !artist.contains(query) && !album.contains(query)) {
                    continue;
                }
            }
            filtered.add(track);
        }
        SortUtil.sort(filtered, prefs.sortMode(), this);
        lastSort = prefs.sortMode();
        adapter.setTracks(filtered);
        adapter.setSelected(selectedUris);
        updateHeader();
        if (tracks.isEmpty()) {
            if (prefs.safOnly()) {
                showEmpty(R.string.empty_title, R.string.saf_first_hint, R.string.choose_folder);
            } else if (!hasAudioPermission()) {
                showEmpty(R.string.need_permission, R.string.need_permission_sub, R.string.grant);
            } else if (prefs.foldersConfigured() && prefs.selectedFolders().isEmpty()) {
                showEmpty(R.string.folders_none_hint, 0, R.string.folders);
            } else {
                showEmpty(R.string.empty_title, R.string.empty_sub, R.string.rescan);
            }
            return;
        }
        if (filtered.isEmpty()) {
            showEmpty(R.string.no_match, R.string.no_match_sub, 0);
            return;
        }
        empty.setVisibility(View.GONE);
        list.setVisibility(View.VISIBLE);
    }

    private void updateHeader() {
        if (selectionMode) {
            headerTitle.setText(getString(R.string.selected_count, selectedUris.size()));
            return;
        }
        if (filterMode == MODE_FAVORITES) {
            headerTitle.setText(R.string.favorites);
        } else if (filterMode == MODE_RECENT) {
            headerTitle.setText(R.string.recent);
        } else if (filterMode == MODE_ALBUM) {
            headerTitle.setText(getString(R.string.album_prefix, filterLabel));
        } else if (filterMode == MODE_ARTIST) {
            headerTitle.setText(getString(R.string.artist_prefix, filterArtist));
        } else {
            headerTitle.setText(R.string.library);
        }
    }

    private void showEmpty(int titleRes, int subRes, int actionRes) {
        empty.setVisibility(View.VISIBLE);
        list.setVisibility(View.GONE);
        emptyTitle.setText(titleRes);
        if (subRes != 0) {
            emptySub.setText(subRes);
            emptySub.setVisibility(View.VISIBLE);
        } else {
            emptySub.setVisibility(View.GONE);
        }
        if (actionRes != 0) {
            emptyAction.setText(actionRes);
            emptyAction.setVisibility(View.VISIBLE);
        } else {
            emptyAction.setVisibility(View.GONE);
        }
    }

    private void hideThumb(final SeekBar bar, boolean show) {
        final Drawable thumb = bar.getThumb();
        if (thumb == null) {
            return;
        }
        if (show) {
            thumb.setAlpha(255);
            return;
        }
        ValueAnimator animator = ValueAnimator.ofInt(thumb.getAlpha(), 0);
        animator.setDuration(260);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                thumb.setAlpha((Integer) animation.getAnimatedValue());
            }
        });
        animator.start();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- 权限

    private String audioPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private boolean hasAudioPermission() {
        return prefs.safOnly()
                || checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAudioPermission() {
        ArrayList<String> permissions = new ArrayList<>();
        permissions.add(audioPermission());
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        requestPermissions(permissions.toArray(new String[0]), REQ_AUDIO);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_AUDIO) {
            return;
        }
        if (hasAudioPermission()) {
            load();
        } else if (!shouldShowRequestPermissionRationale(audioPermission())) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                toast(getString(R.string.permission_settings_hint));
            }
        } else {
            applyFilter();
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
