package com.flatplayer.neo;

import android.content.Context;

/** 统一管理主题、材质、动画等级与预设。 */
public final class ThemeManager {

    public static final int ANIM_OFF = 0;
    public static final int ANIM_FAST = 1;
    public static final int ANIM_MEDIUM = 2;
    public static final int ANIM_ELEGANT = 3;

    public static final int PRESET_DEFAULT = 0;
    public static final int PRESET_PERFORMANCE = 1;
    public static final int PRESET_BEAUTY = 2;
    public static final int PRESET_LOW_END = 3;

    private final Prefs prefs;

    public ThemeManager(Context context) {
        this.prefs = new Prefs(context.getApplicationContext());
    }

    public int animationLevel() {
        return prefs.animationLevel();
    }

    public void setAnimationLevel(int level) {
        prefs.setAnimationLevel(level);
    }

    public int material() {
        return prefs.glassMaterial();
    }

    public void setMaterial(int material) {
        prefs.setGlassMaterial(material == 1 ? 1 : 0);
    }

    public void applyPreset(int preset) {
        switch (preset) {
            case PRESET_PERFORMANCE:
                prefs.setFrostedGlass(1);
                prefs.setAnimationLevel(ANIM_FAST);
                prefs.setReduceMotion(false);
                break;
            case PRESET_BEAUTY:
                prefs.setFrostedGlass(3);
                prefs.setGlassMaterial(1);
                prefs.setAnimationLevel(ANIM_ELEGANT);
                prefs.setReduceMotion(false);
                break;
            case PRESET_LOW_END:
                prefs.setFrostedGlass(0);
                prefs.setAnimationLevel(ANIM_OFF);
                prefs.setReduceMotion(true);
                break;
            case PRESET_DEFAULT:
            default:
                prefs.setFrostedGlass(2);
                prefs.setGlassMaterial(0);
                prefs.setAnimationLevel(ANIM_MEDIUM);
                prefs.setReduceMotion(false);
                prefs.setTheme(Prefs.THEME_FOLLOW);
                prefs.setBackgroundPreset(0);
                prefs.setAccentHue(218);
                break;
        }
    }

    public void resetVisuals() {
        prefs.setTheme(Prefs.THEME_FOLLOW);
        prefs.setBackgroundPreset(0);
        prefs.setAccentHue(218);
        prefs.setFrostedGlass(2);
        prefs.setGlassMaterial(0);
        prefs.setAnimationLevel(ANIM_MEDIUM);
        prefs.setReduceMotion(false);
        prefs.setLyricFontSize(15);
        prefs.setPlayerBlur(false);
        prefs.setColorBlind(false);
    }
}
