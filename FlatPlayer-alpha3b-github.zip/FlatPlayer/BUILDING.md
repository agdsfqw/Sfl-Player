# 构建说明

不使用 Gradle，直接使用 Android SDK 工具。

## 依赖

- JDK 17+
- Android SDK：`platforms/android-34`、`build-tools/34.0.0`
- 非 x86_64 主机运行 x86_64 的 `aapt2` 时需要 `qemu-user-static`

## 构建

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk
./build.sh
```

产物：`FlatPlayer.apk`。版本号读取自 `AndroidManifest.xml`。

## 签名

默认使用 `debug.keystore`（首次构建自动生成）。正式发布请替换为固定 release keystore，并把密码放 CI Secret，不要提交到仓库。
