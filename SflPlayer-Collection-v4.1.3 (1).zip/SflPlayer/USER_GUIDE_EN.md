# Sfl Player User Guide

Applies to v4.1.1. Fully offline, no network permission, no ads, no data collection.

## 1. First launch

Grant audio access:

- Android 13+: Music and audio
- Android 12 and below: Storage

Files are only read for the library. If you deny access, use "Grant permission" in the empty state or enable it in system settings.

## 2. Library sources

- System media library (common folders such as Music/ and Download/)
- SAF folders added manually in Folders (SD card, USB drive, synced folders)

Rescan from the empty state or Folders. MediaStore changes refresh automatically.

## 3. Main screen

- Tap a song: play it and set the current queue
- Tap the currently playing row: open the player (cover transition)
- Long-press: play only this / play next / audio info / favorite / add to playlist / remove from library / multi-select / edit tags
- Heart: favorite

### Search

Settings → Search style: Search bar or Floating ball. Both open the same search dialog:

- Songs, artists and albums are grouped
- Pinyin full spelling and initials are supported (Android 10+)
- Search history is shown when the query is empty; tap to reuse, last row clears

### Drawer

Swipe from the left edge or tap the menu button: Library, Playlists, Recent, Bookmarks, Folders, Albums, Artists, Favorites, Stats, Queue, Settings, About.

## 4. Playback

- Previous / play-pause / next, seek bar
- Long-press seek bar: A-B loop
- Top-right speed: 0.5×–2.0×
- Sleep timer: last 20 seconds fade out, or finish current song first
- Tap cover: switch cover/lyrics; long-press cover: full-screen preview
- Long-press title: audio info, add to playlist, bookmark, bookmarks, A-B loop, preview cover, lyrics offset
- Long-press title menu also shows the current format/quality badge

## 5. Queue

- Tap to play; long-press for play now/next/up/down/remove
- Drag the handle at the end of a row to reorder
- Clear stops playback and empties the queue

## 6. Playlists

- New playlist; long-press to rename/delete
- Add songs via the library menu or "Add" in a playlist
- Drag the handle to reorder; long-press for up/down/remove
- Smart playlists: recently added (30 days), most played Top 50, never played
- M3U export from a playlist; import from the Playlists screen

## 7. Folders (SAF)

- Checked folders appear in the library
- Adding a folder triggers a scan; unchanged folders reuse the index
- Long-press a SAF folder: full rescan / remove
- Removing only drops the index, not the files

## 8. Theme

- Theme: follow system / light / dark
- Background: 3 dark or 3 light presets
- Accent: 0–359° hue
- Frosted glass: off/light/standard/strong; material: frosted glass or acrylic
- Reduce motion disables fades and transitions

## 9. Quality badges

Small solid chips show format and quality:

- Purple: Hi-Res (24-bit or ≥96kHz)
- Green: lossless (FLAC/WAV/APE/AIFF/DSD)
- Blue: high bitrate (≥256kbps)
- Gray-blue: standard (128–255kbps)
- Light gray: low (<128kbps)

While scrolling, the format is shown first (e.g. MP3), then completed after scrolling stops.

## 10. Editing MP3 tags

Long-press a song → Edit tags. MP3 only (ID3v2.3). Covers and lyrics are preserved. The original file is backed up before writing, and restored on failure. Changes apply in the app immediately; other players may need a rescan.

## 11. Widget

Add the 4×2 Sfl Player widget: previous/play-pause/next and current song. Tap to open the app.

## 12. Tablet / large screen

On devices with smallest width ≥600dp, a now-playing panel is pinned to the right with cover, title, artist, quality and controls.

## 13. Lyrics offset

Long-press the player title → Lyrics offset: ±2 seconds in 0.1s steps, saved per song.

## 14. Equalizer

Presets and custom bands are remembered separately for speaker, wired headphones, Bluetooth and USB.

## 15. Backup and restore

Settings → Export backup creates a JSON with playlists, favorites, hidden songs, stats, bookmarks, search history, settings and custom covers (Base64, up to 12MB).

Restore overwrites current data. Files themselves are not included.

## 16. Notification permission

Settings → Notification permission shows allowed/denied and opens system settings when denied.

## 17. Common issues

- Empty library: check permission, rescan, add folders
- Song won't play: unsupported codec (APE/WMA/DSD) or damaged file
- No notification controls: enable notifications
- No cover: no embedded art; use Change cover
- No lyrics: no embedded lyrics and no sibling .lrc (SAF only)
- Sleep timer doesn't stop: check "Finish current song first"
- Restored data unchanged: choose a JSON exported by this app

## 18. Privacy and license

No network permission, no uploaded data, covers and lyrics are local. Free to use, not for profit.

Copyright © 2026 agdsfqw / 蓝色大肥鱼
