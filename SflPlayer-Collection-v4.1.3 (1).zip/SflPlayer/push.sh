#!/usr/bin/env bash
# Sfl Player 手机上传助手（在 Termux 中运行）
set -e
cd "$(dirname "$0")"

echo "======================================"
echo " Sfl Player 上传到 GitHub"
echo "======================================"
echo "请先在 GitHub 新建一个空仓库（不要勾选 README）"
echo

read -r -p "GitHub 用户名: " GH_USER
read -r -p "GitHub 邮箱: " GH_EMAIL
read -r -p "仓库名（直接回车用 SflPlayer）: " REPO
REPO=${REPO:-SflPlayer}
read -r -s -p "粘贴 Token（输入时不显示）: " TOKEN
echo

if [ -z "$GH_USER" ] || [ -z "$TOKEN" ]; then
    echo "用户名或 Token 为空，已停止。"
    exit 1
fi

git init
git config user.name "$GH_USER"
git config user.email "$GH_EMAIL"
git add .
git commit -m "Sfl Player v4.1.3" || true
git branch -M main

git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$GH_USER/$REPO.git"

ASKPASS="$PWD/.askpass.sh"
cat > "$ASKPASS" <<'ASK'
#!/bin/sh
case "$1" in
  *Username*) echo "$GH_USER" ;;
  *) echo "$TOKEN" ;;
esac
ASK
chmod +x "$ASKPASS"

export GH_USER TOKEN
echo
echo "正在推送，请稍候..."
if GIT_ASKPASS="$ASKPASS" GIT_TERMINAL_PROMPT=0 git push -u origin main; then
    echo
    echo "成功！打开：https://github.com/$GH_USER/$REPO"
else
    echo
    echo "推送失败。常见原因："
    echo "1. 仓库里已经有 README 等文件（新建仓库时不要勾选 README）"
    echo "2. Token 没有 Contents: Read and write 权限"
    echo "3. 用户名或仓库名拼错"
fi

rm -f "$ASKPASS"
