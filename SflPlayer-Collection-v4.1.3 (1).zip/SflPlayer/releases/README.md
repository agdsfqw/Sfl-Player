# 发布包

当前仓库只保留最新版本：

- `SflPlayer-v4.1.3.apk`（versionCode 49）

## 关于旧版本

1.0 到 4.1.2 的 APK 在开发过程中被覆盖，仓库中没有历史二进制。
如果你手上有旧 APK，可以按下面结构放入：

```
releases/
  v1.0/SflPlayer.apk
  v2.0/SflPlayer.apk
  ...
  v4.1.2/SflPlayer.apk
```

建议每个版本附一个 `notes.md`，写清版本号、构建日期和主要变化。
