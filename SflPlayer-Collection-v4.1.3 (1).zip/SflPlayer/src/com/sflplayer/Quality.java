package com.sflplayer;

import android.graphics.Color;

/** 单曲的格式与音质徽标信息。 */
public final class Quality {

    public static final int COLOR_HI_RES = 0xFF6A4C93;
    public static final int COLOR_LOSSLESS = 0xFF2E7D32;
    public static final int COLOR_HIGH = 0xFF1565C0;
    public static final int COLOR_STANDARD = 0xFF546E7A;
    public static final int COLOR_LOW = 0xFF78909C;

    public final String format;
    public final String shortLabel;
    public final String detail;
    public final int color;

    public Quality(String format, String shortLabel, String detail, int color) {
        this.format = format;
        this.shortLabel = shortLabel;
        this.detail = detail;
        this.color = color;
    }

    public static Quality unknown() {
        return new Quality("", "", "", COLOR_LOW);
    }
}
