package com.sflplayer;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** 「已隐藏的歌曲」：勾选后批量恢复。 */
public class HiddenActivity extends BaseActivity {

    private final ArrayList<Track> rows = new ArrayList<>();
    private final Set<String> checked = new HashSet<>();
    private Prefs prefs;
    private ListView list;
    private TextView empty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hidden);
        prefs = new Prefs(this);
        list = findViewById(R.id.hidden_list);
        empty = findViewById(R.id.hidden_empty);
        list.setAdapter(new HiddenAdapter());

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String uri = rows.get(position).uri;
                if (checked.contains(uri)) {
                    checked.remove(uri);
                } else {
                    checked.add(uri);
                }
                ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
            }
        });

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.select_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Track track : rows) {
                    checked.add(track.uri);
                }
                ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
            }
        });
        findViewById(R.id.select_none).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checked.clear();
                ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
            }
        });
        findViewById(R.id.restore_selected).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checked.isEmpty()) {
                    Toast.makeText(HiddenActivity.this, R.string.no_selection, Toast.LENGTH_SHORT).show();
                    return;
                }
                Set<String> hidden = prefs.hiddenTracks();
                hidden.removeAll(checked);
                prefs.setHiddenTracks(hidden);
                checked.clear();
                load();
            }
        });

        load();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Track> hidden = new ArrayList<>();
                Set<String> hiddenUris = prefs.hiddenTracks();
                for (Track track : Library.loadAll(HiddenActivity.this)) {
                    if (hiddenUris.contains(track.uri)) {
                        hidden.add(track);
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rows.clear();
                        rows.addAll(hidden);
                        ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
                        empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                    }
                });
            }
        }).start();
    }

    private class HiddenAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Track getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_hidden, parent, false);
            }
            Track track = rows.get(position);
            TextView title = view.findViewById(R.id.h_title);
            TextView artist = view.findViewById(R.id.h_artist);
            CheckBox check = view.findViewById(R.id.h_check);
            title.setText(track.title);
            artist.setText(track.artist);
            check.setChecked(checked.contains(track.uri));
            return view;
        }
    }
}
