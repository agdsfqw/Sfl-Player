package com.sflplayer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;

/** 用户自定义的专辑封面 / 歌手头像，存放在私有目录，按 key 哈希命名。 */
public final class CustomArtStore {

    private CustomArtStore() {
    }

    public static String albumKey(long albumId, String album, String artist) {
        if (albumId > 0) {
            return "album:" + albumId;
        }
        if (album == null || album.trim().isEmpty()) {
            return null;
        }
        return "albumname:" + album + "|" + artist;
    }

    public static String albumKey(Track track) {
        return track == null ? null : albumKey(track.albumId, track.album, track.artist);
    }

    public static String artistKey(String artist) {
        if (artist == null || artist.trim().isEmpty()) {
            return null;
        }
        return "artist:" + artist;
    }

    public static boolean has(Context context, String key) {
        return key != null && file(context, key).exists();
    }

    public static void save(Context context, String key, Bitmap bitmap) {
        if (key == null || bitmap == null) {
            return;
        }
        try {
            File file = file(context, key);
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.close();
        } catch (Exception ignored) {
            // 保存失败时保留旧的
        }
    }

    public static void clear(Context context, String key) {
        if (key != null) {
            file(context, key).delete();
        }
    }

    public static long totalSize(Context context) {
        File[] files = dir(context).listFiles();
        if (files == null) {
            return 0;
        }
        long size = 0;
        for (File file : files) {
            size += file.length();
        }
        return size;
    }

    public static Bitmap load(Context context, String key, int target) {
        if (key == null) {
            return null;
        }
        File file = file(context, key);
        if (!file.exists()) {
            return null;
        }
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int sample = 1;
            int width = Math.max(1, bounds.outWidth);
            while (width / (sample * 2) >= target) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (Throwable t) {
            return null;
        }
    }

    private static File file(Context context, String key) {
        String name = Integer.toHexString(key.hashCode()) + ".jpg";
        return new File(dir(context), name);
    }

    private static File dir(Context context) {
        File dir = new File(context.getFilesDir(), "custom_art");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
