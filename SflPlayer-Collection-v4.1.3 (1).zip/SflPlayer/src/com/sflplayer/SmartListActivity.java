package com.sflplayer;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/** 智能歌单：最近添加 / 最常播放 / 从未播放。 */
public class SmartListActivity extends PlayerBindActivity {

    public static final String EXTRA_TYPE = "smart_type";
    public static final int TYPE_RECENT = 0;
    public static final int TYPE_MOST = 1;
    public static final int TYPE_NEVER = 2;

    private final ArrayList<Track> tracks = new ArrayList<>();
    private SimpleTrackAdapter adapter;
    private int type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart);
        type = getIntent().getIntExtra(EXTRA_TYPE, TYPE_RECENT);
        TextView title = findViewById(R.id.smart_title);
        title.setText(type == TYPE_RECENT ? R.string.smart_recent
                : type == TYPE_MOST ? R.string.smart_most : R.string.smart_never);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ListView list = findViewById(R.id.smart_list);
        adapter = new SimpleTrackAdapter(this);
        list.setAdapter(adapter);
        ScrollPause.attach(list, adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                playQueue(tracks, position);
            }
        });
        findViewById(R.id.play_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playQueue(tracks, 0);
            }
        });

        load();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Track> all = Library.load(SmartListActivity.this);
                JSONObject stats = new Prefs(SmartListActivity.this).stats();
                ArrayList<Track> result = new ArrayList<>();
                if (type == TYPE_RECENT) {
                    long cutoff = System.currentTimeMillis() - 30L * 24 * 3600 * 1000;
                    for (Track track : all) {
                        if (track.dateAdded * 1000L >= cutoff) {
                            result.add(track);
                        }
                    }
                    Collections.sort(result, new Comparator<Track>() {
                        @Override
                        public int compare(Track a, Track b) {
                            return Long.compare(b.dateAdded, a.dateAdded);
                        }
                    });
                } else if (type == TYPE_MOST) {
                    for (Track track : all) {
                        JSONObject item = stats.optJSONObject(track.uri);
                        if (item != null && item.optInt("c") > 0) {
                            result.add(track);
                        }
                    }
                    Collections.sort(result, new Comparator<Track>() {
                        @Override
                        public int compare(Track a, Track b) {
                            JSONObject ia = stats.optJSONObject(a.uri);
                            JSONObject ib = stats.optJSONObject(b.uri);
                            int ca = ia == null ? 0 : ia.optInt("c");
                            int cb = ib == null ? 0 : ib.optInt("c");
                            return Integer.compare(cb, ca);
                        }
                    });
                    while (result.size() > 50) {
                        result.remove(result.size() - 1);
                    }
                } else {
                    for (Track track : all) {
                        JSONObject item = stats.optJSONObject(track.uri);
                        int count = item == null ? 0 : item.optInt("c");
                        if (count == 0) {
                            result.add(track);
                        }
                    }
                }
                final ArrayList<Track> loaded = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tracks.clear();
                        tracks.addAll(loaded);
                        adapter.setTracks(tracks);
                        ((TextView) findViewById(R.id.smart_count))
                                .setText(tracks.size() + " 首");
                    }
                });
            }
        }).start();
    }
}
