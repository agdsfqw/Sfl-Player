package com.sflplayer;

import android.app.Application;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/** 应用入口：崩溃时把堆栈写到文件，方便定位。 */
public class SflApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler previous =
                Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable error) {
                StringWriter writer = new StringWriter();
                PrintWriter printer = new PrintWriter(writer);
                printer.println("time=" + new java.util.Date().toString());
                printer.println("device=" + Build.MANUFACTURER + " " + Build.MODEL
                        + " api=" + Build.VERSION.SDK_INT);
                printer.println("version=" + versionName());
                error.printStackTrace(printer);
                printer.flush();
                String text = writer.toString();
                Log.e("SflCrash", text);
                saveToDownloads(text);
                try {
                    File file = new File(getFilesDir(), "last_crash.txt");
                    FileOutputStream out = new FileOutputStream(file);
                    out.write(text.getBytes("UTF-8"));
                    out.close();
                } catch (Throwable ignored) {
                    // 忽略
                }
                if (previous != null) {
                    previous.uncaughtException(thread, error);
                } else {
                    System.exit(2);
                }
            }
        });
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }

    private void saveToDownloads(String text) {
        if (Build.VERSION.SDK_INT < 29) {
            return;
        }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, "sfl_crash_" + System.currentTimeMillis() + ".txt");
            values.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                java.io.OutputStream out = getContentResolver().openOutputStream(uri);
                if (out != null) {
                    out.write(text.getBytes("UTF-8"));
                    out.close();
                }
            }
        } catch (Throwable ignored) {
            // 忽略
        }
    }
}
