package com.sflplayer;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/** 快照模糊：缩小后做多次 box blur，开销远低于实时模糊。 */
public final class Blur {

    public interface Callback {
        void onBlur(Bitmap bitmap);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Blur() {
    }

    /** 必须在主线程调用（会绘制 View）。 */
    public static void blurView(final View view, final int radius, final Callback callback) {
        final int width = view.getWidth();
        final int height = view.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }
        final int scale = 10;
        final int smallWidth = Math.max(1, width / scale);
        final int smallHeight = Math.max(1, height / scale);
        final Bitmap small = Bitmap.createBitmap(smallWidth, smallHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(small);
        canvas.scale(smallWidth / (float) width, smallHeight / (float) height);
        try {
            view.draw(canvas);
        } catch (Throwable ignored) {
            return;
        }
        if (!hasContent(small)) {
            callback.onBlur(null);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                boxBlur(small, radius);
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onBlur(small);
                    }
                });
            }
        }, "blur").start();
    }

    /** 抽样检查快照是否真的画到了内容（避免得到一张全黑图）。 */
    public static boolean hasContent(Bitmap bitmap) {
        if (bitmap == null) {
            return false;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int visible = 0;
        int samples = 0;
        for (int y = 0; y < height; y += Math.max(1, height / 24)) {
            for (int x = 0; x < width; x += Math.max(1, width / 24)) {
                int color = bitmap.getPixel(x, y);
                samples++;
                if ((color >>> 24) > 0x10) {
                    visible++;
                }
            }
        }
        return samples > 0 && visible > samples / 10;
    }

    /** 亚克力：底色着色 + 细噪点。 */
    public static void acrylic(Bitmap bitmap, int color, float tintAlpha, float noiseAlpha) {
        if (bitmap == null) {
            return;
        }
        Canvas canvas = new Canvas(bitmap);
        android.graphics.Paint paint = new android.graphics.Paint();
        paint.setColor(color);
        paint.setAlpha((int) (tintAlpha * 255));
        canvas.drawRect(0, 0, bitmap.getWidth(), bitmap.getHeight(), paint);
        int count = (int) (bitmap.getWidth() * bitmap.getHeight() * 0.02f);
        java.util.Random random = new java.util.Random(42);
        for (int i = 0; i < count; i++) {
            int x = random.nextInt(bitmap.getWidth());
            int y = random.nextInt(bitmap.getHeight());
            paint.setColor(random.nextBoolean() ? 0xFFFFFFFF : 0xFF000000);
            paint.setAlpha((int) (noiseAlpha * 255 * random.nextFloat()));
            canvas.drawPoint(x, y, paint);
        }
    }

    public static Bitmap blurBitmap(Bitmap source, int radius) {
        if (source == null) {
            return null;
        }
        int width = Math.max(1, source.getWidth() / 8);
        int height = Math.max(1, source.getHeight() / 8);
        Bitmap small = Bitmap.createScaledBitmap(source, width, height, true);
        boxBlur(small, radius);
        return small;
    }

    private static void boxBlur(Bitmap bitmap, int radius) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        int r = Math.max(1, radius / 3);
        for (int pass = 0; pass < 2; pass++) {
            horizontal(pixels, width, height, r);
            vertical(pixels, width, height, r);
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
    }

    private static void horizontal(int[] pixels, int width, int height, int radius) {
        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            int offset = y * width;
            System.arraycopy(pixels, offset, row, 0, width);
            for (int x = 0; x < width; x++) {
                int r = 0;
                int g = 0;
                int b = 0;
                int count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    int nx = x + dx;
                    if (nx < 0 || nx >= width) {
                        continue;
                    }
                    int color = row[nx];
                    r += (color >> 16) & 0xFF;
                    g += (color >> 8) & 0xFF;
                    b += color & 0xFF;
                    count++;
                }
                pixels[offset + x] = 0xFF000000 | ((r / count) << 16)
                        | ((g / count) << 8) | (b / count);
            }
        }
    }

    private static void vertical(int[] pixels, int width, int height, int radius) {
        int[] column = new int[height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                column[y] = pixels[y * width + x];
            }
            for (int y = 0; y < height; y++) {
                int r = 0;
                int g = 0;
                int b = 0;
                int count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= height) {
                        continue;
                    }
                    int color = column[ny];
                    r += (color >> 16) & 0xFF;
                    g += (color >> 8) & 0xFF;
                    b += color & 0xFF;
                    count++;
                }
                pixels[y * width + x] = 0xFF000000 | ((r / count) << 16)
                        | ((g / count) << 8) | (b / count);
            }
        }
    }
}
