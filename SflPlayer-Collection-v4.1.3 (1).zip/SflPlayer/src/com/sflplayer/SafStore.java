package com.sflplayer;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** SAF 目录与扫描结果的本地索引（filesDir/saf_index.json）。 */
public final class SafStore {

    private static final String FILE = "saf_index.json";
    private static final Object LOCK = new Object();

    private static ArrayList<Root> roots;
    private static ArrayList<Track> tracks;
    private static boolean loaded;

    public static class Root {
        public String uri;
        public String name;
        public long lastModified;

        public Root(String uri, String name) {
            this(uri, name, 0);
        }

        public Root(String uri, String name, long lastModified) {
            this.uri = uri;
            this.name = name;
            this.lastModified = lastModified;
        }
    }

    private SafStore() {
    }

    private static synchronized void ensure(Context context) {
        if (loaded) {
            return;
        }
        loaded = true;
        roots = new ArrayList<>();
        tracks = new ArrayList<>();
        File file = new File(context.getFilesDir(), FILE);
        if (!file.exists()) {
            return;
        }
        try {
            JSONObject root = new JSONObject(read(file));
            JSONArray rootArray = root.optJSONArray("roots");
            if (rootArray != null) {
                for (int i = 0; i < rootArray.length(); i++) {
                    JSONObject item = rootArray.optJSONObject(i);
                    if (item != null) {
                        roots.add(new Root(item.optString("uri"), item.optString("name"),
                                item.optLong("lastModified", 0)));
                    }
                }
            }
            JSONArray trackArray = root.optJSONArray("tracks");
            if (trackArray != null) {
                for (int i = 0; i < trackArray.length(); i++) {
                    JSONObject item = trackArray.optJSONObject(i);
                    if (item != null) {
                        tracks.add(Track.fromJson(item));
                    }
                }
            }
        } catch (Exception e) {
            roots.clear();
            tracks.clear();
        }
    }

    public static ArrayList<Root> roots(Context context) {
        synchronized (LOCK) {
            ensure(context);
            return new ArrayList<>(roots);
        }
    }

    public static ArrayList<Track> tracks(Context context) {
        synchronized (LOCK) {
            ensure(context);
            return new ArrayList<>(tracks);
        }
    }

    public static void setRoots(Context context, List<Root> list) {
        synchronized (LOCK) {
            ensure(context);
            roots = new ArrayList<>(list);
            save(context);
        }
    }

    public static void setTracks(Context context, List<Track> list) {
        synchronized (LOCK) {
            ensure(context);
            tracks = new ArrayList<>(list);
            save(context);
        }
    }

    private static void save(Context context) {
        try {
            JSONObject root = new JSONObject();
            JSONArray rootArray = new JSONArray();
            for (Root item : roots) {
                JSONObject o = new JSONObject();
                o.put("uri", item.uri);
                o.put("name", item.name);
                o.put("lastModified", item.lastModified);
                rootArray.put(o);
            }
            JSONArray trackArray = new JSONArray();
            for (Track track : tracks) {
                trackArray.put(track.toJson());
            }
            root.put("roots", rootArray);
            root.put("tracks", trackArray);
            File file = new File(context.getFilesDir(), FILE);
            File temp = new File(context.getFilesDir(), FILE + ".tmp");
            FileOutputStream out = new FileOutputStream(temp);
            out.write(root.toString().getBytes(StandardCharsets.UTF_8));
            out.close();
            if (!temp.renameTo(file)) {
                file.delete();
                temp.renameTo(file);
            }
        } catch (Exception ignored) {
            // 写入失败保留旧索引
        }
    }

    private static String read(File file) throws Exception {
        InputStream in = new FileInputStream(file);
        byte[] buffer = new byte[(int) file.length()];
        int read = in.read(buffer);
        in.close();
        return new String(buffer, 0, Math.max(0, read), StandardCharsets.UTF_8);
    }
}
