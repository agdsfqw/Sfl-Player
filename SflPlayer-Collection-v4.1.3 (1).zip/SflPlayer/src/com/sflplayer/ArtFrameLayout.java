package com.sflplayer;

import android.content.Context;
import android.util.AttributeSet;

/** 播放页封面：正方形，但高度不超过当前窗口高度的 36%（适配分屏与小窗）。 */
public class ArtFrameLayout extends SquareFrameLayout {

    public ArtFrameLayout(Context context) {
        super(context);
    }

    public ArtFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ArtFrameLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int height = MeasureSpec.getSize(heightSpec);
        int mode = MeasureSpec.getMode(heightSpec);
        float density = getResources().getDisplayMetrics().density;
        int windowHeight = (int) (getResources().getConfiguration().screenHeightDp * density);
        boolean wide = getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        int size;
        if (wide) {
            // 横屏是双栏布局，封面不需要给下面的控制区让位
            size = Math.min(width, height);
        } else {
            // 竖屏：预留标题、进度条与控制区的高度，剩下的再给封面
            int cap = Math.max((int) (120 * density), windowHeight - (int) (300 * density));
            cap = Math.min(cap, (int) (windowHeight * 0.62f));
            size = mode == MeasureSpec.UNSPECIFIED ? Math.min(width, cap)
                    : Math.min(Math.min(width, height), cap);
        }
        super.onMeasure(
                MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
    }
}
