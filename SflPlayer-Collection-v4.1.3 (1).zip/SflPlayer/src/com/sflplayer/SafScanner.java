package com.sflplayer;

import android.content.Context;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.util.ArrayList;

/** 递归扫描 SAF 目录（用系统 DocumentsContract，不依赖 AndroidX），提取元数据后写入索引。 */
public final class SafScanner {

    public interface Listener {
        void onProgress(int count, String name);

        void onDone(int count);

        void onError(String message);
    }

    private static final String[] PROJECTION = {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
    };

    private static volatile boolean running;
    private static volatile boolean cancelled;

    private SafScanner() {
    }

    public static boolean isRunning() {
        return running;
    }

    public static void cancel() {
        cancelled = true;
    }

    public static void start(final Context context, final Listener listener) {
        start(context, listener, false);
    }

    /** force=true 时忽略 root 的修改时间，强制全量扫描。 */
    public static void start(final Context context, final Listener listener, final boolean force) {
        if (running) {
            return;
        }
        running = true;
        cancelled = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ArrayList<Track> result = new ArrayList<>();
                    ArrayList<SafStore.Root> roots = SafStore.roots(context);
                    ArrayList<Track> previous = SafStore.tracks(context);
                    for (SafStore.Root root : roots) {
                        if (cancelled) {
                            break;
                        }
                        Uri treeUri = Uri.parse(root.uri);
                        String rootId;
                        long modified = 0;
                        try {
                            rootId = DocumentsContract.getTreeDocumentId(treeUri);
                            modified = queryModified(context, treeUri, rootId);
                        } catch (Exception e) {
                            rootId = null;
                        }
                        if (!force && rootId != null && modified > 0
                                && modified == root.lastModified) {
                            // 目录未变化，复用上次索引
                            for (Track track : previous) {
                                if (track.bucketKey != null
                                        && track.bucketKey.equals("saf:" + root.uri)) {
                                    result.add(track);
                                }
                            }
                            continue;
                        }
                        scanRoot(context, root, result, listener);
                        if (modified > 0) {
                            root.lastModified = modified;
                        }
                    }
                    if (!cancelled) {
                        SafStore.setRoots(context, roots);
                        SafStore.setTracks(context, result);
                        new Prefs(context).markLibraryChanged();
                    }
                    if (listener != null) {
                        listener.onDone(result.size());
                    }
                } catch (Throwable t) {
                    if (listener != null) {
                        listener.onError(t.getMessage() == null ? "扫描失败" : t.getMessage());
                    }
                } finally {
                    running = false;
                }
            }
        }, "saf-scan").start();
    }

    private static long queryModified(Context context, Uri treeUri, String documentId) {
        Uri documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId);
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(documentUri,
                    new String[]{DocumentsContract.Document.COLUMN_LAST_MODIFIED},
                    null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        } catch (Exception ignored) {
            // 查询失败时按需要扫描处理
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return 0;
    }

    private static void scanRoot(Context context, SafStore.Root root, ArrayList<Track> out,
                                 Listener listener) {
        try {
            Uri treeUri = Uri.parse(root.uri);
            String rootId = DocumentsContract.getTreeDocumentId(treeUri);
            walk(context, treeUri, rootId, root, out, listener);
        } catch (Exception ignored) {
            // 该目录不可读时跳过
        }
    }

    private static void walk(Context context, Uri treeUri, String documentId, SafStore.Root root,
                             ArrayList<Track> out, Listener listener) {
        if (cancelled) {
            return;
        }
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId);
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(childrenUri, PROJECTION, null, null, null);
            if (cursor == null) {
                return;
            }
            java.util.ArrayList<String[]> children = new java.util.ArrayList<>();
            java.util.HashMap<String, Uri> lyrics = new java.util.HashMap<>();
            while (cursor.moveToNext() && !cancelled) {
                children.add(new String[]{cursor.getString(0), cursor.getString(1),
                        cursor.getString(2), String.valueOf(cursor.getLong(3))});
            }
            for (String[] child : children) {
                String name = child[1];
                if (name == null) {
                    continue;
                }
                if (name.toLowerCase().endsWith(".lrc")) {
                    lyrics.put(baseName(name), DocumentsContract.buildDocumentUriUsingTree(treeUri, child[0]));
                }
            }
            for (String[] child : children) {
                if (cancelled) {
                    return;
                }
                String id = child[0];
                String name = child[1];
                String mime = child[2];
                long modified = Long.parseLong(child[3]);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    walk(context, treeUri, id, root, out, listener);
                } else if (isAudio(mime, name)) {
                    Uri uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    Uri lyric = name == null ? null : lyrics.get(baseName(name));
                    Track track = readTrack(context, uri, name, modified, root,
                            lyric == null ? "" : lyric.toString());
                    if (track != null) {
                        out.add(track);
                        if (listener != null && out.size() % 5 == 0) {
                            listener.onProgress(out.size(), track.title);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // 单个目录读取失败不影响其它目录
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static boolean isAudio(String mime, String name) {
        if (mime != null && mime.startsWith("audio/")) {
            return true;
        }
        if (name == null) {
            return false;
        }
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) {
            return false;
        }
        String ext = name.substring(dot + 1).toLowerCase();
        return ext.equals("mp3") || ext.equals("flac") || ext.equals("m4a") || ext.equals("aac")
                || ext.equals("ogg") || ext.equals("opus") || ext.equals("wav")
                || ext.equals("ape") || ext.equals("wma");
    }

    private static Track readTrack(Context context, Uri uri, String name, long modified,
                                   SafStore.Root root, String lyricUri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, uri);
            String title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            String durationText = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String yearText = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR);

            if (title == null || title.trim().isEmpty()) {
                title = name == null ? context.getString(R.string.unnamed) : stripExtension(name);
            }
            if (artist == null || artist.trim().isEmpty() || "<unknown>".equals(artist)) {
                artist = context.getString(R.string.unknown_artist);
            }
            if (album == null) {
                album = "";
            }
            long duration = durationText == null ? 0 : parseLong(durationText);
            int year = yearText == null ? 0 : (int) parseLong(yearText);
            long albumId = album.isEmpty() ? 0 : ((album + "|" + artist).hashCode() & 0x7fffffff);

            return new Track(
                    (uri.toString().hashCode() & 0x7fffffff),
                    uri.toString(),
                    title,
                    artist,
                    album,
                    albumId,
                    duration,
                    name,
                    "",
                    "saf:" + root.uri,
                    root.name,
                    year,
                    modified,
                    lyricUri);
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                retriever.release();
            } catch (Throwable ignored) {
                // 忽略
            }
        }
    }

    private static long parseLong(String text) {
        try {
            return Long.parseLong(text);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String baseName(String name) {
        String lower = name.toLowerCase();
        int dot = lower.lastIndexOf('.');
        return dot > 0 ? lower.substring(0, dot) : lower;
    }

    private static String stripExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }
}
