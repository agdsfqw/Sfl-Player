package com.sflplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.widget.Toast;

/** 音频信息弹层：现场读取元数据，读完即释放。 */
public final class InfoDialog {

    private InfoDialog() {
    }

    public static void show(final Activity activity, final Track track) {
        if (track == null) {
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String text = build(activity, track);
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        new AlertDialog.Builder(activity)
                                .setTitle(R.string.audio_info)
                                .setMessage(text)
                                .setPositiveButton(R.string.copy, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        ClipboardManager cm = (ClipboardManager) activity
                                                .getSystemService(Activity.CLIPBOARD_SERVICE);
                                        if (cm != null) {
                                            cm.setPrimaryClip(ClipData.newPlainText("audio", text));
                                            Toast.makeText(activity, R.string.copied, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                })
                                .setNegativeButton(R.string.close, null)
                                .show();
                    }
                });
            }
        }).start();
    }

    private static String build(Activity activity, Track track) {
        StringBuilder sb = new StringBuilder();
        sb.append(activity.getString(R.string.info_title, track.title)).append('\n');
        sb.append(activity.getString(R.string.info_artist, track.artist)).append('\n');
        sb.append(activity.getString(R.string.info_album, track.album == null || track.album.isEmpty() ? "—" : track.album)).append('\n');
        sb.append(activity.getString(R.string.info_duration, Track.format(track.duration))).append('\n');
        sb.append(activity.getString(R.string.info_folder, track.relativePath == null ? "" : track.relativePath)).append('\n');
        sb.append(activity.getString(R.string.info_file, track.displayName == null ? "" : track.displayName)).append('\n');
        sb.append("URI：").append(track.uri).append('\n');

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(activity, Uri.parse(track.uri));
            sb.append(activity.getString(R.string.info_format, value(retriever, MediaMetadataRetriever.METADATA_KEY_MIMETYPE)));
            sb.append('\n');
            sb.append(activity.getString(R.string.info_bitrate, toKbps(retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_BITRATE)))).append('\n');
            sb.append(activity.getString(R.string.info_sample_rate, value(retriever,
                    MediaMetadataRetriever.METADATA_KEY_SAMPLERATE))).append('\n');
            sb.append(activity.getString(R.string.info_tracks, value(retriever,
                    MediaMetadataRetriever.METADATA_KEY_NUM_TRACKS))).append('\n');
            sb.append(activity.getString(R.string.info_year, value(retriever, MediaMetadataRetriever.METADATA_KEY_YEAR))).append('\n');
            byte[] art = retriever.getEmbeddedPicture();
            if (art != null && art.length > 0) {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(art, 0, art.length, bounds);
                sb.append(activity.getString(R.string.info_cover, bounds.outWidth, bounds.outHeight))
                        .append("（").append(art.length / 1024).append(" KB）").append('\n');
            } else {
                sb.append(activity.getString(R.string.info_no_cover)).append('\n');
            }
        } catch (Throwable t) {
            sb.append(activity.getString(R.string.info_metadata_failed, String.valueOf(t.getMessage()))).append('\n');
        } finally {
            try {
                retriever.release();
            } catch (Throwable ignored) {
                // 忽略
            }
        }

        long size = 0;
        Cursor cursor = null;
        try {
            cursor = activity.getContentResolver().query(Uri.parse(track.uri),
                    new String[]{OpenableColumns.SIZE}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                size = cursor.getLong(0);
            }
        } catch (Exception ignored) {
            // 忽略
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        sb.append(activity.getString(R.string.info_file_size, size > 0 ? String.format("%.1f MB", size / 1048576.0) : "—"));
        return sb.toString();
    }

    private static String value(MediaMetadataRetriever retriever, int key) {
        try {
            String v = retriever.extractMetadata(key);
            return v == null || v.isEmpty() ? "—" : v;
        } catch (Throwable t) {
            return "—";
        }
    }

    private static String toKbps(String bitrate) {
        if (bitrate == null || bitrate.isEmpty()) {
            return "—";
        }
        try {
            return (Long.parseLong(bitrate) / 1000) + " kbps";
        } catch (NumberFormatException e) {
            return "—";
        }
    }
}
