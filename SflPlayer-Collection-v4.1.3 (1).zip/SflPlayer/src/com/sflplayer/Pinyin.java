package com.sflplayer;

import android.os.Build;

import java.util.HashMap;
import java.util.Locale;

/** 中文拼音匹配：Android 10+ 用 ICU 转写，低版本退化为原文匹配。 */
public final class Pinyin {

    private static android.icu.text.Transliterator transliterator;
    private static boolean initialized;
    private static final HashMap<String, String[]> CACHE = new HashMap<>();

    private Pinyin() {
    }

    public static boolean matches(String text, String query) {
        if (text == null) {
            return false;
        }
        String lower = text.toLowerCase(Locale.ROOT);
        if (lower.contains(query)) {
            return true;
        }
        if (query.isEmpty() || Build.VERSION.SDK_INT < 29) {
            return false;
        }
        String[] translated = get(text);
        return translated != null
                && (translated[0].contains(query) || translated[1].contains(query));
    }

    private static String[] get(String text) {
        synchronized (CACHE) {
            String[] cached = CACHE.get(text);
            if (cached != null) {
                return cached;
            }
        }
        String[] result;
        try {
            if (!initialized) {
                transliterator = android.icu.text.Transliterator
                        .getInstance("Han-Latin; Latin-ASCII");
                initialized = true;
            }
            String latin = transliterator.transliterate(text);
            StringBuilder full = new StringBuilder();
            StringBuilder initials = new StringBuilder();
            boolean wordStart = true;
            for (int i = 0; i < latin.length(); i++) {
                char c = Character.toLowerCase(latin.charAt(i));
                if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                    full.append(c);
                    if (wordStart) {
                        initials.append(c);
                        wordStart = false;
                    }
                } else {
                    wordStart = true;
                }
            }
            result = new String[]{full.toString(), initials.toString()};
        } catch (Throwable t) {
            result = null;
        }
        synchronized (CACHE) {
            if (CACHE.size() > 5000) {
                CACHE.clear();
            }
            CACHE.put(text, result);
        }
        return result;
    }
}
