package com.sflplayer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TrackAdapter extends BaseAdapter implements ScrollPause.Pausable {

    public interface OnFavoriteToggle {
        void onToggle(Track track);
    }

    private final Context context;
    private final LayoutInflater inflater;
    private final OnFavoriteToggle listener;
    private final int colorText;
    private final int colorDim;
    private final int colorAccent;
    private List<Track> tracks = new ArrayList<>();
    private Set<String> favorites = new HashSet<>();
    private boolean scrolling;
    private Set<String> selected = new HashSet<>();
    private String currentUri;

    public TrackAdapter(Context context, OnFavoriteToggle listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        inflater = LayoutInflater.from(context);
        colorText = color(context, R.attr.colorText);
        colorDim = color(context, R.attr.colorTextDim);
        colorAccent = color(context, R.attr.colorAccent);
    }

    private static int color(Context context, int attr) {
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    public List<Track> getTracks() {
        return tracks;
    }

    public void setTracks(List<Track> list) {
        tracks = list;
        notifyDataSetChanged();
    }

    @Override
    public void setScrolling(boolean scrolling) {
        this.scrolling = scrolling;
    }

    public void setFavorites(Set<String> uris) {
        favorites = uris;
        notifyDataSetChanged();
    }

    public void setSelected(Set<String> uris) {
        selected = uris;
        notifyDataSetChanged();
    }

    public void setCurrentUri(String uri) {
        if (currentUri != null && currentUri.equals(uri)) {
            return;
        }
        currentUri = uri;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return tracks.size();
    }

    @Override
    public Track getItem(int position) {
        return tracks.get(position);
    }

    @Override
    public long getItemId(int position) {
        return tracks.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_track, parent, false);
            holder = new Holder();
            holder.cover = convertView.findViewById(R.id.cover);
            holder.coverHint = convertView.findViewById(R.id.cover_hint);
            holder.title = convertView.findViewById(R.id.title);
            holder.artist = convertView.findViewById(R.id.artist);
            holder.dur = convertView.findViewById(R.id.dur);
        holder.quality = convertView.findViewById(R.id.quality);
            holder.fav = convertView.findViewById(R.id.fav);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        final Track track = tracks.get(position);
        boolean current = track.uri.equals(currentUri);
        if (selected.contains(track.uri)) {
            convertView.setBackgroundColor(0x335B8CFF);
        } else {
            convertView.setBackgroundColor(Color.TRANSPARENT);
        }
        holder.title.setText(track.title);
        holder.artist.setText(track.artist);
        final String qualityKey = track.uri;
        holder.quality.setTag(qualityKey);
        Quality quick = QualityLoader.formatOnly(track);
        holder.quality.setText(quick.shortLabel);
        holder.quality.getBackground().mutate().setTint(quick.color);
        holder.quality.setVisibility(View.VISIBLE);
        QualityLoader.request(context, track, new QualityLoader.Callback() {
            @Override
            public void onQuality(String uri, Quality quality) {
                if (qualityKey.equals(holder.quality.getTag())) {
                    holder.quality.setText(quality.shortLabel);
                    holder.quality.getBackground().mutate().setTint(quality.color);
                    holder.quality.setVisibility(View.VISIBLE);
                }
            }
        });
        holder.dur.setText(Track.format(track.duration));
        holder.title.setTextColor(current ? colorAccent : colorText);
        holder.artist.setTextColor(current ? colorAccent : colorDim);

        boolean favorite = favorites.contains(track.uri);
        holder.fav.setImageResource(favorite ? R.drawable.ic_heart_filled : R.drawable.ic_heart);
        holder.fav.setContentDescription(context.getString(
                favorite ? R.string.unfavorite : R.string.favorite));
        holder.fav.setColorFilter(favorite ? colorAccent : colorDim);
        holder.fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onToggle(track);
                }
            }
        });

        final ImageView cover = holder.cover;
        final ImageView hint = holder.coverHint;
        cover.setTag(track.uri);
        cover.setImageDrawable(null);
        hint.setVisibility(View.VISIBLE);
        ArtLoader.load(context, CustomArtStore.albumKey(track), track.uri, 128, new ArtLoader.Callback() {
            @Override
            public void onArt(String uri, Bitmap bitmap) {
                if (bitmap != null && uri.equals(cover.getTag())) {
                    cover.setImageBitmap(bitmap);
                    hint.setVisibility(View.GONE);
                }
            }
        });
        return convertView;
    }

    private static class Holder {
        ImageView cover;
        ImageView coverHint;
        TextView title;
        TextView artist;
        TextView quality;
        TextView dur;
        ImageButton fav;
    }
}
