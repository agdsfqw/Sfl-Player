package com.sflplayer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Prefs {

    public static final int THEME_FOLLOW = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    private final SharedPreferences sp;

    public Prefs(Context context) {
        sp = context.getSharedPreferences("sfl", Context.MODE_PRIVATE);
    }

    public int ballX() {
        return sp.getInt("ball_x", -1);
    }

    public int ballY() {
        return sp.getInt("ball_y", -1);
    }

    public void setBallPosition(int x, int y) {
        sp.edit().putInt("ball_x", x).putInt("ball_y", y).apply();
    }

    public int sortMode() {
        return sp.getInt("sort_mode", 0);
    }

    public void setSortMode(int mode) {
        sp.edit().putInt("sort_mode", mode).apply();
    }

    public boolean reduceMotion() {
        return sp.getBoolean("reduce_motion", false);
    }

    public void setReduceMotion(boolean value) {
        sp.edit().putBoolean("reduce_motion", value).apply();
    }

    public int glassMaterial() {
        return sp.getInt("glass_material", 0);
    }

    public void setGlassMaterial(int value) {
        sp.edit().putInt("glass_material", value == 1 ? 1 : 0).apply();
    }

    public int frostedGlass() {
        return sp.getInt("frosted_glass", -1);
    }

    public void setFrostedGlass(int value) {
        sp.edit().putInt("frosted_glass", value).apply();
    }

    public int backgroundPreset() {
        return sp.getInt("bg_preset", 0);
    }

    public void setBackgroundPreset(int value) {
        sp.edit().putInt("bg_preset", Math.max(0, Math.min(2, value))).apply();
    }

    public int accentHue() {
        return sp.getInt("accent_hue", 218);
    }

    public void setAccentHue(int hue) {
        sp.edit().putInt("accent_hue", ((hue % 360) + 360) % 360).apply();
    }

    public float speed() {
        return sp.getFloat("speed", 1.0f);
    }

    public void setSpeed(float value) {
        sp.edit().putFloat("speed", value).apply();
    }

    public float fadeSeconds() {
        return sp.getFloat("fade_seconds", 0.6f);
    }

    public void setFadeSeconds(float value) {
        sp.edit().putFloat("fade_seconds", value).apply();
    }

    public int equalizerPreset() {
        return equalizerPreset(0);
    }

    public void setEqualizerPreset(int preset) {
        setEqualizerPreset(0, preset);
    }

    public int equalizerPreset(int device) {
        return sp.getInt("eq_preset_d" + device, sp.getInt("eq_preset", -1));
    }

    public void setEqualizerPreset(int device, int preset) {
        sp.edit().putInt("eq_preset_d" + device, preset).apply();
    }

    public String equalizerBands() {
        return equalizerBands(0);
    }

    public void setEqualizerBands(String json) {
        setEqualizerBands(0, json);
    }

    public String equalizerBands(int device) {
        return sp.getString("eq_bands_d" + device, sp.getString("eq_bands", ""));
    }

    public void setEqualizerBands(int device, String json) {
        sp.edit().putString("eq_bands_d" + device, json).apply();
    }

    public int lyricOffset(String uri) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(
                    sp.getString("lyric_offsets", "{}"));
            return all.optInt(uri, 0);
        } catch (Exception e) {
            return 0;
        }
    }

    public void setLyricOffset(String uri, int offset) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(
                    sp.getString("lyric_offsets", "{}"));
            all.put(uri, offset);
            sp.edit().putString("lyric_offsets", all.toString()).apply();
        } catch (Exception ignored) {
            // 忽略
        }
    }

    public boolean notificationPrompted() {
        return sp.getBoolean("notification_prompted", false);
    }

    public void setNotificationPrompted(boolean value) {
        sp.edit().putBoolean("notification_prompted", value).apply();
    }

    public void addBookmark(String uri, int position) {
        addBookmark(uri, position, "");
    }

    public void addBookmark(String uri, int position, String note) {
        try {
            org.json.JSONObject all = bookmarks();
            org.json.JSONArray array = normalize(all.optJSONArray(uri));
            for (int i = 0; i < array.length(); i++) {
                org.json.JSONObject item = array.optJSONObject(i);
                if (item != null && Math.abs(item.optInt("p") - position) < 5000) {
                    item.put("n", note == null ? "" : note);
                    all.put(uri, array);
                    sp.edit().putString("bookmarks", all.toString()).apply();
                    return;
                }
            }
            org.json.JSONObject item = new org.json.JSONObject();
            item.put("p", position);
            item.put("n", note == null ? "" : note);
            array.put(item);
            while (array.length() > 5) {
                array.remove(0);
            }
            all.put(uri, array);
            sp.edit().putString("bookmarks", all.toString()).apply();
        } catch (Exception ignored) {
            // 忽略
        }
    }

    public org.json.JSONObject allBookmarks() {
        org.json.JSONObject raw = bookmarks();
        org.json.JSONObject normalized = new org.json.JSONObject();
        try {
            java.util.Iterator<String> keys = raw.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                normalized.put(key, normalize(raw.optJSONArray(key)));
            }
        } catch (Exception ignored) {
            // 忽略
        }
        return normalized;
    }

    public void removeBookmark(String uri, int position) {
        try {
            org.json.JSONObject all = bookmarks();
            org.json.JSONArray array = normalize(all.optJSONArray(uri));
            org.json.JSONArray kept = new org.json.JSONArray();
            for (int i = 0; i < array.length(); i++) {
                org.json.JSONObject item = array.optJSONObject(i);
                if (item != null && Math.abs(item.optInt("p") - position) > 3000) {
                    kept.put(item);
                }
            }
            if (kept.length() == 0) {
                all.remove(uri);
            } else {
                all.put(uri, kept);
            }
            sp.edit().putString("bookmarks", all.toString()).apply();
        } catch (Exception ignored) {
            // 忽略
        }
    }

    /** 旧数据是纯数字数组，这里统一成 [{p,n}]。 */
    public org.json.JSONArray getBookmarks(String uri) {
        return normalize(bookmarks().optJSONArray(uri));
    }

    private org.json.JSONArray normalize(org.json.JSONArray array) {
        org.json.JSONArray out = new org.json.JSONArray();
        if (array == null) {
            return out;
        }
        for (int i = 0; i < array.length(); i++) {
            Object raw = array.opt(i);
            try {
                if (raw instanceof org.json.JSONObject) {
                    out.put(raw);
                } else if (raw instanceof Number) {
                    org.json.JSONObject item = new org.json.JSONObject();
                    item.put("p", ((Number) raw).intValue());
                    item.put("n", "");
                    out.put(item);
                }
            } catch (Exception ignored) {
                // 跳过损坏项
            }
        }
        return out;
    }

    public void setLastPosition(String uri, int position) {
        try {
            org.json.JSONObject all = lastPositions();
            all.put(uri, position);
            sp.edit().putString("last_positions", all.toString()).apply();
        } catch (Exception ignored) {
            // 忽略
        }
    }

    public int getLastPosition(String uri) {
        return lastPositions().optInt(uri, 0);
    }

    private org.json.JSONObject bookmarks() {
        try {
            return new org.json.JSONObject(sp.getString("bookmarks", "{}"));
        } catch (Exception e) {
            return new org.json.JSONObject();
        }
    }

    private org.json.JSONObject lastPositions() {
        try {
            return new org.json.JSONObject(sp.getString("last_positions", "{}"));
        } catch (Exception e) {
            return new org.json.JSONObject();
        }
    }

    public void setWidgetState(String title, String artist, boolean playing) {
        sp.edit().putString("widget_title", title)
                .putString("widget_artist", artist)
                .putBoolean("widget_playing", playing).apply();
    }

    public String widgetTitle() {
        return sp.getString("widget_title", "Sfl Player");
    }

    public String widgetArtist() {
        return sp.getString("widget_artist", "");
    }

    public boolean widgetPlaying() {
        return sp.getBoolean("widget_playing", false);
    }

    public org.json.JSONObject exportAll() {
        org.json.JSONObject out = new org.json.JSONObject();
        try {
            for (java.util.Map.Entry<String, ?> entry : sp.getAll().entrySet()) {
                Object value = entry.getValue();
                if (value instanceof java.util.Set) {
                    org.json.JSONArray array = new org.json.JSONArray();
                    for (Object item : (java.util.Set<?>) value) {
                        array.put(String.valueOf(item));
                    }
                    out.put(entry.getKey(), array);
                } else {
                    out.put(entry.getKey(), value);
                }
            }
        } catch (Exception ignored) {
            // 忽略
        }
        return out;
    }

    public void importAll(org.json.JSONObject data) {
        if (data == null) {
            return;
        }
        android.content.SharedPreferences.Editor editor = sp.edit();
        java.util.Iterator<String> keys = data.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = data.opt(key);
            try {
                if (value instanceof org.json.JSONArray) {
                    org.json.JSONArray array = (org.json.JSONArray) value;
                    java.util.HashSet<String> set = new java.util.HashSet<>();
                    for (int i = 0; i < array.length(); i++) {
                        set.add(array.optString(i));
                    }
                    editor.putStringSet(key, set);
                } else if (value instanceof Boolean) {
                    editor.putBoolean(key, (Boolean) value);
                } else if (value instanceof Integer) {
                    editor.putInt(key, (Integer) value);
                } else if (value instanceof Long) {
                    editor.putLong(key, (Long) value);
                } else if (value instanceof Number) {
                    editor.putFloat(key, ((Number) value).floatValue());
                } else if (value != null && value != org.json.JSONObject.NULL) {
                    editor.putString(key, String.valueOf(value));
                }
            } catch (Exception ignored) {
                // 跳过损坏字段
            }
        }
        editor.apply();
    }

    public org.json.JSONObject metaOverrides() {
        try {
            return new org.json.JSONObject(sp.getString("meta_overrides", "{}"));
        } catch (Exception e) {
            return new org.json.JSONObject();
        }
    }

    public void setMetaOverride(String uri, String title, String artist, String album) {
        try {
            org.json.JSONObject all = metaOverrides();
            org.json.JSONObject item = new org.json.JSONObject();
            item.put("title", title);
            item.put("artist", artist);
            item.put("album", album);
            all.put(uri, item);
            sp.edit().putString("meta_overrides", all.toString()).apply();
        } catch (Exception ignored) {
            // 忽略
        }
    }

    public ArrayList<String> searchHistory() {
        ArrayList<String> out = new ArrayList<>();
        try {
            org.json.JSONArray array = new org.json.JSONArray(sp.getString("search_history", "[]"));
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i);
                if (value != null && !value.isEmpty()) {
                    out.add(value);
                }
            }
        } catch (Exception ignored) {
            // 忽略
        }
        return out;
    }

    public void addSearchHistory(String query) {
        if (query == null) {
            return;
        }
        String value = query.trim();
        if (value.isEmpty()) {
            return;
        }
        ArrayList<String> list = searchHistory();
        list.remove(value);
        list.add(0, value);
        while (list.size() > 12) {
            list.remove(list.size() - 1);
        }
        org.json.JSONArray array = new org.json.JSONArray();
        for (String item : list) {
            array.put(item);
        }
        sp.edit().putString("search_history", array.toString()).apply();
    }

    public void clearSearchHistory() {
        sp.edit().putString("search_history", "[]").apply();
    }

    public boolean lyricsMode() {
        return sp.getBoolean("lyrics_mode", false);
    }

    public void setLyricsMode(boolean value) {
        sp.edit().putBoolean("lyrics_mode", value).apply();
    }

    public int searchMode() {
        return sp.getInt("search_mode", 0);
    }

    public void setSearchMode(int mode) {
        sp.edit().putInt("search_mode", mode).apply();
    }

    public int theme() {
        return sp.getInt("theme", THEME_FOLLOW);
    }

    public void setTheme(int value) {
        sp.edit().putInt("theme", value).apply();
    }

    public boolean resume() {
        return sp.getBoolean("resume", true);
    }

    public void setResume(boolean value) {
        sp.edit().putBoolean("resume", value).apply();
    }

    public boolean headset() {
        return sp.getBoolean("headset", true);
    }

    public void setHeadset(boolean value) {
        sp.edit().putBoolean("headset", value).apply();
    }

    public boolean confirmSingle() {
        return sp.getBoolean("confirm_single", true);
    }

    public void setConfirmSingle(boolean value) {
        sp.edit().putBoolean("confirm_single", value).apply();
    }

    public String queueJson() {
        return sp.getString("queue", null);
    }

    public void saveQueue(String json, int index, int position) {
        sp.edit().putString("queue", json)
                .putInt("queue_index", index)
                .putInt("queue_pos", position)
                .apply();
    }

    public int queueIndex() {
        return sp.getInt("queue_index", 0);
    }

    public int queuePos() {
        return sp.getInt("queue_pos", 0);
    }

    // ------------------------------------------------------------ 文件夹与隐藏

    public Set<String> selectedFolders() {
        return new HashSet<>(sp.getStringSet("folders", Collections.<String>emptySet()));
    }

    public void setSelectedFolders(Set<String> keys) {
        sp.edit().putStringSet("folders", new HashSet<>(keys))
                .putBoolean("folders_configured", true)
                .apply();
        markLibraryChanged();
    }

    public boolean foldersConfigured() {
        return sp.getBoolean("folders_configured", false);
    }

    public Set<String> hiddenTracks() {
        return new HashSet<>(sp.getStringSet("hidden", Collections.<String>emptySet()));
    }

    public void setHiddenTracks(Set<String> uris) {
        sp.edit().putStringSet("hidden", new HashSet<>(uris)).apply();
        markLibraryChanged();
    }

    public void markLibraryChanged() {
        sp.edit().putInt("lib_rev", sp.getInt("lib_rev", 0) + 1).apply();
    }

    public int libraryRevision() {
        return sp.getInt("lib_rev", 0);
    }

    // ------------------------------------------------------------ 收藏

    public Set<String> favorites() {
        return new HashSet<>(sp.getStringSet("favorites", Collections.<String>emptySet()));
    }

    public void setFavorites(Set<String> uris) {
        sp.edit().putStringSet("favorites", new HashSet<>(uris)).apply();
    }

    // ------------------------------------------------------------ 最近播放

    public List<String> recent() {
        ArrayList<String> out = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(sp.getString("recent", "[]"));
            for (int i = 0; i < array.length(); i++) {
                out.add(array.optString(i));
            }
        } catch (JSONException ignored) {
            // 忽略损坏数据
        }
        return out;
    }

    public void addRecent(String uri) {
        if (uri == null) {
            return;
        }
        List<String> list = recent();
        list.remove(uri);
        list.add(0, uri);
        while (list.size() > 100) {
            list.remove(list.size() - 1);
        }
        JSONArray array = new JSONArray();
        for (String item : list) {
            array.put(item);
        }
        sp.edit().putString("recent", array.toString()).apply();
    }

    // ------------------------------------------------------------ 播放统计

    public JSONObject stats() {
        try {
            return new JSONObject(sp.getString("stats", "{}"));
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    public void addPlayed(String uri, long durationMs) {
        if (uri == null) {
            return;
        }
        try {
            JSONObject stats = stats();
            JSONObject item = stats.optJSONObject(uri);
            if (item == null) {
                item = new JSONObject();
            }
            item.put("c", item.optInt("c") + 1);
            item.put("t", item.optLong("t") + Math.max(0, durationMs));
            item.put("l", System.currentTimeMillis());
            stats.put(uri, item);
            sp.edit().putString("stats", stats.toString()).apply();
        } catch (JSONException ignored) {
            // 忽略
        }
    }

    public void clearStats() {
        sp.edit().remove("stats").apply();
    }
}
