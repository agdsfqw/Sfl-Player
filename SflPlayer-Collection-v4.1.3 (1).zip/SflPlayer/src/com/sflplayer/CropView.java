package com.sflplayer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** 方形取景框：拖动、双指缩放，导出取景框内的图像。 */
public class CropView extends View {

    private Bitmap bitmap;
    private final Matrix matrix = new Matrix();
    private final ScaleGestureDetector scaleDetector;
    private final RectF rect = new RectF();
    private float lastX;
    private float lastY;

    public CropView(Context context) {
        this(context, null);
    }

    public CropView(Context context, AttributeSet attrs) {
        super(context, attrs);
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.OnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                if (bitmap == null) {
                    return false;
                }
                matrix.postScale(detector.getScaleFactor(), detector.getScaleFactor(),
                        detector.getFocusX(), detector.getFocusY());
                clampAndCover();
                invalidate();
                return true;
            }

            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
            }
        });
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
        reset();
        invalidate();
    }

    private void reset() {
        matrix.reset();
        if (bitmap == null || getWidth() == 0 || getHeight() == 0) {
            return;
        }
        float scale = Math.max((float) getWidth() / bitmap.getWidth(),
                (float) getHeight() / bitmap.getHeight());
        matrix.postScale(scale, scale);
        matrix.postTranslate((getWidth() - bitmap.getWidth() * scale) / 2f,
                (getHeight() - bitmap.getHeight() * scale) / 2f);
        clampAndCover();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        reset();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (bitmap == null) {
            return false;
        }
        scaleDetector.onTouchEvent(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (event.getPointerCount() == 1) {
                    matrix.postTranslate(event.getX() - lastX, event.getY() - lastY);
                    lastX = event.getX();
                    lastY = event.getY();
                    clampAndCover();
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    /** 保证图片始终铺满取景框，并把移出边界的位置拉回。 */
    private void clampAndCover() {
        if (bitmap == null) {
            return;
        }
        rect.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
        matrix.mapRect(rect);
        float scaleX = getWidth() / rect.width();
        float scaleY = getHeight() / rect.height();
        float scale = Math.max(scaleX, scaleY);
        if (scale > 1f) {
            matrix.postScale(scale, scale, getWidth() / 2f, getHeight() / 2f);
            rect.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
            matrix.mapRect(rect);
        }
        float dx = 0;
        float dy = 0;
        if (rect.left > 0) {
            dx = -rect.left;
        } else if (rect.right < getWidth()) {
            dx = getWidth() - rect.right;
        }
        if (rect.top > 0) {
            dy = -rect.top;
        } else if (rect.bottom < getHeight()) {
            dy = getHeight() - rect.bottom;
        }
        if (dx != 0 || dy != 0) {
            matrix.postTranslate(dx, dy);
        }
    }

    public Bitmap export() {
        if (bitmap == null || getWidth() == 0) {
            return null;
        }
        Bitmap out = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(0xFF000000);
        canvas.drawBitmap(bitmap, matrix, null);
        return out;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, matrix, null);
        }
    }
}
