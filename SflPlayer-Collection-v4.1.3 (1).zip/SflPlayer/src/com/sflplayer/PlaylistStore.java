package com.sflplayer;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 歌单持久化：filesDir/playlists.json，写入走临时文件再改名。 */
public final class PlaylistStore {

    private static final String FILE = "playlists.json";

    private PlaylistStore() {
    }

    public static synchronized ArrayList<Playlist> load(Context context) {
        ArrayList<Playlist> out = new ArrayList<>();
        File file = new File(context.getFilesDir(), FILE);
        if (!file.exists()) {
            return out;
        }
        try {
            String text = read(file);
            JSONArray array = new JSONArray(text);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o != null) {
                    out.add(Playlist.fromJson(o));
                }
            }
        } catch (Exception e) {
            // 文件损坏时备份并返回空
            File backup = new File(context.getFilesDir(), FILE + ".bak");
            file.renameTo(backup);
            out.clear();
        }
        return out;
    }

    public static synchronized void save(Context context, List<Playlist> playlists) {
        try {
            JSONArray array = new JSONArray();
            for (Playlist playlist : playlists) {
                array.put(playlist.toJson());
            }
            File file = new File(context.getFilesDir(), FILE);
            File temp = new File(context.getFilesDir(), FILE + ".tmp");
            FileOutputStream out = new FileOutputStream(temp);
            out.write(array.toString().getBytes(StandardCharsets.UTF_8));
            out.close();
            if (!temp.renameTo(file)) {
                file.delete();
                temp.renameTo(file);
            }
        } catch (Exception ignored) {
            // 写入失败时保留旧文件
        }
    }

    private static String read(File file) throws Exception {
        InputStream in = new FileInputStream(file);
        byte[] buffer = new byte[(int) file.length()];
        int read = in.read(buffer);
        in.close();
        return new String(buffer, 0, Math.max(0, read), StandardCharsets.UTF_8);
    }
}
