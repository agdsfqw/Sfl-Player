package com.sflplayer;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

/** 播放统计：只统计完整听完的歌曲。 */
public class StatsActivity extends BaseActivity {

    private final ArrayList<Row> rows = new ArrayList<>();
    private TextView summary;
    private TextView empty;

    private static class Row {
        String title;
        int count;
        long totalMs;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        summary = findViewById(R.id.stats_summary);
        empty = findViewById(R.id.stats_empty);
        ListView list = findViewById(R.id.stats_list);
        list.setAdapter(new StatsAdapter());

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        load(list);
    }

    private void load(final ListView list) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Prefs prefs = new Prefs(StatsActivity.this);
                JSONObject stats = prefs.stats();
                HashMap<String, String> titles = new HashMap<>();
                for (Track track : Library.load(StatsActivity.this)) {
                    titles.put(track.uri, track.title);
                }
                ArrayList<Row> result = new ArrayList<>();
                int totalCount = 0;
                long totalMs = 0;
                java.util.Iterator<String> keys = stats.keys();
                while (keys.hasNext()) {
                    String uri = keys.next();
                    JSONObject item = stats.optJSONObject(uri);
                    if (item == null) {
                        continue;
                    }
                    Row row = new Row();
                    row.title = titles.containsKey(uri) ? titles.get(uri) : uri;
                    row.count = item.optInt("c");
                    row.totalMs = item.optLong("t");
                    totalCount += row.count;
                    totalMs += row.totalMs;
                    if (row.count > 0) {
                        result.add(row);
                    }
                }
                Collections.sort(result, new Comparator<Row>() {
                    @Override
                    public int compare(Row a, Row b) {
                        return Integer.compare(b.count, a.count);
                    }
                });
                final int count = totalCount;
                final long duration = totalMs;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rows.clear();
                        rows.addAll(result);
                        ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
                        summary.setText(getString(R.string.stats_summary, count, format(duration)));
                        empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                    }
                });
            }
        }).start();
    }

    private String format(long ms) {
        long totalMinutes = ms / 60000;
        long hours = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        return hours > 0 ? getString(R.string.stats_hours, hours, minutes) : getString(R.string.stats_minutes, minutes);
    }

    private class StatsAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Row getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_stat, parent, false);
            }
            Row row = rows.get(position);
            TextView title = view.findViewById(R.id.s_title);
            TextView sub = view.findViewById(R.id.s_sub);
            title.setText(row.title);
            sub.setText(getString(R.string.count_times, row.count) + " · " + format(row.totalMs));
            return view;
        }
    }
}
