package com.sflplayer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

/** 从音频内嵌封面解码出指定尺寸附近的位图；失败返回 null。 */
public final class Art {

    private Art() {
    }

    public static Bitmap load(Context context, String uri, int target) {
        try {
            Bitmap bitmap = decode(context, uri, target);
            if (bitmap != null) {
                return bitmap;
            }
            return decode(context, uri, Math.max(256, target / 2));
        } catch (OutOfMemoryError error) {
            System.gc();
            try {
                return decode(context, uri, Math.max(256, target / 4));
            } catch (Throwable ignored) {
                return null;
            }
        }
    }

    private static Bitmap decode(Context context, String uri, int target) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, Uri.parse(uri));
            byte[] data = retriever.getEmbeddedPicture();
            if (data == null || data.length == 0) {
                return null;
            }
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            int sample = 1;
            int width = Math.max(1, bounds.outWidth);
            while (width / (sample * 2) >= target) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            if (target <= 256) {
                options.inPreferredConfig = Bitmap.Config.RGB_565;
            }
            return BitmapFactory.decodeByteArray(data, 0, data.length, options);
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                retriever.release();
            } catch (Throwable ignored) {
                // 忽略
            }
        }
    }
}
