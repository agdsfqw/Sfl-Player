package com.sflplayer;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.Layout;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class PlayerActivity extends BaseActivity implements PlayerService.Listener {

    private final Handler ui = new Handler(Looper.getMainLooper());

    private View content;
    private View mediaArea;
    private View spacer;
    private View coverBox;
    private ImageView art;
    private ImageView playerBg;
    private TextView qualityView;
    private ImageView placeholder;
    private ScrollView lyricsScroll;
    private TextView lyrics;
    private TextView title;
    private TextView artist;
    private TextView album;
    private SeekBar seek;
    private TextView curTime;
    private TextView totalTime;
    private ImageButton playButton;
    private ImageButton modeButton;
    private ImageButton timerButton;
    private TextView speedLabel;

    private PlayerService service;
    private Prefs prefs;
    private boolean bound;
    private boolean lyricsMode;
    private float downY;
    private float downX;
    private boolean draggingView;
    private long currentTrackId = -1;
    private int artToken;
    private Bitmap currentArt;
    private boolean lastPlaying;
    private Lyrics.Data lyricsData = Lyrics.Data.empty();
    private int lyricLine = -1;
    private boolean userSeeking;
    private long coverDownTime;
    private int lyricOffset;
    private long sharedTrackId = -1;
    private float titleDownX;
    private float titleDownY;
    private boolean titleLongPressed;
    private boolean titleMenuShown;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            ui.postDelayed(this, 500);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((PlayerService.LocalBinder) binder).service();
            service.addListener(PlayerActivity.this);
            sync();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        getWindow().setWindowAnimations(0);
        prefs = new Prefs(this);
        bindViews();
        setupActions();
        setupGestures();
        hideThumb(seek, false);
    }

    private void bindViews() {
        content = findViewById(R.id.player_content);
        mediaArea = findViewById(R.id.media_area);
        spacer = findViewById(R.id.spacer);
        coverBox = findViewById(R.id.cover_box);
        art = findViewById(R.id.art);
        playerBg = findViewById(R.id.player_bg);
        placeholder = findViewById(R.id.art_placeholder);
        qualityView = findViewById(R.id.quality);
        TransitionArt.Data shared = TransitionArt.take();
        if (shared != null && shared.bitmap != null) {
            sharedTrackId = shared.trackId;
            art.setTransitionName("player_cover");
            art.setImageBitmap(shared.bitmap);
            art.setVisibility(View.VISIBLE);
            placeholder.setVisibility(View.GONE);
            currentArt = shared.bitmap;
        }
        android.transition.ChangeBounds bounds = new android.transition.ChangeBounds();
        bounds.setDuration(240);
        getWindow().setSharedElementEnterTransition(bounds);
        getWindow().setSharedElementReturnTransition(bounds);
        lyricsScroll = findViewById(R.id.lyrics_scroll);
        lyrics = findViewById(R.id.lyrics);
        title = findViewById(R.id.title);
        artist = findViewById(R.id.artist);
        album = findViewById(R.id.album);
        seek = findViewById(R.id.seek);
        curTime = findViewById(R.id.cur_time);
        totalTime = findViewById(R.id.total_time);
        playButton = findViewById(R.id.play);
        modeButton = findViewById(R.id.mode);
        timerButton = findViewById(R.id.timer);
        speedLabel = findViewById(R.id.speed_label);
    }

    private void setupActions() {
        findViewById(R.id.close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.toggle();
                }
            }
        });
        findViewById(R.id.prev).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.prev();
                }
            }
        });
        findViewById(R.id.next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null) {
                    service.next();
                }
            }
        });
        modeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service == null) {
                    return;
                }
                int mode = service.cycleMode();
                updateMode();
                toast(getString(mode == PlayerService.MODE_SHUFFLE ? R.string.mode_shuffle
                        : mode == PlayerService.MODE_REPEAT ? R.string.mode_repeat
                        : R.string.mode_sequence));
            }
        });
        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service == null) {
                    return;
                }
                showSleepDialog();
            }
        });
        speedLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSpeedDialog();
            }
        });
        final GestureDetector abDetector = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public void onLongPress(MotionEvent e) {
                        showAbDialog();
                    }
                });
        seek.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                abDetector.onTouchEvent(event);
                return false;
            }
        });

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser && service != null) {
                    int duration = service.getDuration();
                    if (duration > 0) {
                        curTime.setText(Track.format((long) duration * progress / 1000));
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                userSeeking = true;
                hideThumb(bar, true);
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                userSeeking = false;
                if (service != null) {
                    int duration = service.getDuration();
                    if (duration > 0) {
                        service.seekTo(duration * bar.getProgress() / 1000);
                    }
                }
                hideThumb(bar, false);
            }
        });
    }

    private void setupGestures() {
        final GestureDetector titleDetector = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDoubleTap(MotionEvent e) {
                        if (!titleLongPressed) {
                            showInfo();
                        }
                        return true;
                    }
                });
        titleDetector.setIsLongpressEnabled(false);
        final int slop = android.view.ViewConfiguration.get(this).getScaledTouchSlop();
        final Runnable longPress = new Runnable() {
            @Override
            public void run() {
                titleLongPressed = true;
                titleMenuShown = true;
                showTrackMenu();
            }
        };
        title.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                titleDetector.onTouchEvent(event);
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        titleDownX = event.getRawX();
                        titleDownY = event.getRawY();
                        titleLongPressed = false;
                        titleMenuShown = false;
                        v.postDelayed(longPress, 500);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(event.getRawX() - titleDownX) > slop
                                || Math.abs(event.getRawY() - titleDownY) > slop) {
                            v.removeCallbacks(longPress);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.removeCallbacks(longPress);
                        return true;
                    default:
                        return false;
                }
            }
        });

        coverBox.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = event.getRawY();
                        downX = event.getRawX();
                        coverDownTime = event.getEventTime();
                        draggingView = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dy = event.getRawY() - downY;
                        float dx = Math.abs(event.getRawX() - downX);
                        if (dy > 12 && dy > dx) {
                            draggingView = true;
                            content.setTranslationY(dy);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        float delta = event.getRawY() - downY;
                        if (!draggingView && event.getEventTime() - coverDownTime > 600) {
                            openPreview();
                        } else if (!draggingView) {
                            showLyrics();
                        } else if (delta > dp(140)) {
                            closeWithSlide();
                        } else {
                            content.animate().translationY(0).setDuration(160).start();
                        }
                        draggingView = false;
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        content.animate().translationY(0).setDuration(160).start();
                        draggingView = false;
                        return true;
                    default:
                        return false;
                }
            }
        });

        final GestureDetector lyricsDetector = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        showCover();
                        return true;
                    }
                });
        lyricsScroll.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                lyricsDetector.onTouchEvent(event);
                return false;
            }
        });
        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null && service.currentTrack() != null) {
                    Intent intent = new Intent(PlayerActivity.this, ArtistDetailActivity.class);
                    intent.putExtra(ArtistDetailActivity.EXTRA_ARTIST, service.currentTrack().artist);
                    startActivity(intent);
                }
            }
        });
        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (service != null && service.currentTrack() != null) {
                    Track track = service.currentTrack();
                    Intent intent = new Intent(PlayerActivity.this, AlbumDetailActivity.class);
                    intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_ID, track.albumId);
                    intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_NAME, track.album);
                    startActivity(intent);
                }
            }
        });

        lyrics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCover();
            }
        });
    }

    private void showTrackMenu() {
        if (service == null || service.currentTrack() == null) {
            return;
        }
        final Track track = service.currentTrack();
        String[] items = {
                getString(R.string.audio_info),
                getString(R.string.add_to_playlist),
                getString(R.string.add_bookmark),
                getString(R.string.bookmarks),
                getString(R.string.ab_loop),
                getString(R.string.preview_cover),
                getString(R.string.lyric_offset)
        };
        new AlertDialog.Builder(this)
                .setTitle(track.title)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            InfoDialog.show(PlayerActivity.this, track);
                        } else if (which == 1) {
                            PlaylistPicker.show(PlayerActivity.this,
                                    java.util.Collections.singletonList(track.uri));
                        } else if (which == 2) {
                            addBookmarkWithNote(track);
                        } else if (which == 3) {
                            showBookmarks(track);
                        } else if (which == 4) {
                            showAbDialog();
                        } else if (which == 5) {
                            openPreview();
                        } else {
                            showLyricOffsetDialog(track);
                        }
                    }
                })
                .show();
    }

    private void showSleepDialog() {
        final int[] minutes = {service.getSleepMinutes()};
        final boolean[] finish = {service.isSleepFinishCurrent()};

        android.widget.LinearLayout content = new android.widget.LinearLayout(this);
        content.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, dp(8), pad, 0);

        final TextView value = new TextView(this);
        value.setTextColor(color(R.attr.colorText));
        value.setTextSize(15);
        value.setText(minutes[0] == 0 ? getString(R.string.sleep_off)
                : getString(R.string.sleep_minutes_fmt, minutes[0]));
        content.addView(value);

        SeekBar bar = new SeekBar(this);
        bar.setMax(180);
        bar.setProgress(minutes[0]);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                minutes[0] = progress;
                value.setText(progress == 0 ? getString(R.string.sleep_off)
                        : getString(R.string.sleep_minutes_fmt, progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        content.addView(bar);

        final android.widget.CheckBox check = new android.widget.CheckBox(this);
        check.setText(R.string.sleep_finish_current);
        check.setTextColor(color(R.attr.colorText));
        check.setChecked(finish[0]);
        check.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                finish[0] = isChecked;
            }
        });
        content.addView(check);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.sleep)
                .setView(content)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        service.setSleepMinutes(minutes[0], finish[0]);
                        updateTimer();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        GlassDialogs.apply(this, dialog);
    }

    private void openPreview() {
        if (service == null || service.currentTrack() == null) {
            return;
        }
        Track track = service.currentTrack();
        android.content.Intent intent = new android.content.Intent(this, PreviewActivity.class);
        intent.putExtra(PreviewActivity.EXTRA_URI, track.uri);
        intent.putExtra(PreviewActivity.EXTRA_KEY, CustomArtStore.albumKey(track));
        startActivity(intent);
    }

    private void showLyricOffsetDialog(final Track track) {
        final int[] value = {lyricOffset};
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = dp(20);
        box.setPadding(pad, dp(8), pad, 0);
        final TextView label = new TextView(this);
        label.setTextColor(color(R.attr.colorText));
        label.setTextSize(15);
        label.setText(String.format(Locale.CHINA, "%+.1f s", value[0] / 1000f));
        box.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(4000);
        bar.setProgress(value[0] + 2000);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value[0] = progress - 2000;
                label.setText(String.format(Locale.CHINA, "%+.1f s", value[0] / 1000f));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        box.addView(bar);
        new AlertDialog.Builder(this)
                .setTitle(R.string.lyric_offset)
                .setView(box)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        lyricOffset = value[0];
                        prefs.setLyricOffset(track.uri, lyricOffset);
                        updateLyricLine(service == null ? 0 : service.getPosition());
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showSpeedDialog() {
        if (service == null) {
            return;
        }
        final float[] value = {service.getSpeed()};
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = dp(20);
        box.setPadding(pad, dp(8), pad, 0);
        final TextView label = new TextView(this);
        label.setTextColor(color(R.attr.colorText));
        label.setTextSize(15);
        label.setText(String.format(Locale.CHINA, "%.1f×", value[0]));
        box.addView(label);
        SeekBar bar = new SeekBar(this);
        bar.setMax(15);
        bar.setProgress(Math.round((value[0] - 0.5f) * 10));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value[0] = 0.5f + progress / 10f;
                label.setText(String.format(Locale.CHINA, "%.1f×", value[0]));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        box.addView(bar);
        new AlertDialog.Builder(this)
                .setTitle(R.string.speed)
                .setView(box)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        service.setSpeed(value[0]);
                        updateSpeed();
                    }
                })
                .setNeutralButton("1.0×", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        service.setSpeed(1f);
                        updateSpeed();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showAbDialog() {
        if (service == null) {
            return;
        }
        String[] items = {
                getString(R.string.ab_set_a),
                getString(R.string.ab_set_b),
                getString(R.string.ab_clear)
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.ab_loop)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            service.setAbStart();
                            toast(getString(R.string.ab_point_a, Track.format(service.getPosition())));
                        } else if (which == 1) {
                            service.setAbEnd();
                            toast(getString(service.getAbEnd() > 0 ? R.string.ab_b_set : R.string.ab_b_need_a));
                        } else {
                            service.clearAb();
                            toast(getString(R.string.ab_cleared));
                        }
                    }
                })
                .show();
    }

    private void addBookmarkWithNote(final Track track) {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint(R.string.bookmark_note_hint);
        input.setTextColor(color(R.attr.colorText));
        input.setHintTextColor(color(R.attr.colorTextDim));
        int pad = dp(20);
        input.setPadding(pad, dp(8), pad, dp(8));
        final int position = service.getPosition();
        new AlertDialog.Builder(this)
                .setTitle(R.string.add_bookmark)
                .setMessage(Track.format(position))
                .setView(input)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.addBookmark(track.uri, position, input.getText().toString().trim());
                        toast(getString(R.string.bookmark_saved));
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showBookmarks(Track track) {
        org.json.JSONArray array = prefs.getBookmarks(track.uri);
        if (array == null || array.length() == 0) {
            toast(getString(R.string.bookmarks_none_hint));
            return;
        }
        final ArrayList<Integer> positions = new ArrayList<>();
        String[] items = new String[array.length()];
        for (int i = 0; i < array.length(); i++) {
            org.json.JSONObject item = array.optJSONObject(i);
            int pos = item == null ? 0 : item.optInt("p");
            String note = item == null ? "" : item.optString("n");
            positions.add(pos);
            items[i] = Track.format(pos) + (note.isEmpty() ? "" : " · " + note);
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.bookmarks)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (service != null) {
                            service.seekTo(positions.get(which));
                        }
                    }
                })
                .setNegativeButton(R.string.close, null)
                .show();
    }

    private void showInfo() {
        if (service != null) {
            InfoDialog.show(PlayerActivity.this, service.currentTrack());
        }
    }

    private void showLyrics() {
        if (prefs != null) {
            prefs.setLyricsMode(true);
        }
        applyMode(true);
        renderLyrics();
    }

    private void showCover() {
        if (prefs != null) {
            prefs.setLyricsMode(false);
        }
        applyMode(false);
    }

    /** 封面与歌词切换：让标题位移、淡入淡出由 TransitionManager 统一编排。 */
    private void applyMode(boolean lyrics) {
        if (lyricsMode == lyrics) {
            return;
        }
        lyricsMode = lyrics;
        boolean reduce = prefs != null && prefs.reduceMotion();
        if (!reduce && content instanceof ViewGroup) {
            AutoTransition transition = new AutoTransition();
            transition.setDuration(240);
            transition.setInterpolator(new DecelerateInterpolator());
            TransitionManager.beginDelayedTransition((ViewGroup) content, transition);
        }
        mediaArea.setVisibility(lyrics ? View.GONE : View.VISIBLE);
        spacer.setVisibility(lyrics ? View.GONE : View.VISIBLE);
        coverBox.setVisibility(lyrics ? View.GONE : View.VISIBLE);
        album.setVisibility(lyrics ? View.GONE : View.VISIBLE);
        lyricsScroll.setVisibility(lyrics ? View.VISIBLE : View.GONE);
        if (lyrics && !reduce) {
            lyricsScroll.setAlpha(0f);
            lyricsScroll.setTranslationY(dp(16));
            lyricsScroll.animate().alpha(1f).translationY(0)
                    .setDuration(260)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        } else if (reduce) {
            lyricsScroll.setAlpha(1f);
            lyricsScroll.setTranslationY(0);
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void closeWithSlide() {
        content.animate().translationY(content.getHeight()).setDuration(180)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }).start();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!bound) {
            bindService(new Intent(this, PlayerService.class), connection, BIND_AUTO_CREATE);
            bound = true;
        }
        ui.post(ticker);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sync();
    }

    @Override
    protected void onStop() {
        super.onStop();
        ui.removeCallbacks(ticker);
        if (service != null) {
            service.removeListener(this);
        }
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        service = null;
    }

    @Override
    public void onStateChanged() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                sync();
            }
        });
    }

    @Override
    public void onError(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }
                new AlertDialog.Builder(PlayerActivity.this)
                        .setTitle(R.string.play_failed_title)
                        .setMessage(message)
                        .setPositiveButton(R.string.retry, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (service != null) {
                                    service.retry();
                                }
                            }
                        })
                        .setNeutralButton(R.string.skip, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (service != null) {
                                    service.skip();
                                }
                            }
                        })
                        .setNegativeButton(R.string.stop_play, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (service != null) {
                                    service.stopPlayback();
                                }
                            }
                        })
                        .show();
            }
        });
    }

    private void sync() {
        if (service == null) {
            return;
        }
        Track track = service.currentTrack();
        if (track == null) {
            return;
        }
        boolean playing = service.isPlaying();
        if (playing != lastPlaying) {
            lastPlaying = playing;
            pulse(playButton);
        }
        playButton.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        playButton.setContentDescription(getString(playing ? R.string.pause : R.string.play));
        setTextFaded(title, track.title, 0);
        setTextFaded(artist, track.artist, 50);
        setTextFaded(album, track.album == null ? "" : track.album, 90);
        int duration = service.getDuration();
        totalTime.setText(Track.format(duration > 0 ? duration : track.duration));

        if (track.id != currentTrackId) {
            currentTrackId = track.id;
            loadLyrics(track);
            updateQuality(track);
            lyricOffset = prefs.lyricOffset(track.uri);
            if (track.id == sharedTrackId) {
                sharedTrackId = -1;
                final Track delayed = track;
                ui.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loadArt(delayed);
                    }
                }, 420);
            } else {
                loadArt(track);
            }
            if (prefs != null && prefs.lyricsMode() && !lyricsMode) {
                showLyrics();
            } else if (prefs != null && !prefs.lyricsMode() && lyricsMode) {
                applyMode(false);
            }
        }

        updateMode();
        updateTimer();
        updateSpeed();
        updateProgress();
    }

    private void loadLyrics(final Track track) {
        lyricsData = Lyrics.Data.empty();
        lyricLine = -1;
        lyrics.setText(R.string.lyrics_none);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Lyrics.Data data = Lyrics.load(PlayerActivity.this, track);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || track.id != currentTrackId) {
                            return;
                        }
                        lyricsData = data;
                        lyricLine = -1;
                        renderLyrics();
                    }
                });
            }
        }).start();
    }

    private void renderLyrics() {
        int accent = color(R.attr.colorAccent);
        int dim = color(R.attr.colorTextDim);
        lyrics.setTextColor(dim);
        if (lyricsData == null || (lyricsData.lines.isEmpty() && lyricsData.plain.isEmpty())) {
            lyrics.setText(R.string.lyrics_none);
            return;
        }
        if (!lyricsData.timed) {
            lyrics.setText(lyricsData.plain);
            return;
        }
        SpannableStringBuilder sb = new SpannableStringBuilder();
        int offset = 0;
        for (int i = 0; i < lyricsData.lines.size(); i++) {
            String text = lyricsData.lines.get(i).text;
            sb.append(text).append('\n');
            int start = offset;
            int end = offset + text.length();
            if (i == lyricLine) {
                sb.setSpan(new ForegroundColorSpan(accent), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), start, end,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            offset = end + 1;
        }
        lyrics.setText(sb);
        scrollToLyric();
    }

    private void scrollToLyric() {
        if (!lyricsData.timed || lyricLine < 0) {
            return;
        }
        lyrics.post(new Runnable() {
            @Override
            public void run() {
                Layout layout = lyrics.getLayout();
                if (layout == null) {
                    return;
                }
                int line = Math.min(lyricLine, layout.getLineCount() - 1);
                int y = layout.getLineTop(Math.max(0, line));
                int height = lyricsScroll.getHeight();
                lyricsScroll.smoothScrollTo(0, Math.max(0, y - height / 3));
            }
        });
    }

    private void updateLyricLine(int position) {
        if (lyricsData == null || !lyricsData.timed || lyricsData.lines.isEmpty()) {
            return;
        }
        position += lyricOffset;
        int line = -1;
        for (int i = 0; i < lyricsData.lines.size(); i++) {
            if (lyricsData.lines.get(i).time <= position) {
                line = i;
            } else {
                break;
            }
        }
        if (line != lyricLine) {
            lyricLine = line;
            renderLyrics();
        }
    }

    @Override
    protected void onApplyInsets(int left, int top, int right, int bottom) {
        View contentView = findViewById(R.id.player_content);
        if (contentView != null) {
            contentView.setPadding(left, top, right, bottom);
        }
    }

    private void updateQuality(final Track track) {
        if (qualityView == null) {
            return;
        }
        qualityView.setVisibility(View.GONE);
        final String key = track.uri;
        qualityView.setTag(key);
        QualityLoader.request(this, track, new QualityLoader.Callback() {
            @Override
            public void onQuality(String uri, Quality quality) {
                if (key.equals(qualityView.getTag())) {
                    qualityView.setText(quality.detail);
                    qualityView.getBackground().mutate().setTint(quality.color);
                    qualityView.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private int glassLevel() {
        int level = prefs.frostedGlass();
        if (level < 0) {
            boolean lowRam = ((android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE))
                    .isLowRamDevice();
            level = lowRam ? 0 : 2;
        }
        return level;
    }

    private void applyPlayerBackground(final Bitmap bitmap) {
        int level = glassLevel();
        if (level <= 0 || bitmap == null) {
            if (playerBg != null) {
                playerBg.setVisibility(View.GONE);
            }
            return;
        }
        final boolean acrylic = prefs.glassMaterial() == 1;
        final int radius = acrylic
                ? (level >= 3 ? 8 : level == 2 ? 4 : 2)
                : (level >= 3 ? 14 : level == 2 ? 8 : 4);
        int bgColor = color(R.attr.colorBg);
        final int tint = android.graphics.Color.argb(255,
                android.graphics.Color.red(bgColor),
                android.graphics.Color.green(bgColor),
                android.graphics.Color.blue(bgColor));
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Bitmap blurred = Blur.blurBitmap(bitmap, radius);
                if (blurred != null && acrylic) {
                    Blur.acrylic(blurred, tint, 0.16f, 0.025f);
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (blurred == null || isFinishing()) {
                            return;
                        }
                        playerBg.setImageBitmap(blurred);
                        playerBg.setAlpha(acrylic ? 0.32f : 0.24f);
                        playerBg.setVisibility(View.VISIBLE);
                    }
                });
            }
        }, "player-blur").start();
    }

    private void loadArt(final Track track) {
        final int token = ++artToken;
        if (currentArt == null) {
            art.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
        }
        boolean lowRam = ((android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE)).isLowRamDevice();
        int artSize = lowRam ? 1024 : 1536;
        ArtLoader.load(this, CustomArtStore.albumKey(track), track.uri, artSize, new ArtLoader.Callback() {
            @Override
            public void onArt(String uri, Bitmap bitmap) {
                if (token != artToken || isFinishing()) {
                    return;
                }
                if (bitmap == null) {
                    showNoArt();
                    return;
                }
                showArt(bitmap, token);
                preloadNext();
            }
        });
    }

    /** 旧封面淡出、新封面淡入并轻微缩放，避免切歌时闪空。 */
    private void showArt(Bitmap bitmap, int token) {
        art.setVisibility(View.VISIBLE);
        placeholder.setVisibility(View.GONE);
        applyPlayerBackground(bitmap);
        if (currentArt == null) {
            art.setImageBitmap(bitmap);
            art.setAlpha(0f);
            art.setScaleX(1.04f);
            art.setScaleY(1.04f);
            art.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(new DecelerateInterpolator()).start();
        } else {
            Drawable[] layers = new Drawable[]{
                    new BitmapDrawable(getResources(), currentArt),
                    new BitmapDrawable(getResources(), bitmap)
            };
            TransitionDrawable transition = new TransitionDrawable(layers);
            art.setImageDrawable(transition);
            transition.startTransition(240);
            final Bitmap target = bitmap;
            art.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (token == artToken) {
                        art.setImageBitmap(target);
                    }
                }
            }, 270);
            art.animate().scaleX(1.03f).scaleY(1.03f).setDuration(120)
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            art.animate().scaleX(1f).scaleY(1f).setDuration(160).start();
                        }
                    }).start();
        }
        currentArt = bitmap;
    }

    /** 新歌没有内嵌封面：淡出旧图并显示占位音符，避免沿用上一首的封面。 */
    private void showNoArt() {
        currentArt = null;
        if (playerBg != null) {
            playerBg.setVisibility(View.GONE);
        }
        if (art.getVisibility() != View.VISIBLE) {
            art.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
            return;
        }
        art.animate().alpha(0f).setDuration(160).withEndAction(new Runnable() {
            @Override
            public void run() {
                art.setImageDrawable(null);
                art.setVisibility(View.GONE);
                art.setAlpha(1f);
                placeholder.setAlpha(0f);
                placeholder.setVisibility(View.VISIBLE);
                placeholder.animate().alpha(1f).setDuration(180).start();
            }
        }).start();
    }

    /** 预解码下一首封面，切歌时几乎立刻可用。 */
    private void preloadNext() {
        if (service == null) {
            return;
        }
        java.util.List<Track> queue = service.getQueue();
        int next = service.getIndex() + 1;
        if (next >= 0 && next < queue.size()) {
            ArtLoader.load(this, queue.get(next).uri, 1024, new ArtLoader.Callback() {
                @Override
                public void onArt(String uri, Bitmap bitmap) {
                    // 只是预热缓存
                }
            });
        }
    }

    private void setTextFaded(TextView view, String text, long delay) {
        String value = text == null ? "" : text;
        if (value.contentEquals(view.getText())) {
            return;
        }
        view.setText(value);
        view.setAlpha(0f);
        view.animate().alpha(1f).setStartDelay(delay).setDuration(200)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void hideThumb(final SeekBar bar, boolean show) {
        final Drawable thumb = bar.getThumb();
        if (thumb == null) {
            return;
        }
        if (show) {
            thumb.setAlpha(255);
            return;
        }
        ValueAnimator animator = ValueAnimator.ofInt(thumb.getAlpha(), 0);
        animator.setDuration(260);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                thumb.setAlpha((Integer) animation.getAnimatedValue());
            }
        });
        animator.start();
    }

    private void pulse(View view) {
        view.animate().scaleX(1.10f).scaleY(1.10f).setDuration(90)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(130).start();
                    }
                }).start();
    }

    private void updateMode() {
        int mode = service == null ? PlayerService.MODE_SEQUENCE : service.getMode();
        int icon = mode == PlayerService.MODE_SHUFFLE ? R.drawable.ic_shuffle
                : mode == PlayerService.MODE_REPEAT ? R.drawable.ic_repeat_one
                : R.drawable.ic_repeat;
        modeButton.setImageResource(icon);
        modeButton.setColorFilter(mode == PlayerService.MODE_SEQUENCE
                ? color(R.attr.colorText) : color(R.attr.colorAccent));
    }

    private void updateSpeed() {
        if (speedLabel == null) {
            return;
        }
        float speed = service == null ? 1f : service.getSpeed();
        speedLabel.setText(String.format(Locale.CHINA, "%.1f×", speed));
        speedLabel.setTextColor(color(speed == 1f ? R.attr.colorTextDim : R.attr.colorAccent));
    }

    private void updateTimer() {
        boolean active = service != null && service.getSleepMinutes() > 0;
        timerButton.setColorFilter(color(active ? R.attr.colorAccent : R.attr.colorText));
    }

    private int color(int attr) {
        android.util.TypedValue value = new android.util.TypedValue();
        getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    private void updateProgress() {
        if (service == null || service.currentTrack() == null) {
            return;
        }
        int duration = service.getDuration();
        if (duration <= 0) {
            return;
        }
        int position = Math.min(service.getPosition(), duration);
        int progress = (int) Math.min(1000L, (long) position * 1000L / duration);
        if (!userSeeking) {
            seek.setProgress(progress);
        }
        curTime.setText(Track.format(position));
        totalTime.setText(Track.format(duration));
        updateLyricLine(position);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
