package com.sflplayer;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 按需读取单曲格式/码率/采样率，并缓存结果。 */
public final class QualityLoader {

    public interface Callback {
        void onQuality(String uri, Quality quality);
    }

    private static final LruCache<String, Quality> CACHE = new LruCache<>(2048);
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);
    private static final ExecutorService PREFETCH = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static String cacheFile;
    private static int loadedCount;

    private QualityLoader() {
    }

    /** 启动时读取磁盘缓存，二次打开不再显示“只有格式”。 */
    private static synchronized void ensureCache(Context context) {
        if (cacheFile != null) {
            return;
        }
        cacheFile = new File(context.getFilesDir(), "quality_cache.json").getAbsolutePath();
        try {
            File file = new File(cacheFile);
            if (!file.exists()) {
                return;
            }
            byte[] data = new byte[(int) file.length()];
            FileInputStream in = new FileInputStream(file);
            int read = in.read(data);
            in.close();
            JSONObject root = new JSONObject(new String(data, 0, Math.max(0, read), "UTF-8"));
            java.util.Iterator<String> keys = root.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject item = root.optJSONObject(key);
                if (item != null) {
                    CACHE.put(key, new Quality(item.optString("f"), item.optString("s"),
                            item.optString("d"), item.optInt("c", Quality.COLOR_STANDARD)));
                }
            }
        } catch (Throwable ignored) {
            // 缓存损坏时忽略
        }
    }

    private static synchronized void saveCache(Context context) {
        if (cacheFile == null) {
            return;
        }
        try {
            JSONObject root = new JSONObject();
            for (java.util.Map.Entry<String, Quality> entry : CACHE.snapshot().entrySet()) {
                JSONObject item = new JSONObject();
                item.put("f", entry.getValue().format);
                item.put("s", entry.getValue().shortLabel);
                item.put("d", entry.getValue().detail);
                item.put("c", entry.getValue().color);
                root.put(entry.getKey(), item);
            }
            FileOutputStream out = new FileOutputStream(cacheFile);
            out.write(root.toString().getBytes("UTF-8"));
            out.close();
        } catch (Throwable ignored) {
            // 忽略
        }
    }

    /** 后台预取整库，滚动时尽量直接命中完整数据。 */
    public static void prefetch(final Context context, final List<Track> tracks) {
        ensureCache(context);
        PREFETCH.execute(new Runnable() {
            @Override
            public void run() {
                int count = 0;
                for (Track track : tracks) {
                    if (CACHE.get(track.uri) != null) {
                        continue;
                    }
                    Quality quality = read(context.getApplicationContext(), track);
                    CACHE.put(track.uri, quality);
                    if (++count % 20 == 0) {
                        saveCache(context);
                    }
                }
                saveCache(context);
            }
        });
    }

    /** 只按扩展名生成一个轻量徽标，滚动时先顶上。 */
    public static Quality formatOnly(Track track) {
        String format = formatOf(track);
        if (format.isEmpty()) {
            format = "AUDIO";
        }
        return new Quality(format, format, format, Quality.COLOR_STANDARD);
    }

    public static void request(final Context context, final Track track, final Callback callback) {
        if (track == null) {
            return;
        }
        ensureCache(context);
        final String key = track.uri;
        Quality cached = CACHE.get(key);
        if (cached != null) {
            callback.onQuality(key, cached);
            return;
        }
        final Context app = context.getApplicationContext();
        EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                final Quality quality = read(app, track);
                CACHE.put(key, quality);
                if (++loadedCount % 20 == 0) {
                    saveCache(app);
                }
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onQuality(key, quality);
                    }
                });
            }
        });
    }

    private static Quality read(Context context, Track track) {
        String format = formatOf(track);
        int bitrate = 0;
        int sampleRate = 0;
        int bits = 0;
        String mime = "";
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, Uri.parse(track.uri));
            mime = safe(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE));
            bitrate = parse(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE));
            sampleRate = parse(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE));
            if (Build.VERSION.SDK_INT >= 31) {
                bits = parse(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE));
            }
        } catch (Throwable ignored) {
            // 读取失败时退化为扩展名
        } finally {
            try {
                retriever.release();
            } catch (Throwable ignored) {
                // 忽略
            }
        }

        String ext = extension(track);
        boolean lossless = isLossless(ext) || mime.contains("alac") || mime.contains("flac")
                || mime.contains("wav");
        if (format.isEmpty()) {
            format = mime.contains("mpeg") ? "MP3"
                    : mime.contains("mp4") || mime.contains("aac") ? "AAC"
                    : mime.contains("flac") ? "FLAC"
                    : mime.contains("ogg") ? "OGG"
                    : mime.contains("opus") ? "OPUS" : "AUDIO";
        }

        String shortLabel;
        String detail;
        int color;
        if (lossless) {
            boolean hiRes = bits >= 24 || sampleRate >= 96000;
            shortLabel = hiRes
                    ? format + " " + (bits > 0 ? bits : 24) + "/"
                    + (sampleRate > 0 ? sampleRate / 1000 : 96)
                    : format;
            StringBuilder d = new StringBuilder(format);
            if (bits > 0) {
                d.append(" · ").append(bits).append("bit");
            }
            if (sampleRate > 0) {
                d.append(" · ").append(sampleRate / 1000).append("kHz");
            }
            if (bitrate > 0) {
                d.append(" · ").append(bitrate / 1000).append("kbps");
            }
            detail = d.toString();
            color = hiRes ? Quality.COLOR_HI_RES : Quality.COLOR_LOSSLESS;
        } else {
            int kbps = bitrate > 0 ? bitrate / 1000 : 0;
            shortLabel = kbps > 0 ? format + " " + kbps + "k" : format;
            detail = kbps > 0 ? format + " · " + kbps + "kbps" : format;
            if (kbps >= 256) {
                color = Quality.COLOR_HIGH;
            } else if (kbps >= 128) {
                color = Quality.COLOR_STANDARD;
            } else if (kbps > 0) {
                color = Quality.COLOR_LOW;
            } else {
                color = Quality.COLOR_STANDARD;
            }
        }
        if (shortLabel.isEmpty()) {
            shortLabel = "?";
        }
        if (detail.isEmpty()) {
            detail = shortLabel;
        }
        return new Quality(format, shortLabel, detail, color);
    }

    private static String safe(String value) {
        return value == null ? "" : value.toLowerCase();
    }

    private static int parse(String value) {
        try {
            return value == null ? 0 : Integer.parseInt(value.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private static String extension(Track track) {
        String name = track.displayName != null ? track.displayName : track.uri;
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1).toLowerCase() : "";
    }

    private static String formatOf(Track track) {
        String ext = extension(track);
        if (ext.isEmpty()) {
            return "";
        }
        switch (ext) {
            case "mp3":
                return "MP3";
            case "flac":
                return "FLAC";
            case "wav":
                return "WAV";
            case "m4a":
            case "aac":
                return "AAC";
            case "ogg":
                return "OGG";
            case "opus":
                return "OPUS";
            case "wma":
                return "WMA";
            case "ape":
                return "APE";
            case "aiff":
            case "aif":
                return "AIFF";
            case "dsf":
                return "DSF";
            case "dff":
                return "DFF";
            default:
                return ext.length() <= 5 ? ext.toUpperCase() : "";
        }
    }

    private static boolean isLossless(String ext) {
        return ext.equals("flac") || ext.equals("wav") || ext.equals("ape")
                || ext.equals("aiff") || ext.equals("aif") || ext.equals("dsf")
                || ext.equals("dff");
    }
}
