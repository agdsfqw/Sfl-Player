package com.sflplayer;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

/** 全屏封面预览。 */
public class PreviewActivity extends BaseActivity {

    public static final String EXTRA_URI = "cover_uri";
    public static final String EXTRA_KEY = "cover_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);
        findViewById(R.id.preview_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        final ZoomImageView image = findViewById(R.id.preview_image);
        String uri = getIntent().getStringExtra(EXTRA_URI);
        String key = getIntent().getStringExtra(EXTRA_KEY);
        if (uri == null) {
            finish();
            return;
        }
        ArtLoader.load(this, key, uri, 2048, new ArtLoader.Callback() {
            @Override
            public void onArt(String u, Bitmap bitmap) {
                if (bitmap == null) {
                    Toast.makeText(PreviewActivity.this, "没有可预览的封面", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    image.setBitmap(bitmap);
                }
            }
        });
    }
}
