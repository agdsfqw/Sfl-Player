package com.sflplayer;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/** 关于页：作者、致谢、许可与版本信息。 */
public class AboutActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView version = findViewById(R.id.about_version);
        String name = "2.2.1";
        try {
            name = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
            // 使用默认值
        }
        version.setText(name + " · Android " + Build.VERSION.RELEASE);
    }
}
