# 构建说明

本项目不使用 Gradle，直接用 Android SDK 自带工具构建。

## 依赖

- JDK 17+
- Android SDK：`platforms/android-34`、`build-tools/34.0.0`
- 签名：脚本会在缺少 `debug.keystore` 时自动生成一个调试密钥

非 x86_64 主机（例如 aarch64）如果 SDK 里的 `aapt2` 只有 x86_64 版本，需要安装 `qemu-user-static`，并保证 `/usr/bin/qemu-x86_64-static` 与 `/tmp/x86root` 存在；也可以通过 `QEMU`、`X86ROOT` 环境变量指定。

## 构建

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk
./build.sh
```

产物为项目根目录的 `SflPlayer.apk`。

## 说明

- 版本号以 `AndroidManifest.xml` 为唯一来源，`build.sh` 会自动读取，不需要再改脚本
- `debug.keystore` 已被 `.gitignore` 忽略，不要提交
- 发布到 GitHub Release 时，建议使用固定的正式签名密钥；更换密钥会导致无法覆盖安装

## 测试

见 [TESTING.md](TESTING.md)；CI 会执行构建与 APK 校验。

## 发布签名（可选）

当前脚本默认使用 `debug.keystore` 调试签名。正式发布时，把签名参数替换为你的 release keystore：

```bash
apksigner sign --ks /path/to/release.jks --ks-key-alias your-alias \
  --ks-pass pass:****** --key-pass pass:****** \
  --out SflPlayer.apk build/aligned.apk
```

不要把 `.jks` 和密码提交到仓库；可以放在 CI Secret 里。
